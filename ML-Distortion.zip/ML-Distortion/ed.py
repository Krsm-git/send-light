import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import copy
import time
import math
import os
pd.set_option('display.max_rows', None)

dfr=pd.read_csv('ERdata.csv',index_col=0)
#print(dfr)

dfd=pd.read_csv('EDdata.csv',index_col=0)
#print(dfd)
dfd=dfd.iloc[:,3:]

dfo=dfr.join(dfd).dropna(how='any')
dfo=dfo.set_index('DefN', drop=True)
print(dfo.index)

dfn=pd.read_csv('element.csv',index_col=0)
dfn=dfn.iloc[:,0:]

import re
rep=[re.sub('_[A-Z][a-z]','',i) for i in dfo.index]
dfo.index=rep
print(dfo)
#print(dfn)
#dfo=dfo.drop('Sc').drop('Y')

#IMPatom = ['Mg','Mn','Ca','Dy','La','Ce','Gd','V','Cr','Ni','Fe','Yt','Nd','Cu','Co','Sc','Zn','K']
G1 = ['K']
G2 = ['Mg','Ca']
TM = ['Mn','V','Cr','Ni','Fe','Cu','Co','Sc','Zn','Yt']
RE = ['Dy','La','Ce','Gd','Nd']
#dfo=dfo.drop(TM)
#dfo=dfo.drop(G1)
#dfo=dfo.drop(G2)
dfo=dfo.drop(RE)

#dfc = dfo.copy()
dfc = dfo.join(dfn).dropna(how='any')

#---Correlation Matrix---#
#import seaborn as sns
#cor = dfc.corr()
#sns.heatmap(cor, cmap= sns.color_palette('coolwarm', 10), annot=True,fmt='.2f', vmin = -1, vmax = 1)

xp=dfc['Eform'].values
yp=dfc['CrR'].values
#yp=dfc['diffthBa1me'].values
#yp=dfc['diffrOx1sk']
#yp=dfc['diffphBa1me']
#yp=dfc['hcrOx1me']
#yp=dfc['dcphOx1me']
#yp=dfc['dcphOx1st']
#yp=dfc['dcphOx1ku']
#yp=dfc['dcthOx1me']
#yp=dfc['dcthOx1me']
plt.scatter(xp,yp)
plt.xlim(xp.min(),xp.max())
plt.ylim(yp.min(),yp.max())

from adjustText import adjust_text
text=dfc.index.values
texts = [plt.text(xp[i], yp[i], text[i], ha='center', va='center') for i in range(len(xp))]
adjust_text(texts)

plt.show()

exit()
