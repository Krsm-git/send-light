import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import copy
import time
import math
import shutil
import os

#--- Color Palette---#
Fmtdata = pd.DataFrame(columns=['Def','Color'],index=[])
DefN='vO'
Fmtdata.loc[DefN] = [DefN,[float(f'{0/255:6.03f}'),float(f'{112/255:6.03f}'),float(f'{192/255:6.03f}')]]
DefN='vBa'
Fmtdata.loc[DefN] = [DefN,[float(f'{255/255:6.03f}'),float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='vTi'
Fmtdata.loc[DefN] = [DefN,[float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Ti_Ti'
Fmtdata.loc[DefN] = [DefN,[float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Ti_Ba'
Fmtdata.loc[DefN] = [DefN,[float(f'{0/255:6.03f}'),float(f'{176/255:6.03f}'),float(f'{80/255:6.03f}')]]
DefN='vO+vBa'
Fmtdata.loc[DefN] = [DefN,[float(f'{255/255:6.03f}'),float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='vO+vTi'
Fmtdata.loc[DefN] = [DefN,[float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='2vO+vTi'
Fmtdata.loc[DefN] = [DefN,[float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Mg'
Fmtdata.loc[DefN] = [DefN,[float(f'{47/255:6.03f}'),float(f'{85/255:6.03f}'),float(f'{151/255:6.03f}')]]
DefN='Mn'
Fmtdata.loc[DefN] = [DefN,[float(f'{112/255:6.03f}'),float(f'{48/255:6.03f}'),float(f'{160/255:6.03f}')]]
DefN='Ca'
Fmtdata.loc[DefN] = [DefN,[float(f'{84/255:6.03f}'),float(f'{130/255:6.03f}'),float(f'{53/255:6.03f}')]]
DefN='Dy'
Fmtdata.loc[DefN] = [DefN,[float(f'{191/255:6.03f}'),float(f'{144/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='La'
Fmtdata.loc[DefN] = [DefN,[float(f'{31/255:6.03f}'),float(f'{78/255:6.03f}'),float(f'{121/255:6.03f}')]]
DefN='Ce'
Fmtdata.loc[DefN] = [DefN,[float(f'{112/255:6.03f}'),float(f'{173/255:6.03f}'),float(f'{71/255:6.03f}')]]
DefN='Gd'
Fmtdata.loc[DefN] = [DefN,[float(f'{112/255:6.03f}'),float(f'{48/255:6.03f}'),float(f'{160/255:6.03f}')]]
DefN='V'
Fmtdata.loc[DefN] = [DefN,[float(f'{228/255:6.03f}'),float(f'{160/255:6.03f}'),float(f'{160/255:6.03f}')]]
DefN='Sr'
Fmtdata.loc[DefN] = [DefN,[float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Cr'
Fmtdata.loc[DefN] = [DefN,[float(f'{119/255:6.03f}'),float(f'{66/255:6.03f}'),float(f'{252/255:6.03f}')]]
DefN='Ni'
Fmtdata.loc[DefN] = [DefN,[float(f'{247/255:6.03f}'),float(f'{102/255:6.03f}'),float(f'{37/255:6.03f}')]]
DefN='W'
Fmtdata.loc[DefN] = [DefN,[float(f'{184/255:6.03f}'),float(f'{187/255:6.03f}'),float(f'{188/255:6.03f}')]]
DefN='Fe'
Fmtdata.loc[DefN] = [DefN,[float(f'{2/255:6.03f}'),float(f'{143/255:6.03f}'),float(f'{150/255:6.03f}')]]
DefN='Y'
Fmtdata.loc[DefN] = [DefN,[float(f'{154/255:6.03f}'),float(f'{208/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Nd'
Fmtdata.loc[DefN] = [DefN,[float(f'{128/255:6.03f}'),float(f'{107/255:6.03f}'),float(f'{80/255:6.03f}')]]
DefN='Cu'
Fmtdata.loc[DefN] = [DefN,[float(f'{160/255:6.03f}'),float(f'{96/255:6.03f}'),float(f'{32/255:6.03f}')]]
DefN='Co'
Fmtdata.loc[DefN] = [DefN,[float(f'{188/255:6.03f}'),float(f'{140/255:6.03f}'),float(f'{150/255:6.03f}')]]
DefN='Sc'
Fmtdata.loc[DefN] = [DefN,[float(f'{255/255:6.03f}'),float(f'{192/255:6.03f}'),float(f'{0/255:6.03f}')]]
DefN='Zn'
Fmtdata.loc[DefN] = [DefN,[float(f'{95/255:6.03f}'),float(f'{95/255:6.03f}'),float(f'{95/255:6.03f}')]]
DefN='K'
Fmtdata.loc[DefN] = [DefN,[float(f'{35/255:6.03f}'),float(f'{112/255:6.03f}'),float(f'{155/255:6.03f}')]]
DefN='Yb'
Fmtdata.loc[DefN] = [DefN,[float(f'{0/255:6.03f}'),float(f'{255/255:6.03f}'),float(f'{255/255:6.03f}')]]
DefN='Be'
Fmtdata.loc[DefN] = [DefN,[float(f'{102/255:6.03f}'),float(f'{153/255:6.03f}'),float(f'{255/255:6.03f}')]]
DefN='Tl'
Fmtdata.loc[DefN] = [DefN,[float(f'{255/255:6.03f}'),float(f'{204/255:6.03f}'),float(f'{255/255:6.03f}')]]
DefN='Ga'
Fmtdata.loc[DefN] = [DefN,[float(f'{214/255:6.03f}'),float(f'{0/255:6.03f}'),float(f'{0/255:6.03f}')]]
#DefN=''
#Fmtdata.loc[DefN] = [DefN,[float(f'{/255:6.03f}'),float(f'{/255:6.03f}'),float(f'{/255:6.03f}')]]
plt.rcParams["figure.figsize"] = [7.0,4.0]  # 図の縦横のサイズ([横(inch),縦(inch)])
plt.rcParams["figure.dpi"] = 150            # dpi(dots per inch)
plt.rcParams["figure.autolayout"] = False   # レイアウトの自動調整を利用するかどうか
plt.rcParams["figure.subplot.left"] = 0.14  # 余白
plt.rcParams["figure.subplot.bottom"] = 0.2 # 余白
plt.rcParams["figure.subplot.right"] = 0.75 # 余白
plt.rcParams["figure.subplot.top"] = 0.93   # 余白
plt.rcParams["figure.subplot.wspace"] = 0.20# 図が複数枚ある時の左右との余白
plt.rcParams["figure.subplot.hspace"] = 0.20# 図が複数枚ある時の上下との余白
plt.rcParams["font.family"] = "serif"       # 使用するフォント
#plt.rcParams["font.serif"] = "Times New Roman"
plt.rcParams["font.size"] = 14              # 基本となるフォントの大きさ
plt.rcParams["mathtext.cal"] ="serif"      # TeX表記に関するフォント設定
plt.rcParams["mathtext.rm"] = "serif"       # TeX表記に関するフォント設定
plt.rcParams["mathtext.it"] = "serif:italic"# TeX表記に関するフォント設定
plt.rcParams["mathtext.bf"] = "serif:bold"  # TeX表記に関するフォント設定
plt.rcParams["mathtext.fontset"] = "cm"     # TeX表記に関するフォント設定
plt.rcParams["xtick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["ytick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["xtick.top"] = False            # 上部に目盛り線を描くかどうか
plt.rcParams["xtick.bottom"] = True         # 下部に目盛り線を描くかどうか
plt.rcParams["ytick.left"] = True           # 左部に目盛り線を描くかどうか
plt.rcParams["ytick.right"] = False          # 右部に目盛り線を描くかどうか
plt.rcParams["xtick.major.size"] = 4.0      # x軸主目盛り線の長さ
plt.rcParams["ytick.major.size"] = 4.0      # y軸主目盛り線の長さ
plt.rcParams["xtick.major.width"] = 1.0     # x軸主目盛り線の線幅
plt.rcParams["ytick.major.width"] = 1.0     # y軸主目盛り線の線幅
plt.rcParams["xtick.minor.visible"] = True # x軸副目盛り線を描くかどうか
plt.rcParams["ytick.minor.visible"] = True # y軸副目盛り線を描くかどうか
plt.rcParams["xtick.minor.size"] = 2.0      # x軸副目盛り線の長さ
plt.rcParams["ytick.minor.size"] = 2.0      # y軸副目盛り線の長さ
plt.rcParams["xtick.minor.width"] = 0.6     # x軸副目盛り線の線幅
plt.rcParams["ytick.minor.width"] = 0.6     # y軸副目盛り線の線幅
plt.rcParams["xtick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["ytick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["axes.labelsize"] = 18         # 軸ラベルのフォントサイズ
plt.rcParams["axes.linewidth"] = 1.5        # グラフ囲う線の太さ
plt.rcParams["axes.grid"] = True            # グリッドを表示するかどうか
plt.rcParams["grid.color"] = "black"        # グリッドの色
plt.rcParams["grid.linewidth"] = 0.5        # グリッドの線幅
plt.rcParams["legend.loc"] = "best"         # 凡例の位置、"best"でいい感じのところ
plt.rcParams["legend.frameon"] = True       # 凡例を囲うかどうか、Trueで囲う、Falseで囲わない
plt.rcParams["legend.framealpha"] = 1.0     # 透過度、0.0から1.0の値を入れる
plt.rcParams["legend.facecolor"] = "white"  # 背景色
plt.rcParams["legend.edgecolor"] = "black"  # 囲いの色
plt.rcParams["legend.fancybox"] = False     # Trueにすると囲いの四隅が丸くなる
plt.rcParams["legend.fontsize"] = 12     # Trueにすると囲いの四隅が丸くなる
plt.rcParams['patch.force_edgecolor'] = True
plt.rcParams["lines.markersize"] = 8
plt.rcParams["lines.markeredgewidth"] = 2.5
plt.rcParams["lines.linewidth"] = 2
#plt.rcParams["lines.linestyle"] = '-'
plt.rcParams.update({"axes.grid" : True, "grid.color": "0.4"})

def ChgStat(DefE):
    nq = len(DefE['q'])
    #print("Number of charge states: ",nq)
    qmin = DefE['q'].min();qmax = DefE['q'].max()
    #print("Charge states: {} ~ {}".format(qmin,qmax))
    qlist=DefE['q'].unique().tolist();qlist.sort()
    #print("Charge states: {}".format(qlist))
    return nq,qmin,qmax,qlist

def ThermTransLev():
    EF=0
    TTLtemp = pd.DataFrame(columns=['Def','q','qd','TTL'],index=[])
    qlt = copy.copy(qlist)
    qlt.pop(-1)
    #for q in reversed(range(qmin,qmax)):
    for q in sorted(qlt, reverse=True):
        TTLs = []
        qltH = [ix for ix in qlist if ix > q]
        #for qd in range(q+1,qmax+1):
        for qd in qltH:
            TTL = -(Efdata.loc[DefN+'q'+str(q)+'EF'+str(EF)]['Eform'] - Efdata.loc[DefN+'q'+str(qd)+'EF'+str(EF)]['Eform'])/(q-qd)
            TTLs.append(TTL)
        qt = q+1+TTLs.index(max(TTLs))
        TTLtemp.loc[DefN+'q'+str(q)+'qd'+str(qd)] = [DefN,q,qt,max(TTLs)]
    if len(TTLtemp) == 1:
        TTLmin = TTLtemp.index.values[0]
    else:
        TTLmin = TTLtemp[ TTLtemp['qd'] == qmax ]['TTL'].idxmin()
    qnmin = TTLtemp.loc[TTLmin]['q']
    qdnmin = TTLtemp.loc[TTLmin]['qd']
    TTLdata.loc[DefN+'q'+str(qnmin)+'qd'+str(qdnmin)] = TTLtemp.loc[TTLmin]
    if qnmin != qmin :
        for x in range(10):
            qnext = TTLtemp.loc[TTLtemp[ TTLtemp['qd'] == qdnmin ]['TTL'].idxmin()]['q']
            TTLmin = TTLtemp[ TTLtemp['qd'] == qnext ]['TTL'].idxmin()
            qnmin = TTLtemp.loc[TTLmin]['q']
            qdnmin = TTLtemp.loc[TTLmin]['qd']
            TTLdata.loc[DefN+'q'+str(qnmin)+'qd'+str(qdnmin)] = TTLtemp.loc[TTLmin]
            if qnmin == qmin:
                break
    return TTLdata

def EfPlot(TTLdata,Efdata,CNL):
    print("|---------------------------|")
    print("|-------Visualization-------|")
    print("|---------------------------|")
    
    ysh = 0.7
   
    fig = plt.figure()
    fig_1 = fig.add_subplot(111)

    import itertools
    import re
    for DefN in TTLdata['Def'].unique():
        cn = 0
        cend = len(TTLdata[TTLdata['Def'] == DefN]['qd'].values)
        for qd in TTLdata[TTLdata['Def'] == DefN]['qd'].values:
            XAXt = DefN
            lc = list(itertools.chain.from_iterable(Fmtdata[Fmtdata['Def'] == XAXt]['Color'].tolist()))
            pc = lc
            tc = lc
            lt='-'
            mk='o'
            pcf = 'blue'
            txttemp1 = '$\mathrm{XAX}_\mathrm{Ti}$'
            txttemp2 = '$\mathrm{XAX}_\mathrm{Ti}^{XQX}$'
            txtlab1=txttemp1.replace('XAX', XAXt)
            txttemp2=txttemp2.replace('XAX', XAXt)
            cn = cn + 1
            TTL = TTLdata[ (TTLdata['Def'] == DefN) & (TTLdata['qd'] == qd) ]['TTL'].values[0]
            q = TTLdata[ (TTLdata['Def'] == DefN) & (TTLdata['qd'] == qd) ]['q'].values[0]
            EF = 0
            Efq = Efdata.loc[DefN+'q'+str(q)+'EF'+str(int(EF))]['Eform']
            Efqd = Efdata.loc[DefN+'q'+str(qd)+'EF'+str(int(EF))]['Eform']
            if cn == 1:
                EFp1 = -2
                EfqEFp1 = Efqd + qd*EFp1
                EFp2 = TTL
                EfqEFp2 = Efqd + qd*EFp2
                txtlab2=txttemp2.replace('XQX', str(qd))
                fig_1.plot([EFp1,EFp2],[EfqEFp1,EfqEFp2], color=lc, linestyle=lt, marker=mk, markeredgecolor=pc,  markerfacecolor=pcf, label=txtlab1)
                #texts = plt.text((0+EFp2)/2,(Efqd+EfqEFp2)/2+ysh,txtlab2,ha='center',va='center',color=tc)
                #texts = plt.text((0+EFp2)/2,(Efqd+EfqEFp2)/2,qd,ha='center',va='center',color=tc,bbox=dict(facecolor='w', pad=0, alpha=0.7, linewidth=0))
            else:
                EFp1 = EFPre
                EfqEFp1 = EfqdPre
                EFp2 = TTL
                EfqEFp2 = Efqd + qd*EFp2
                txtlab2=txttemp2.replace('XQX', str(qd))
                fig_1.plot([EFp1,EFp2],[EfqEFp1,EfqEFp2], color=lc, linestyle=lt, marker=mk, markeredgecolor=pc, markerfacecolor=pcf)
                #texts = plt.text((EFp1+EFp2)/2,(EfqEFp1+EfqEFp2)/2+ysh,txtlab2, ha='center', va='center', color = tc)
                #texts = plt.text((EFp1+EFp2)/2,(EfqEFp1+EfqEFp2)/2,qd, ha='center', va='center', color = tc,bbox=dict(facecolor='w', pad=0, alpha=0.7, linewidth=0))
    
            if cn == cend:
                EFp1 = TTL
                EfqEFp1 = Efq + q*TTL
                EFp2 = 7
                EfqEFp2 = Efq + q*EFp2
                EFg = Eg
                print(DefN+'q'+str(q)+'EF'+str(int(EFg)))
                print(Efdata)
                EfqEFg = Efdata.loc[DefN+'q'+str(q)+'EF'+str(int(EFg))]['Eform']
                txtlab2=txttemp2.replace('XQX', str(q))
                fig_1.plot([EFp1,EFp2],[EfqEFp1,EfqEFp2], color=lc, linestyle=lt, marker=mk, markeredgecolor=pc,  markerfacecolor=pcf)
                #texts = plt.text((EFp1+Eg)/2,(EfqEFp1+EfqEFg)/2+ysh,txtlab2, ha='center', va='center', color = tc)
                #texts = plt.text((EFp1+Eg)/2,(EfqEFp1+EfqEFg)/2,qd, ha='center', va='center', color = tc,bbox=dict(facecolor='w', pad=0, alpha=0.7, linewidth=0))
    
            EFPre = EFp2
            EfqdPre = EfqEFp2
        
    plt.hlines(0, -20, 20, linestyle='-', linewidth=1.0, color='black')
    #plt.vlines(0, -7, 7, linestyle='dashed', linewidth=0.5)
    fig_1.set_xlabel("$\Delta\mathrm{E}_\mathrm{F}$")
    fig_1.set_ylabel("$\mathrm{Formation\ Energy\ (eV)}$")
    fig_1.set_xlim(0,Eg)
    fig_1.set_ylim(-6,6)
    fig_1.set_ylim(-6,6)
    fig_1.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    
    #plt.show()
    #plt.draw()
    #plt.pause(.05)
    fig.savefig('Ef.png', bbox_inches="tight", pad_inches=0.05) 
    plt.close()

Odata = pd.read_csv('Other.dat', index_col=0, header=None)
ECBM = Odata[1]['CBM']
EVBM = Odata[1]['VBM']
Eg = Odata[1]['CBM'] - Odata[1]['VBM']

#dfo=pd.read_csv('a.csv',index_col=0)
dfo=pd.read_csv('atom.csv',index_col=0)
Efdata = pd.DataFrame(columns=['Def','q','EF','Eform'],index=[])
TTLdata = pd.DataFrame(columns=['Def','q','qd','TTL'],index=[])
#for i in range(len(dfo)):
for DefN in dfo.index.unique():
    EF=0
    dfo[dfo.index.str.contains(DefN)]
    nq,qmin,qmax,qlist = ChgStat(DefE=dfo[dfo.index.str.contains(DefN)])
    for EF in [0,Eg]:
      for q in qlist:
          Eform = dfo[(dfo.index.str.contains(DefN)) & (dfo['q'] == q)]['Eform'].values[0] 
          Efdata.loc[DefN+'q'+str(q)+'EF'+str(int(EF))] = [DefN,q,EF,Eform]
#print(Efdata)
#exit()
#for DefN in dfo.index.unique():
    if(len(qlist)==1):
      continue
    TTLdata = ThermTransLev()
#print(TTLdata)
EfPlot(TTLdata,Efdata,-10)
