#!/bin/bash
#PBS -N JOBLOG
#PBS -q cpu_computing_q
#PBS -l select=1:ncpus=16:mpiprocs=16
#PBS -l place=scatter
##PBS -l walltime=1:00:00

# select   : No. of nodes
# mpiprocs : No. of processes per node
# ncpus    : No. of cores per node (= mpiprocs x No. of threads)

#module load vasp/5.4.1
module load ixe2017-impi2017
cd $PBS_O_WORKDIR
PROC_NUM=16     # total No. of processes (= select x mpiprocs)
THREAD_NUM=1    # No. of threads in each node
PROC_PERNODE=16  # No. of processes in each node

export I_MPI_PERHOST=$PROC_PERNODE
export I_MPI_HYDRA_HOST_FILE=$PBS_NODEFILE
export I_MPI_DEBUG=5  # check if core-binding is optimal
export OMP_NUM_THREADS=$THREAD_NUM

ES=dnn
Pp=JJPp
FE=JJFE
n=JJn
x=${ES}-${FE}-${Pp}-${n}
cp HypOpt-DNN.py exe.py

sed -i "s/XXNrank/${n}/g" exe.py
sed -i "s/XXpp/${Pp}/g" exe.py
sed -i "s/XXfe/${FE}/g" exe.py
sed -i "s/XXWW/${x}/g" exe.py
mkdir ResHyp-${x}
mpirun -n $PROC_NUM python -m mpi4py exe.py > LOG-Hypopt-${x}
