#!/bin/bash
#PBS -N NJOB
#PBS -q cpu_computing_q
#PBS -l select=1:ncpus=2:mpiprocs=1
#PBS -l place=scatter
##PBS -l walltime=100:00:00

# select   : No. of nodes
# mpiprocs : No. of processes per node
# ncpus    : No. of cores per node (= mpiprocs x No. of threads)

#module load vasp/5.4.1
module load ixe2017-impi2017
cd $PBS_O_WORKDIR
PROC_NUM=1     # total No. of processes (= select x mpiprocs)
#THREAD_NUM=1    # No. of threads in each node
PROC_PERNODE=1  # No. of processes in each node

export I_MPI_PERHOST=$PROC_PERNODE
export I_MPI_HYDRA_HOST_FILE=$PBS_NODEFILE
#export I_MPI_DEBUG=5  # check if core-binding is optimal
#export OMP_NUM_THREADS=$THREAD_NUM

Pop="BA"
EXE=reg-${Pop}
#cp main.py ${EXE}.py
python ${EXE}.py > LOG-${EXE}
