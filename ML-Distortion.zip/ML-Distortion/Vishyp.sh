for i in `ls -d ResHyp*`
#for i in "ResHyp-dnn-LS-QT-10"
do
echo ${i}
cd ${i}
if [ -f temp ];then
rm temp
fi
for i in `ls hyp*` ;do cat ${i}>> temp;done;sed -i "s/\[//g" temp;sed -i "s/]/,/g" temp
awk 'BEGIN{m=1000}{if(m>$3) m=$3} END{print m}' temp
cp ../vis.py ./
python vis.py
cd ../
done
