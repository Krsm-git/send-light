import numpy as np
import pandas as pd
ts = pd.read_csv('test_features.csv')
ss = pd.read_csv('submission.csv')
#print(ss.describe())
ts1=ts.iloc[:,1:]
ss1=ss.iloc[:,1:]
ss1=ss1*2

#ss1.loc[ts1['cp_type']=='ctl_vehicle', :] = 1E-15
#ss1[ss1 < 1E-15] = 1E-15
#ss1[ss1 > 1-1E-15] = 1-1E-15
#ss2=ss1.sum().sum()
#print(ss2)
#y1=3104
#r1=y1/ss2
#sss1 = ss1*r1
#sss2=sss1.sum()
#print(sss2.sum())
#ss1=sss2

print(ss1.loc[ts1['cp_type']=='ctl_vehicle', :].sum().sum())
ss1.loc[ts1['cp_type']=='ctl_vehicle', :] = 1E-15
ss1[ss1 < 1E-15] = 1E-15
ss1[ss1 > 1-1E-15] = 1-1E-15
ss2=ss1.loc[ts1['cp_type']=='trt_cp', :].sum().sum()
print(ss2)
y1=3104
r1=y1/ss2
ss1.loc[ts1['cp_type']=='trt_cp', :] *= r1
sss1 = ss1
#sss1 = ss1*r1
sss2=sss1.sum()
print(sss2.sum())
#ss1=sss2
print(ss1.loc[ts1['cp_type']=='ctl_vehicle', :].sum().sum())







#nss = ss.iloc[:,1:].to_numpy()
##print(nss.shape)
#for il in np.arange(-3,-2,0.25):
#	#print(il)
#	print(10**il)
#	nssl = np.full_like(nss,10**il,dtype=np.float)
#	#print(nssl.shape)
#	#print(pd.DataFrame(nssl).describe())
#	scr = - nss*np.log(nssl) - (1-nss)*np.log(1-nssl)
#	#print(scr.shape)
#	#print(pd.DataFrame(scr).describe())
#	scrs = np.mean(scr)
#	print(scrs)
