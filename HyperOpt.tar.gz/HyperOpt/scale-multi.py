import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
fmpi = 1

warnings.simplefilter('ignore')

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

start = time.time()

dfo=pd.read_csv('train_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dft=pd.read_csv('test_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

tk=dft.shape
tdis=tk[1]-1
tsam=tk[0]

#dfc=pd.concat([dfo,dfs.iloc[:,1:3]], axis=1)
#mdis=2
dfc=pd.concat([dfo,dfs.iloc[:,1:]], axis=1)
#df=dfc.iloc[:1000,1:]
df=dfc.iloc[:,1:]

#dis=np.loadtxt("dis.dat")

h=df.columns.values
nd=df.loc[:,h].values
dat=nd[:,:]

ntar=mdis
k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis
  
#--Test--#
ndt=dft.loc[:,h[0:-mdis]].values
x=np.zeros([tsam,mdis])
datt=np.hstack([ndt[:,:],x.reshape(-1,mdis)])
ttar=mdis

MINo=np.min(dat[1:,:], axis=0)
MAXo=np.max(dat[1:,:], axis=0)
dat=np.vstack([dat,MINo])
dat=np.vstack([dat,MAXo])

#sc=MinMaxScaler()
sc=StandardScaler()
#sc=QuantileTransformer()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

#--Test--# 
stdt=sc.transform(datt)
stdt0o=stdt.T[0:tdis]
stdt1o=stdt.T[tdis:tdis+ttar]
stdt0,MMit=np.split(stdt0o,[tsam],1)
stdt1,tempt=np.split(stdt1o,[tsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))
	
x_train=std0.T
y_train=std1.T
x_test=stdt0.T

pndis=ndis

k=x_train.shape
nsam=k[0]
ndis=k[1]

#mean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
#nmean_train = np.array(mean_train)
#nmean_test = np.array(mean_test)
#mean_train = nmean_train.reshape(-1,ntar)
#mean_test = nmean_test.reshape(-1,ntar)
#
#ra=np.array([[1]*pndis]*x_test.shape[0])
#rb=mean_test
#R2=np.hstack([ra,rb])
#Rmean_test=sc.inverse_transform(R2)
#Amean_test=Rmean_test[:,pndis:]

#print(Amean_test)
#print(Amean_test.shape)
#
#sh=dfs.iloc[:,1:mdis+1].columns
##sh=dfs.iloc[:,1:].columns
si=dft.iloc[:,0]
#spd=pd.DataFrame(data=Amean_test,index=None,columns=sh,dtype='float')

ss = pd.read_csv('submission.csv')
ss1=ss.iloc[:,1:]
ss1.loc[dft['cp_type']=='ctl_vehicle', :] = 0
ss1[ss1 < 1E-15] = 1E-15
ss1[ss1 > 1-1E-15] = 1-1E-15
print(ss1.sum().sum())
ss2=ss1.sum().sum()
y1=3104
r1=y1/ss2
sss1 = ss1*r1
print(sss1.sum().sum())
spd=sss1

sub=pd.concat([si,spd],axis=1)
print(sub.shape)
sub.to_csv('submission.csv',index=None)

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
