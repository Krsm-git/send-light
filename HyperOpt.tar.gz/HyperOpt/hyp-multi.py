import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
fmpi = 1

warnings.simplefilter('ignore')

start = time.time()

dfo=pd.read_csv('train_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dft=pd.read_csv('test_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

tk=dft.shape
tdis=tk[1]-1
tsam=tk[0]

#dfc=pd.concat([dfo,dfs.iloc[:,1:3]], axis=1)
#mdis=2
dfc=pd.concat([dfo,dfs.iloc[:,1:]], axis=1)
#df=dfc.iloc[:1000,1:]
df=dfc.iloc[:,1:]

#dis=np.loadtxt("dis.dat")

h=df.columns.values
nd=df.loc[:,h].values
dat=nd[:,:]

ntar=mdis
k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis
  
#--Test--#
ndt=dft.loc[:,h[0:-mdis]].values
x=np.zeros([tsam,mdis])
datt=np.hstack([ndt[:,:],x.reshape(-1,mdis)])
ttar=mdis

MINo=np.min(dat[1:,:], axis=0)
MAXo=np.max(dat[1:,:], axis=0)
dat=np.vstack([dat,MINo])
dat=np.vstack([dat,MAXo])

#sc=MinMaxScaler()
sc=StandardScaler()
#sc=QuantileTransformer()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

#--Test--# 
stdt=sc.transform(datt)
stdt0o=stdt.T[0:tdis]
stdt1o=stdt.T[tdis:tdis+ttar]
stdt0,MMit=np.split(stdt0o,[tsam],1)
stdt1,tempt=np.split(stdt1o,[tsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))
	
tmp2 = np.loadtxt("Train_ICA100.dat")
ttmp2 = np.loadtxt("Test_ICA100.dat")

X_train=tmp2
#X_train=std0.T
Y_train=std1.T
X_test=ttmp2
#X_test=stdt0.T

pndis=ndis
k=X_train.shape
Nsam=k[0]
Ndis=k[1]

fcv=np.loadtxt('FCV-M-pp1.dat',dtype=int)
nfcv=np.unique(fcv) - 1
x_train = np.delete(X_train,nfcv,0)
y_train = np.delete(Y_train,nfcv,0)
x_test = X_train[nfcv,:]
y_test = Y_train[nfcv,:]

k=x_train.shape
nsam=k[0]
ndis=k[1]
 
from sklearn.neural_network import MLPRegressor
for mai in [100, 200, 400]:
  for hls in [(50), (50,50), (50,50,50,50), (100), (100,100), (100,100,100,100), (50,100,50)]:
    for act in ['relu', 'tanh']:
      for sol in ['adam', 'sgd', 'lbfgs']:
        for alp in [0.0001, 0.001, 0.01]:
          print("|-----------------------|")
          print("|------Hyper Param------|")
          print("|-----------------------|")
          print(" HiddenLayerSize: {}".format(hls))
          print(" Activator: {}".format(act))
          print(" Solver: {}".format(sol))
          print(" Alpha: {}".format(alp))
          print(" MaxIter: {}".format(mai))
          m = MLPRegressor(verbose=True, hidden_layer_sizes=hls, alpha=alp, solver=sol, activation=act, max_iter=mai, random_state=1)
          m.fit(x_train,y_train)
          print("Neural Network Iter: {}".format(m.n_iter_))
          print("Neural Network Loss: {}".format(m.loss_))
          print("Neural Network Score: {}".format(m.score(x_train,y_train)))
          print("Hyperparameters: {}".format(m.get_params()))
          mean_train = m.predict(x_train)
          mean_test = m.predict(x_test)
          
          nmean_train = np.array(mean_train)
          nmean_test = np.array(mean_test)
          mean_train = nmean_train.reshape(-1,ntar)
          mean_test = nmean_test.reshape(-1,ntar)
          
          #---Prediction Score---#
          print("|-----------------------|")
          print("|------Train Score------|")
          print("|-----------------------|")
          R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
          Ry_train=sc.inverse_transform(R2)
          R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
          Rmean_train=sc.inverse_transform(R2)
          p1=Rmean_train[:,pndis]
          p2=1-Rmean_train[:,pndis]
          pp1=np.where(p1 < 1E-15,1E-15,p1)
          pp2=np.where(p2 < 1E-15,1E-15,p2)
          logl_train = -np.mean(Ry_train[:,pndis]*np.log(pp1)+(1-Ry_train[:,pndis])*np.log(pp2))
          print("Log Loss: {}".format(logl_train))
          
          print("|-----------------------|")
          print("|------Test Score-------|")
          print("|-----------------------|")
          R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
          Ry_test=sc.inverse_transform(R2)
          R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
          Rmean_test=sc.inverse_transform(R2)
          p1=Rmean_test[:,pndis]
          p2=1-Rmean_test[:,pndis]
          pp1=np.where(p1 < 1E-15,1E-15,p1)
          pp2=np.where(p2 < 1E-15,1E-15,p2)
          logl_test = -np.mean(Ry_test[:,pndis]*np.log(pp1)+(1-Ry_test[:,pndis])*np.log(pp2))
          print("Log Loss: {}".format(logl_test))
          #with open('log-loss.dat', 'a') as ff:
          #	ff.write(str(logl_test))
