import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
fmpi = 1

warnings.simplefilter('ignore')

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

start = time.time()

dfo=pd.read_csv('train_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dft=pd.read_csv('test_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

tk=dft.shape
tdis=tk[1]-1
tsam=tk[0]

#dfc=pd.concat([dfo,dfs.iloc[:,1:3]], axis=1)
#mdis=2
dfc=pd.concat([dfo,dfs.iloc[:,1:]], axis=1)
#df=dfc.iloc[:1000,1:]
df=dfc.iloc[:,1:]

#dis=np.loadtxt("dis.dat")

h=df.columns.values
nd=df.loc[:,h].values
dat=nd[:,:]

ntar=mdis
k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis
  
#--Test--#
ndt=dft.loc[:,h[0:-mdis]].values
x=np.zeros([tsam,mdis])
datt=np.hstack([ndt[:,:],x.reshape(-1,mdis)])
ttar=mdis

MINo=np.min(dat[1:,:], axis=0)
MAXo=np.max(dat[1:,:], axis=0)
dat=np.vstack([dat,MINo])
dat=np.vstack([dat,MAXo])

#sc=MinMaxScaler()
sc=StandardScaler()
#sc=QuantileTransformer()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

#--Test--# 
stdt=sc.transform(datt)
stdt0o=stdt.T[0:tdis]
stdt1o=stdt.T[tdis:tdis+ttar]
stdt0,MMit=np.split(stdt0o,[tsam],1)
stdt1,tempt=np.split(stdt1o,[tsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))
	
def dLasso(XLasso, YLasso, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.linear_model import MultiTaskLassoCV
	estimator = MultiTaskLassoCV(normalize=True, cv=2)
	#estimator = MultiTaskLassoCV(normalize=True, cv=10)
	sfm = SelectFromModel(estimator, threshold=trh)
	sfm.fit(XLasso, YLasso)
	d_data = sfm.transform(XLasso)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Selected Descriptors: {}".format(rlabel[[not x for x in removed_idx]]))
	#print("Removed of Descriptors: {}".format(rlabel[removed_idx]))

#def dPCA(XPCA, YPCA, XTPCA, NPC): 
#        from sklearn.decomposition import PCA 
#        from sklearn.decomposition import KernelPCA
#        from sklearn.decomposition import FastICA
#        from sklearn.metrics import explained_variance_score
#        h=[]
#        for i in range(1,NPC,1):
#            h.append("PC" + str(i))
#        h.append("TG")
#        #decomp = PCA(n_components=NPC, random_state=0).fit(XPCA)
#        decomp = FastICA(n_components=NPC, random_state=0).fit(XPCA)
#        #decomp = LDA(n_components=NPC).fit(XPCA, YPCA)
#        #decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XPCA)
#        #decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XPCA)
#        d_data = decomp.transform(XPCA)
#        dt_data = decomp.transform(XTPCA)
#        evs = explained_variance_score(XPCA, decomp.inverse_transform(d_data))
#        #evs_ratio = decomp.explained_variance_ratio_/evs
#        evs_ratio = np.var(d_data, axis=0) / np.sum(np.var(d_data, axis=0))
#        print("|-----------------------|")
#        print("|--Decomposition Param--|")
#        print("|-----------------------|")
#        print("Score: {}".format(evs))
#        print("Score Ratio: {}".format(evs_ratio))
#        print("Shape: {}".format(d_data.shape))
#        #scc=MinMaxScaler()
#        #scc.fit(dd_data)
#        #d_data=scc.transform(dd_data)
#        return d_data, dt_data, h, decomp

def dPCA(XPCA, YPCA, XTPCA, NPC): 
        from sklearn.decomposition import PCA 
        from sklearn.decomposition import KernelPCA
        from sklearn.decomposition import FastICA
        from sklearn.metrics import explained_variance_score
        h=[]
        for i in range(1,NPC,1):
            h.append("PC" + str(i))
        h.append("TG")
        XXPCA=np.vstack([XPCA,XTPCA])
        #decomp = PCA(n_components=NPC, random_state=0).fit(XXPCA)
        decomp = FastICA(n_components=NPC, random_state=0).fit(XXPCA)
        #decomp = LDA(n_components=NPC).fit(XXPCA, YPCA)
        #decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XXPCA)
        #decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XXPCA)
        dd_data = decomp.transform(XXPCA)
        d_data = dd_data[:nsam,:]
        dt_data = dd_data[nsam:,:]
        evs = explained_variance_score(XXPCA, decomp.inverse_transform(dd_data))
        #evs_ratio = decomp.explained_variance_ratio_/evs
        evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
        print("|-----------------------|")
        print("|--Decomposition Param--|")
        print("|-----------------------|")
        print("Score: {}".format(evs))
        print("Score Ratio: {}".format(evs_ratio))
        print("Shape: {}".format(dd_data.shape))
        #scc=MinMaxScaler()
        #scc.fit(dd_data)
        #d_data=scc.transform(dd_data)
        return d_data, dt_data, h, decomp

#d_data = dLasso(XLasso=std0.T, YLasso=std1.T, trh=1e-10, label=h)
#d_data, dt_data, h, decomp = dPCA(XPCA=std0.T, YPCA=std1.T, XTPCA=stdt0.T, NPC=3)

spl0=std0.T[:,:3]
spl1=std0.T[:,3:3+772]
spl2=std0.T[:,3+772:]
tspl0=stdt0.T[:,:3]
tspl1=stdt0.T[:,3:3+772]
tspl2=stdt0.T[:,3+772:]
d_data, dt_data, h, decomp = dPCA(XPCA=spl1, YPCA=std1.T, XTPCA=tspl1, NPC=3)
tmp1=np.hstack([spl0,d_data])
tmp2=np.hstack([tmp1,spl2])
ttmp1=np.hstack([tspl0,dt_data])
ttmp2=np.hstack([ttmp1,tspl2])

#x_train=std0.T
x_train=tmp2
y_train=std1.T
x_test=ttmp2

# --- vis --- #
from mpl_toolkits.mplot3d import Axes3D

#import plotly.graph_objects as go
#import plotly.figure_factory as ff
#fig1 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#fig1.show()
#fig2 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#fig2.show()

di=3
fig = plt.figure(figsize=plt.figaspect(0.5))
#ax = fig.add_subplot(1,1,1)
#scf = ax.scatter(x_train[:,0], x_train[:,1], std1,label="Exp",marker="o",edgecolor='r',c='white',s=y_train[:,0]*40)
#scf = ax.scatter(x_train[:,0], x_train[:,1], std1,label="Exp",marker="o",edgecolor='b',c='white',s=(1-y_train[:,0])*40)
ax = fig.add_subplot(1,1,1, projection='3d')
scf = ax.scatter3D(x_train[:,di+-1], x_train[:,di+1], x_train[:,di+2],label="Exp",marker="o",edgecolor='b',c='white',s=(1-y_train[:,0])*20)
scf = ax.scatter3D(x_train[:,di+-1], x_train[:,di+1], x_train[:,di+2],label="Exp",marker="o",edgecolor='r',c='white',s=y_train[:,0]*5)
#scf = ax.scatter3D(x_train[:,0], x_train[:,1], x_train[:,2],label="Exp",marker="o",edgecolor='g',c='white',s=y_train[:,1]*10)
scf = ax.scatter3D(x_test[:,di+-1], x_test[:,di+1], x_test[:,di+2],label="Exp",marker="o",edgecolor='g',c='white',s=50)
#scf = ax.scatter3D(x_test[:,0], x_test[:,1], x_test[:,2],label="Exp",marker="^",edgecolor='g',c='white',s=y_test*100)
ax.set_xlabel(h[0], fontsize=20)
ax.set_ylabel(h[1], fontsize=20)
#ax.set_zlabel(h[2], fontsize=20)
#ax.set_xlim(-0.1,1.1)
#ax.set_ylim(-0.1,1.1)
#ax.set_zlim(-0.1,1.1)
plt.show()

exit()

pndis=ndis

k=x_train.shape
nsam=k[0]
ndis=k[1]

mean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
nmean_train = np.array(mean_train)
nmean_test = np.array(mean_test)
mean_train = nmean_train.reshape(-1,ntar)
mean_test = nmean_test.reshape(-1,ntar)

ra=np.array([[1]*pndis]*x_test.shape[0])
rb=mean_test
R2=np.hstack([ra,rb])
Rmean_test=sc.inverse_transform(R2)
Amean_test=Rmean_test[:,pndis:]
#Amean_test=mean_test

print(Amean_test)
print(Amean_test.shape)

sh=dfs.iloc[:,1:mdis+1].columns
#sh=dfs.iloc[:,1:].columns
si=dft.iloc[:,0]
spd=pd.DataFrame(data=Amean_test,index=None,columns=sh,dtype='float')
sub=pd.concat([si,spd],axis=1)
print(sub.shape)
sub.to_csv('submission.csv',index=None)

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
