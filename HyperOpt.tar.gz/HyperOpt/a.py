import sklearn.datasets
import sklearn.ensemble
import sklearn.model_selection
import optuna

#目的関数の定義
def objective(trial):
    iris = sklearn.datasets.load_iris()

    #ハイパーパラメータの定義
    n_estimators = trial.suggest_int('n_estimators', 2, 20)
    max_depth = int(trial.suggest_loguniform('max_depth', 1, 32))
    
    #ランダムフォレストモデルの作成
    clf = sklearn.ensemble.RandomForestClassifier(
        n_estimators=n_estimators, max_depth=max_depth)
    
    #ランダムフォレストモデルを交差検証してその平均スコアを返す
    return sklearn.model_selection.cross_val_score(
        clf, iris.data, iris.target, n_jobs=-1, cv=3).mean()
#Optunaオブジェクトの作成 directionをmaximizeとすることで最大化
study = optuna.create_study(direction='maximize')
#100回の試行で最適化をおこなう。
study.optimize(objective, n_trials=100)

#trialにベストのトライアル結果を入れる。
trial = study.best_trial

#ベストな結果、パラメータの表示
print('Accuracy: {}'.format(trial.value))
print("Best hyperparameters: {}".format(trial.params))
