import numpy as np
import pandas as pd

de=pd.read_csv("AllDel.txt-x2")
#de=pd.read_csv("AllDat.txt", dtype='float')
#de=pd.read_csv("AllDat.txt-x2")
#de=pd.read_csv("AllDat.txt-x3", dtype='float')
#de=pd.read_csv("Er.txt")

print(de.describe())
print(de.corr())
#print(de.rank())
#print(de.sort_values('Del'))
dee = de.sort_values('Del')
#print(dee.iloc[-30:,:])
#des = de.sort_values('Test')
#print(des.iloc[-30:,:])
#dess = des.iloc[-10:,:]
#print(dess.corr())
print(dee.iloc[-40:,:].index)
deee = np.array(dee.iloc[-40:,:].index.values)
np.savetxt('edis.dat', deee, fmt='%i')
