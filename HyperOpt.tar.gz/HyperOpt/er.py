import math
import os
import xlrd
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
import time
import warnings
#FLAGMPIfrom mpi4py import MPI
#FLAGMPIcomm = MPI.COMM_WORLD
#FLAGMPIsize = comm.Get_size()
#FLAGMPIrank = comm.Get_rank()
#FLAGnoMPIrank = 0
#FLAGnoMPIsize = 1

warnings.simplefilter('ignore')


def acq_max(n_warmup=10000, n_iter=10):
	from scipy.optimize import minimize
	# Warm up with random points
	x_tries = np.random.uniform(0, 1, size=(n_warmup, ndis))
	ys = ac(x_tries)
	x_max = x_tries[ys.argmax()]
	max_acq = ys.max()
	# Explore the parameter space more throughly
	x_seeds = np.random.uniform(0, 1, size=(n_iter, ndis))
	for x_try in x_seeds:
	    # Find the minimum of minus the acquisition function
	    res = minimize(lambda x: -ac(x.reshape(1, -1)),
	                   x_try.reshape(1, -1),
	                   bounds=MMs.T,
	                   method="L-BFGS-B")
	    # See if success
	    if not res.success:
	        continue
	    # Store it if better than previous minimum(maximum).
	    if max_acq is None or -res.fun[0] >= max_acq:
	        x_max = res.x
	        max_acq = -res.fun[0]
	# Clip output to make sure it lies within the bounds. Due to floating
	# point technicalities this is not always the case.
	return np.clip(x_max, MMs.T[:, 0], MMs.T[:, 1])

def ac(x):
	mean,sigma = m.predict(x)
	#FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
	#FLAGGP_GPymean, sigma = m.predict(x)
	#FLAGGP_GPflowmean, sigma = m.predict_f(x)
	#FLAGGP_GPflowmean=mean.numpy()
	#FLAGGP_GPflowsigma=sigma.numpy()
	ucb=mean+sigma.reshape(-1,1)*kappa
	return ucb

def g(x):
	optimizer = GaussianProcessRegressor(alpha=x,kernel=kernel,n_restarts_optimizer=5,random_state=1)
	optimizer.fit(std0.T,std1.T)
	print(x)
	print(-(optimizer.log_marginal_likelihood()))
	return (-(optimizer.log_marginal_likelihood()))

def ET_Skit(x_train, y_train, x_test): 
	from sklearn.ensemble import BaggingRegressor
	from sklearn.tree import ExtraTreeRegressor
	extra_tree = ExtraTreeRegressor(random_state=1)
	m = BaggingRegressor(extra_tree, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def RF_Skit(x_train, y_train, x_test): 
	from sklearn.ensemble import RandomForestRegressor
	m = RandomForestRegressor(random_state=1)
	#m = RandomForestRegressor(max_depth=2, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def KRR_Skit(x_train, y_train, x_test): 
	from sklearn.kernel_ridge import KernelRidge
	m = KernelRidge(kernel='rbf', alpha=0.007, gamma=0.007)
	#m = KernelRidge(alpha=1.0, kernel='rbf')
	m.fit(x_train,y_train)
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def GP_Skit(x_train, y_train, x_test): 
	from sklearn.gaussian_process import GaussianProcessRegressor
	from sklearn.gaussian_process import kernels as sk_kern
	#kernel=sk_kern.RBF(length_scale=[1]*(ndis))
	#kernel=sk_kern.Matern(nu=2.5,length_scale=[1]*(ndis))
	#kernel=sk_kern.RationalQuadratic(length_scale=1.0, alpha=1.0, length_scale_bounds=(1e-10, 1e+10), alpha_bounds=(1e-10, 1e+10))
	kernel=sk_kern.RationalQuadratic()
	x_min=1E-2
	#m = GaussianProcessRegressor(kernel=kernel,random_state=1)
	m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,random_state=1)
	#m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,n_restarts_optimizer=5,random_state=1)
	m.fit(x_train,y_train)
	print("Log Marginal Likelihood: {}".format(m.log_marginal_likelihood()))
	print(m.kernel_.hyperparameters)
	print("Hyperparameters: {}".format(m.kernel_.theta))
	mean_train, sigma_train = m.predict(x_train, return_std=True)
	mean_test, sigma_test = m.predict(x_test, return_std=True)
	return mean_train, mean_test, sigma_test, m

def GP_GPy(x_train, y_train, x_test): 
	import GPy
	import GPy.kern as gp_kern
	#kern = gp_kern.RBF(input_dim=ndis)
	#kern = gp_kern.RBF(input_dim=ndis, ARD=True)
	#kern = gp_kern.sde_RatQuad(input_dim=ndis)
	kern = gp_kern.sde_RatQuad(input_dim=ndis, ARD=True)
	#kern = gp_kern.RBF(input_dim=ndis, ARD=True) + gp_kern.sde_RatQuad(input_dim=ndis, ARD=True)
	m = GPy.models.GPRegression(X=x_train, Y=y_train.reshape(-1, 1), kernel=kern, normalizer=None)
	#m.Gaussian_noise.variance = 1e-2
	#m.Gaussian_noise.variance.fix()
	#m.kern.lengthscale = [1e-0, 1e+1, 1e+5]
	#m.kern.lengthscale.fix()
	#m.kern.lengthscale.constrain_bounded(1e+1,1e+3)
	#m.kern.lengthscale.constrain_fixed(1e-1)
	#m.sum.rbf.lengthscale.constrain_bounded(1e+1,1e+3)
	#m.sum.RatQuad.lengthscale.constrain_bounded(1e+1,1e+3)
	m.Gaussian_noise.variance.constrain_fixed(1e-2)
	
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.sum.rbf.lengthscale)
	#print(m.sum.RatQuad.lengthscale)
	m.optimize()
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.sum.rbf.lengthscale)
	#print(m.sum.RatQuad.lengthscale)
	mean_train, sigma = m.predict(x_train)
	mean_test, sigma = m.predict(x_test)
	return mean_train, mean_test, m

def GP_GPflow(x_train, y_train, x_test): 
	import gpflow
	import tensorflow as tf
	from gpflow.utilities import print_summary
	#k = gpflow.kernels.RationalQuadratic()
	#k = gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis))) + gpflow.kernels.White(variance=1e-10)
	#k = gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	#k = gpflow.kernels.SquaredExponential()
	#k = gpflow.kernels.SquaredExponential(lengthscales=np.array([1]*(ndis)))
	k = gpflow.kernels.ArcCosine()
	#k = gpflow.kernels.ArcCosine(order=2)
	#k = gpflow.kernels.SquaredExponential(lengthscales=np.array([1]*(ndis))) + gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	#k = gpflow.kernels.SquaredExponential() + gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	m = gpflow.models.GPR(data=(x_train, y_train), kernel=k, mean_function=None) 
	#m.likelihood.variance.assign(0.01)
	#m.likelihood.variance.assign(0.001)
	#gpflow.set_trainable(m.likelihood.variance, False)
	#m.kernel.lengthscales.assign(0.3)
	#print_summary(m)
	opt = gpflow.optimizers.Scipy()
	#opt_logs = opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=100))
	#opt_logs = opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=300), method='BFGS')
	opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=300), method='BFGS')
	#print_summary(m)
	mean_train, sigma = m.predict_f(x_train)
	mean_train=mean_train.numpy()
	mean_test, sigma = m.predict_f(x_test)
	mean_test=mean_test.numpy()
	return mean_train, mean_test, m

def dGPLVM(XLVM, YLVM, NPC):
	import GPy
	import GPy.kern as gp_kern
	input_dim = NPC
	#kern = GPy.kern.RBF(input_dim, 1, ARD=True) 
	kern = GPy.kern.sde_RatQuad(input_dim, 1, ARD=True) 
	#m = GPy.models.GPLVM(XLVM, input_dim, kernel=kern)
	#m = GPy.models.bayesian_gplvm_minibatch.BayesianGPLVMMiniBatch(XLVM, input_dim, num_inducing=30, missing_data=True)
	m = GPy.models.bayesian_gplvm_minibatch.BayesianGPLVMMiniBatch(XLVM, input_dim, num_inducing=int(XLVM.shape[0]*XLVM.shape[1]/100), missing_data=True)
	#m.Gaussian_noise.variance.constrain_fixed(1e-2)
	#print(m)
	#print(m.kern.lengthscale)
	m.optimize(messages=1, max_iters=5e+3)
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.X.shape)
	#print(m.X)
	#print(m.X.mean)
	#m.plot_latent()
	#m.plot_scatter(projection='3d')
	#m.plot_steepest_gradient_map()
	#for c in range(0,2):
	#    arg = np.where(std1.T==c)[0]
	#    plt.scatter(m.X.mean[arg, 0], m.X.mean[arg, 1], c='C'+str(c))
	#plt.show()
	dd_data = m.X.mean.values
	scc=MinMaxScaler()
	scc.fit(dd_data)
	d_data=scc.transform(dd_data)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	return d_data, scc


def dPCA(XPCA, YPCA, NPC): 
	from matplotlib.cm import get_cmap
	from sklearn.decomposition import PCA
	from sklearn.decomposition import KernelPCA
	from sklearn.decomposition import FastICA
	from sklearn.metrics import explained_variance_score
	
	#XPCA=np.hstack([std0.T,std1.T])
	print(XPCA.shape)
	#scsc=StandardScaler()
	#XPCA=scsc.fit_transform(XPCA)
	
	###def customkernel(X1,X2):
	###    from sklearn.metrics.pairwise import rbf_kernel
	###    k = rbf_kernel(X1,X2)
	###    return k
	###decomp = KernelPCA(n_components=3, kernel='precomputed')
	###gram_mat = customkernel(XPCA,XPCA)
	###decomp.fit(gram_mat)
	
	h=[]
	for i in range(1,10,1):
	    h.append("PC" + str(i))
	h.append("Target")
	#h=['PC1','PC2','FE']
	#h=['PC1','PC2','PC3','FE']
	#h=['PC1','PC2','PC3','PC4','FE']
	
	#import umap
	#decomp = umap.UMAP(n_neighbors=5,n_components=NPC).fit(XPCA)
	#decomp = umap.UMAP(n_neighbors=5,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	#decomp = umap.UMAP(n_neighbors=nsam,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	
	#from scipy.optimize import minimize
	#def kPCA(gamma):
	#	print(gamma)
	#	decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma)
	#	decomp.fit(XPCA)
	#	dd_data = decomp.transform(XPCA)
	#	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#	print(evs)
	#	return -evs
	#gam_ini=1.0
	#res = minimize(kPCA,gam_ini)
	#gamma=res.x
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma).fit(XPCA)
	
	#decomp = PCA(n_components=NPC).fit(XPCA)
	decomp = FastICA(n_components=NPC, random_state=0).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XPCA)
	dd_data = decomp.transform(XPCA)
	evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#evs = np.max(evs_ratio)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Score: {}".format(evs))
	print("Score Ratio: {}".format(evs_ratio))
	print("Shape: {}".format(dd_data.shape))
	scc=MinMaxScaler()
	scc.fit(dd_data)
	d_data=scc.transform(dd_data)
	
	#if 2 <= NPC <= 3:
	#	fig = plt.figure(figsize=plt.figaspect(0.5))
	#if NPC == 2:
	#	ax = fig.add_subplot(1,1,1)
	#	scc = ax.scatter(d_data[:,0], d_data[:,1],label="Exp",marker="o",edgecolor='r',c='white',s=YPCA*100)
	#elif NPC == 3:
	#	ax = fig.add_subplot(1,1,1, projection='3d')
	#	scc = ax.scatter3D(d_data[:,0], d_data[:,1], d_data[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=YPCA*100)
	#if 2 <= NPC <= 3:
	#	ax.set_title("PCA visual", fontsize=15)
	#	plt.show()
	#exit()
	
	return d_data, h, decomp, scc

def dLasso(XLasso, YLasso, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.linear_model import LassoCV
	estimator = LassoCV(normalize=True, cv=10)
	#estimator = LassoCV(normalize=True)
	sfm = SelectFromModel(estimator, threshold=trh)
	sfm.fit(XLasso, YLasso)
	d_data = sfm.transform(XLasso)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Removed of Descriptors: {}".format(rlabel[removed_idx]))
	return d_data

def dRFS(XRFS, YRFS, label):
	from sklearn.feature_selection import RFECV
	from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, SGDRegressor
	from sklearn.linear_model import LassoCV
	from xgboost import XGBRegressor
	from catboost import CatBoostRegressor
	#estimator = Ridge()
	estimator = XGBRegressor()
	#estimator = CatBoostRegressor()
	#estimator = LassoCV(normalize=True, cv=10)

	sfm = RFECV(estimator, step=1, cv=10)
	sfm.fit(XRFS, YRFS)
	d_data = sfm.transform(XRFS)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Selected Descriptors: {}".format(rlabel[[not x for x in removed_idx]]))
	#print("Removed  Descriptors: {}".format(rlabel[removed_idx]))
	return d_data


start = time.time()

#df=pd.read_excel('FLAG1', header=None, index_col=None).replace('male',0).replace('female',1).replace('C',0).replace('S',1).replace('Q',2)
#df=pd.read_excel('FLAG1', header=None, index_col=None)
df=pd.read_excel('FLAG1')

###---Fill with 0---#
##df=df.fillna('A')
###---Label Encoding---#
##import sklearn.preprocessing as sp
##for ile in range(1,7,1):
##  le = sp.LabelEncoder()
##  le.fit(df[df.columns[ile]].unique())
##  k=le.transform(df[df.columns[ile]])
##  df.iloc[:,ile]=k
###print(df.iloc[:,1:7])
###--------------------#
df=df[df['EH'] < 400]
#df=df[df['EH'] < 10]
#df.to_excel('train_Ehull-1918.xlsx')
#exit()

dis=np.loadtxt("dis.dat")
h=df.iloc[:,dis].columns.values
#h=df.iloc[:,2:490].columns.values
h=np.append(h,'EH')

#h=df.iloc[:,2:].columns.values

#h=['TF','OF','AO','BO','AB','EH']

nd=df.loc[:,h].values

#dat=nd[:-1,:]
dat=nd[:,:]
#dat=nd[1:,1:]

ntar=1
k=dat.shape
ndis=k[1]-1
nsam=k[0]

#FLAG_MM1nsam=nsam-2
#FLAG_MM1MINo=dat[nsam,:]
#FLAG_MM1MAXo=dat[nsam+1,:]

#FLAG_MM2MINo=np.min(dat[1:,:], axis=0)
#FLAG_MM2MAXo=np.max(dat[1:,:], axis=0)
#FLAG_MM2dat=np.vstack([dat,MINo])
#FLAG_MM2dat=np.vstack([dat,MAXo])

#sc=RobustScaler()
#sc=MinMaxScaler()
sc=StandardScaler()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))
	
if ndis >= 2:
	MMs=MMi.T
else:
	MMs=MMi.reshape(-1,1)

d_data=std0.T
#NPC=30
#d_data, h, decomp, scc = dPCA(XPCA=std0.T, YPCA=std1.T, NPC=NPC)
#d_data = dLasso(XLasso=std0.T, YLasso=std1.T, trh=1e-10, label=h)
#d_data = dRFS(XRFS=std0.T, YRFS=std1.T, label=h)
#d_data, scc = dGPLVM(XLVM=std0.T, YLVM=std1.T, NPC=NPC)

pndis=ndis
Armse_train=[]
Armse_test=[]
Asigma_test=[]
#from sklearn.model_selection import train_test_split
#Lrank = rank + 1
#Lsize = 1
#for LRepeat in range(0, Lsize, 1):
#    Repeat = Lrank * (LRepeat + 1)
#    x_train, x_test, y_train, y_test = train_test_split(d_data, std1.T, test_size=0.2, random_state=Repeat)

Lsta = math.floor(nsam / size * rank)
Lend = math.floor(nsam / size * (rank + 1))
if size == (rank + 1):
    Lend = nsam
Lsta = 99
Lend = 100
print("MPI Loop Start : {}".format(Lsta))
print("MPI Loop End   : {}".format(Lend))
for di in range(Lsta, Lend, 1):
    x_train = np.delete(std0.T, di, 0)
    y_train = np.delete(std1.T, di, 0)
    x_test = std0.T[di,:]
    y_test = std1.T[di,:]
    #x_test = x_test.T
    x_test = x_test.reshape(1,-1)
    y_test = y_test.reshape(1,-1)
    
    k=x_train.shape
    nsam=k[0]
    ndis=k[1]
    
    #FLAGET_Skitmean_train, mean_test, m = ET_Skit(x_train, y_train, x_test)
    #FLAGRF_Skitmean_train, mean_test, m = RF_Skit(x_train, y_train, x_test)
    #FLAGNN_Skitmean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
    #FLAGKRR_Skitmean_train, mean_test, m = KRR_Skit(x_train, y_train, x_test)
    #FLAGGP_Skitmean_train, mean_test, sigma_test, m = GP_Skit(x_train, y_train, x_test)
    #FLAGGP_GPymean_train, mean_test, m= GP_GPy(x_train, y_train, x_test)
    #FLAGGP_GPflowmean_train, mean_test, m = GP_GPflow(x_train, y_train, x_test)
    nmean_train = np.array(mean_train)
    nmean_test = np.array(mean_test)
    mean_train = nmean_train.reshape(-1,1)
    mean_test = nmean_test.reshape(-1,1)
    
    
    ##Prediction Score
    from sklearn.metrics import mean_squared_error
    from sklearn.metrics import r2_score
    print("|-----------------------|")
    print("|------Train Score------|")
    print("|-----------------------|")
    rmse = np.sqrt(mean_squared_error(mean_train, y_train))
    print("Mean Squared Error : {0:.4%}".format(rmse))
    R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
    Ry_train=sc.inverse_transform(R2)
    R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
    Rmean_train=sc.inverse_transform(R2)
    Rrmse_train = np.sqrt(mean_squared_error(Rmean_train[:,pndis], Ry_train[:,pndis]))
    print("Mean Squared Error (Real): {0:.4f}".format(float(Rrmse_train)))
    r2s = r2_score(Rmean_train, Ry_train)
    print("R2 Score: {}".format(r2s))
    
    ##Correlation Matrix
    #print(np.corrcoef(std.transpose()))
    
    ##Test Score according to TrainData
    print("|-----------------------|")
    print("|------Test Score-------|")
    print("|-----------------------|")
    rmse = np.sqrt(mean_squared_error(mean_test, y_test))
    print("Mean Squared Error : {0:.4%}".format(rmse))
    R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
    Ry_test=sc.inverse_transform(R2)
    R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
    Rmean_test=sc.inverse_transform(R2)
    Rrmse_test = np.sqrt(mean_squared_error(Rmean_test[:,pndis], Ry_test[:,pndis]))
    print("Prediction Value (Real): {0:.4f}".format(float(Rmean_test[:,pndis])))
    print("Correct Value (Real): {0:.4f}".format(float(Ry_test[:,pndis])))
    print("Mean Squared Error (Real): {0:.4f}".format(float(Rrmse_test)))
    r2s = r2_score(Rmean_test, Ry_test)
    print("R2 Score: {}".format(r2s))
    k=x_test.shape
    nsam2=k[0]
    stds0=x_test
    stds1=y_test
    Armse_train.append(Rrmse_train)
    Armse_test.append(Rrmse_test)
    #FLAGGP_SkitAsigma_test.append(sigma_test)
    
    #FLAGPP##Parity Plot
    #FLAGPPfont_axis_publish = {
    #FLAGPP        'color':  'black',
    #FLAGPP        'weight': 'bold',
    #FLAGPP        'size': 22,
    #FLAGPP        }
    #FLAGPPplt.rcParams['ytick.labelsize'] = 16
    #FLAGPPplt.rcParams['xtick.labelsize'] = 16
    #FLAGPP# Plot Figures
    #FLAGPPfignow = plt.figure(figsize=(8,8))
    #FLAGPPx1 =    Ry_train[:,pndis] 
    #FLAGPPy1 = Rmean_train[:,pndis]
    #FLAGPPx2 =     Ry_test[:,pndis]
    #FLAGPPy2 =  Rmean_test[:,pndis]
    #FLAGPP## find the boundaries of X and Y values
    #FLAGPPbounds1 = np.array([min(x1.min(), y1.min()) - int(0.1 * y1.min()), max(x1.max(), y1.max())+ int(0.1 * y1.max())])
    #FLAGPPbounds2 = np.array([min(x2.min(), y2.min()) - int(0.1 * y2.min()), max(x2.max(), y2.max())+ int(0.1 * y2.max())])
    #FLAGPPbounds  = (min(bounds1.min(), bounds2.min()), max(bounds1.max(), bounds2.max()))
    #FLAGPP# Reset the limits
    #FLAGPPax = plt.gca()
    #FLAGPPax.set_xlim(bounds)
    #FLAGPPax.set_ylim(bounds)
    #FLAGPP# Ensure the aspect ratio is square
    #FLAGPPax.set_aspect("equal", adjustable="box")
    #FLAGPPax.scatter(x1[:], y1[:],label="Train",marker="o",edgecolor='r',c='white',s=50)
    #FLAGPPax.scatter(x2[:], y2[:],label="Train",marker="^",edgecolor='b',c='white',s=50)
    #FLAGPPax.plot([0, 1], [0, 1], "k-",lw=2 ,transform=ax.transAxes)
    #FLAGPPplt.title("Parity Plot", fontdict=font_axis_publish)
    #FLAGPPplt.xlabel('Ground Truth', fontdict=font_axis_publish)
    #FLAGPPplt.ylabel('Prediction', fontdict=font_axis_publish)
exit()
    
Armse_train = np.array(Armse_train, dtype='d')
Armse_test = np.array(Armse_test, dtype='d')
#FLAGGP_SkitAsigma_test = np.array(Asigma_test, dtype='d')

#print("|-----------------------|")
#print("|--MPI--|")
#print("|-----------------------|")
#print("My rank: {}".format(rank))
filename = "{0:03d}".format(rank)
np.savetxt(filename + "train.txt", Armse_train)
np.savetxt(filename + "test.txt", Armse_test)
np.savetxt(filename + "sigma.txt", Asigma_test)

recvbuf = None
if rank == 0:
  recvbuf = np.zeros([74, size], dtype='d')
sendbuf = Armse_train.reshape(-1, 1)

comm.Gather(sendbuf,recvbuf, root=0)
Krmse_train = recvbuf
sendbuf = Armse_test.reshape(-1,1)
comm.Gather(sendbuf, recvbuf, root=0)
Krmse_test = recvbuf
if rank == 0:
  Armse_train = np.array(Krmse_train)
  Armse_test =  np.array(Krmse_test)
  Armse_train = Armse_train.reshape(-1,1)
  Armse_test =   Armse_test.reshape(-1,1)
  np.savetxt('Er-list-train.txt', Armse_train)
  np.savetxt('Er-list-test.txt', Armse_test)

if rank == 0:
  print("|-----------------------|")
  print("|--Summary RMSE Scores--|")
  print("|-----------------------|")
  #print("Cross-Validate RMSE Train: {}".format(Armse_train))
  #print("Cross-Validate RMSE Test : {}".format(Armse_test))
  print("|---Train RMSE Scores---|")
  print("Cross-Validate RMSE Train Mean: {0:.4f}".format(np.mean(Armse_train)))
  print("Cross-Validate RMSE Train Std : {0:.4f}".format(np.std(Armse_train)))
  print("Cross-Validate RMSE Train Std2: {0:.4f}".format(np.square(np.std(Armse_train))))
  print("Cross-Validate RMSE Train Max : {0:.4f}".format(np.max(Armse_train)))
  print("Cross-Validate RMSE Train Min : {0:.4f}".format(np.min(Armse_train)))
  print("|----Test RMSE Scores---|")
  print("Cross-Validate RMSE Test  Mean: {0:.4f}".format(np.mean(Armse_test)))
  print("Cross-Validate RMSE Test  Std : {0:.4f}".format(np.std(Armse_test)))
  print("Cross-Validate RMSE Test  Std2: {0:.4f}".format(np.square(np.std(Armse_test))))
  print("Cross-Validate RMSE Test  Max : {0:.4f}".format(np.max(Armse_test)))
  print("Cross-Validate RMSE Test  Min : {0:.4f}".format(np.min(Armse_test)))

#plt.show()

###Mean Prediction ArgMax
##if args.noacq is False:
##	MS=open('Prediction/Mean-Scaled.csv', 'a')
##	MD=open('Prediction/Mean-Direct.csv', 'a')
##	MS.write("# Column : Discripter, Row : target-1\n")
##	MD.write("# Column : Discripter, Row : target-1\n")
##	#m1pred=x[np.argmax(mean)]
##	kappa=0
##	m1pred=acq_max()
##	c1=sc.inverse_transform(np.vstack([std,np.append(m1pred,1)]))
##	#c1=MINo+np.vstack([std,np.append(m1pred,1)])*(MAXo-MINo)/SFa
##	
##	np.savetxt(MS,m1pred,fmt='%2.4f',newline="\n",delimiter=",")
##	np.savetxt(MD,c1[-1,0:ndis],fmt='%2.4e',newline="\n",delimiter=",")
##	
##	#UCB Prediction ArgMax
##	US=open('Prediction/UCB-Scaled.csv', 'a')
##	UD=open('Prediction/UCB-Direct.csv', 'a')
##	US.write("# Column : Discripter, Row : target-1 x KappaVariation\n")
##	UD.write("# Column : Discripter, Row : target-1 x KappaVariation\n")
##	kk=np.loadtxt('Kappa.dat',delimiter="\t",dtype = "float")
##	for kappa in kk:
##		US.write("Kappa Variation\n")
##		UD.write("Kappa Variation\n")
##		
##		u1pred=acq_max()
##		c1=sc.inverse_transform(np.vstack([std,np.append(u1pred,1)]))
##		#c1=MINo+np.vstack([std,np.append(m1pred,1)])*(MAXo-MINo)/SFa
##	
##		np.savetxt(US,u1pred,fmt='%2.4f',newline="\n",delimiter=",")
##		np.savetxt(UD,c1[-1,0:ndis],fmt='%2.4e',newline="\n",delimiter=",")
##	
elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
	
#Visualization
#FLAG_novisfrom mpl_toolkits.mplot3d import Axes3D
#FLAG_novisimport plotly.offline as po
#FLAG_novisimport plotly.graph_objects as go
#FLAG_novisimport plotly.figure_factory as ff
#FLAG_novisfrom mayavi import mlab
#FLAG_novis
#FLAG_novisif ndis == 1:
#FLAG_novis
#FLAG_novis  fig = plt.figure(figsize=plt.figaspect(0.5))
#FLAG_novis  mesh=int(1000/args.gpg)
#FLAG_novis  x0=np.linspace(0,1,mesh)
#FLAG_novis  X0 = np.meshgrid(x0)
#FLAG_novis  positions = X0
#FLAG_novis  x = (np.array(positions)).T
#FLAG_novis  #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis  #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis  #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis  #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis  #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis  #h=nd[0,0:2]
#FLAG_novis  clabel=h[1]+'(%)'
#FLAG_novis  
#FLAG_novis  #maxpred,temp = m.predict(m1pred.reshape(-1,1))
#FLAG_novis  #ax1 = fig.add_subplot(1,2,1, aspect='equal')
#FLAG_novis  #scf = ax1.plot(std0,std1,label="Exp",marker="o",color='white',markersize=10,markeredgewidth=3,markeredgecolor='blue',alpha=0.8)
#FLAG_novis  # scf = ax1.plot(m1pred,maxpred,label="MeanPred",marker="^",color='white',markersize=12,markeredgewidth=3,markeredgecolor='red',alpha=0.8)
#FLAG_novis  #scf = ax1.plot(x,mean,'k-',label="mean",color="black",lw=1.5,alpha=0.6)
#FLAG_novis  #ax1.set_title("Mean,Exp(o),MeanPred", fontsize=15)
#FLAG_novis  #ax1.set_xlabel(h[0], fontsize=20)
#FLAG_novis  #ax1.set_ylabel(clabel, fontsize=20)
#FLAG_novis  #ax1.set_xlim(-0.1,1.1)
#FLAG_novis  #ax1.set_ylim(-0.1,1.1)
#FLAG_novis  
#FLAG_novis  kappa=args.kf
#FLAG_novis  #u1pred=acq_max()
#FLAG_novis  #maxpred, sigpred = m.predict(u1pred.reshape(-1,1))
#FLAG_novis  upr=mean+args.kf*sigma.reshape(-1,1)
#FLAG_novis  btr=mean-args.kf*sigma.reshape(-1,1)
#FLAG_novis  ax2 = fig.add_subplot(1,2,2, aspect='equal')
#FLAG_novis  scf = ax2.plot(std0,std1,label="Exp",marker="o",color='white',markersize=10,markeredgewidth=3,markeredgecolor='blue',alpha=0.8)
#FLAG_novis  #scf = ax2.plot(u1pred,maxpred+sigpred*kappa,label="UCBPred",marker="^",color='white',markersize=12,markeredgewidth=3,markeredgecolor='red',alpha=0.8)
#FLAG_novis  scf = ax2.plot(x,mean,'k-',label="mean",color="black",lw=1.5,alpha=0.6)
#FLAG_novis  scf = ax2.fill_between(x.ravel(), upr.ravel(), btr.ravel(), alpha=0.5)
#FLAG_novis  ax2.set_title("Mean,UCB,UCBPred", fontsize=15)
#FLAG_novis  ax2.set_xlabel(h[0], fontsize=20)
#FLAG_novis  ax2.set_ylabel(clabel, fontsize=20)
#FLAG_novis  ax2.set_xlim(-0.1,1.1)
#FLAG_novis  ax2.set_ylim(-0.1,1.1)
#FLAG_novis
#FLAG_novis	
#FLAG_noviselif ndis == 2:
#FLAG_novis
#FLAG_novis  fig = plt.figure(figsize=plt.figaspect(0.5))
#FLAG_novis  mesh=int(200/args.gpg)
#FLAG_novis  x0 = np.linspace(0, 1, mesh)
#FLAG_novis  x1 = np.linspace(0, 1, mesh)
#FLAG_novis  X,Y = np.meshgrid(x0,x1)
#FLAG_novis  positions = np.vstack([X.ravel(),Y.ravel()])
#FLAG_novis  x = (np.array(positions)).T
#FLAG_novis  #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis  #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis  #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis  #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis  #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis  #h=nd[0,0:3]
#FLAG_novis  clabel=h[2]+'(%)'
#FLAG_novis  
#FLAG_novis  Z=mean.reshape(mesh,mesh)
#FLAG_novis  #maxpred, temp = m.predict(m1pred.reshape(-1,1).T)
#FLAG_novis  ax = fig.add_subplot(1,2,1, projection='3d')
#FLAG_novis  #scf = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAG_novis  scf = ax.scatter(d_data[:,0], d_data[:,1], std1,label="Exp",marker="o",edgecolor='b',c='white',s=60)
#FLAG_novis  scf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=args.colormap, linewidth=0.3)
#FLAG_novis  ax.set_title("Mean", fontsize=15)
#FLAG_novis  ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis  ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis  ax.set_zlabel(clabel, fontsize=20)
#FLAG_novis  ax.set_xlim(-0.1,1.1)
#FLAG_novis  ax.set_ylim(-0.1,1.1)
#FLAG_novis  ax.set_zlim(-0.1,1.1)
#FLAG_novis  
#FLAG_novis  ucb=mean+sigma.reshape(-1,1)*args.kf
#FLAG_novis  Z=ucb.reshape(mesh,mesh)
#FLAG_novis  kappa=args.kf
#FLAG_novis  #u1pred=acq_max()
#FLAG_novis  #maxpred, sigpred = m.predict(u1pred.reshape(-1,1).T)
#FLAG_novis ax = fig.add_subplot(1,2,2, projection='3d')
#FLAG_novis  #scf = ax.scatter(u1pred[0], u1pred[1], maxpred+sigpred*kappa,label="UCBPred",marker="^",edgecolor='r',c='white',s=200)
#FLAG_novis  scf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=args.colormap, linewidth=0.3)
#FLAG_novis  ax.set_title("UCB(Kappa=5)", fontsize=15)
#FLAG_novis  ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis  ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis  ax.set_zlabel(clabel, fontsize=20)
#FLAG_novis  ax.set_xlim(-0.1,1.1)
#FLAG_novis  ax.set_ylim(-0.1,1.1)
#FLAG_novis  ax.set_zlim(-0.1,1.1)
#FLAG_novis
#FLAG_noviselif ndis == 3:
#FLAG_novis  #h=nd[0,0:4]
#FLAG_novis  clabel=h[3]+'(%)'
#FLAG_novis  #if args.figmlab is True:	
#FLAG_novis  #mesh=int(100/args.gpg)
#FLAG_novis  mesh=20
#FLAG_novis  x0 = np.linspace(0, 1, mesh)
#FLAG_novis  x1 = np.linspace(0, 1, mesh)
#FLAG_novis  x2 = np.linspace(0, 1, mesh)
#FLAG_novis  X,Y,Z = np.meshgrid(x0,x1,x2)
#FLAG_novis  positions = np.vstack([X.ravel(),Y.ravel(),Z.ravel()])
#FLAG_novis  x = (np.array(positions)).T
#FLAG_novis  #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis  #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis  #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis  #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis  #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis  
#FLAG_novis  Sv=mean.reshape(mesh,mesh,mesh)
#FLAG_novis  
#FLAG_novis  mlab.figure(1, bgcolor=(1, 1, 1), fgcolor=(0, 0, 0), size=(600, 400))
#FLAG_novis  
#FLAG_novis  mlab.contour3d(Sv, colormap='jet', contours=20, transparent=True, opacity=0.8)
#FLAG_novis  #ss1=mlab.pipeline.image_plane_widget(mlab.pipeline.scalar_field(Sv),plane_orientation='x_axes',slice_index=10,)
#FLAG_novis  #ss2=mlab.pipeline.image_plane_widget(mlab.pipeline.scalar_field(Sv),plane_orientation='y_axes',slice_index=10,)
#FLAG_novis
#FLAG_novis  if args.figsurf is True:	
#FLAG_novis    mesh=int(100/args.gpg)
#FLAG_novis    x0 = np.linspace(0, 1, mesh)
#FLAG_novis    x1 = np.linspace(0, 1, mesh)
#FLAG_novis    x2 = np.linspace(0, 1, mesh)
#FLAG_novis    X,Y,Z = np.meshgrid(x0,x1,x2)
#FLAG_novis    positions = np.vstack([X.ravel(),Y.ravel(),Z.ravel()])
#FLAG_novis    x = (np.array(positions)).T
#FLAG_novis    #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis    #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis    #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis    #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis    Sv=mean.reshape(mesh,mesh,mesh)
#FLAG_novis    
#FLAG_novis    fig1 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#FLAG_novis    #fig1 = go.Figure(data=go.Scatter3d(x=std[:,0], y=std[:,1], z=std[:,2], mode='markers',marker=dict(size=std[0,3]*1000,color=std[0,3]*1000,colorscale='Viridis')))
#FLAG_novis    fig1.add_trace(go.Volume(
#FLAG_novis    #fig1 = go.Figure(data=go.Volume(
#FLAG_novis    x=X.flatten(),
#FLAG_novis    y=Y.flatten(),
#FLAG_novis    z=Z.flatten(),
#FLAG_novis    value=Sv.flatten(),
#FLAG_novis    #isomin=0.5,
#FLAG_novis    isomin=0.0,
#FLAG_novis    isomax=0.5,
#FLAG_novis    opacity=0.6, # needs to be small to see through all surfaces
#FLAG_novis    surface_count=6, # needs to be a large number for good volume rendering
#FLAG_novis    ))
#FLAG_novis
#FLAG_novis    fig1.update_layout(scene = dict(xaxis_title=h[0], yaxis_title=h[1], zaxis_title=h[2]))
#FLAG_novis    
#FLAG_novis    #fig1 = go.Figure(data=go.Scatter3d(x=std0[0], y=std0[1], z=std0[2], mode='markers'))	
#FLAG_novis    
#FLAG_novis    po.plot(fig1, filename = 'Plotly-Sulf-Down', auto_open=False)
#FLAG_novis    
#FLAG_novis    fig2 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#FLAG_novis    fig2.add_trace(go.Volume(
#FLAG_novis        x=X.flatten(),
#FLAG_novis        y=Y.flatten(),
#FLAG_novis        z=Z.flatten(),
#FLAG_novis        value=Sv.flatten(),
#FLAG_novis        isomin=0.5,
#FLAG_novis        isomax=1.0,
#FLAG_novis        opacity=0.6, # needs to be small to see through all surfaces
#FLAG_novis        surface_count=6, # needs to be a large number for good volume rendering
#FLAG_novis        ))
#FLAG_novis    
#FLAG_novis    fig2.update_layout(scene = dict(
#FLAG_novis                xaxis_title=h[0],
#FLAG_novis                yaxis_title=h[1],
#FLAG_novis                zaxis_title=h[2]))
#FLAG_novis    
#FLAG_novis    po.plot(fig2, filename = 'Plotly-Surf-UP', auto_open=False)
#FLAG_novis  
#FLAG_novis  
#FLAG_novis  if args.figscat is True:	
#FLAG_novis    fig = plt.figure(figsize=plt.figaspect(1))
#FLAG_novis    mesh=int(100/args.gpg)
#FLAG_novis    x0 = np.linspace(0, 1, mesh)
#FLAG_novis    x1 = np.linspace(0, 1, mesh)
#FLAG_novis    x2 = np.linspace(0, 1, mesh)
#FLAG_novis    X,Y,Z = np.meshgrid(x0,x1,x2)
#FLAG_novis    positions = np.vstack([X.ravel(),Y.ravel(),Z.ravel()])
#FLAG_novis    x = (np.array(positions)).T
#FLAG_novis    #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis    #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis    #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis    #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis    
#FLAG_novis    ax = fig.add_subplot(1,1,1, projection='3d')
#FLAG_novis    #ax = fig.add_subplot(1,3,1, projection='3d')
#FLAG_novis    scf = ax.scatter3D(x_train[:,0], x_train[:,1], x_train[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=y_train*100)
#FLAG_novis    scf = ax.scatter3D(x_test[:,0], x_test[:,1], x_test[:,2],label="Exp",marker="^",edgecolor='g',c='white',s=y_test*100)
#FLAG_novis     scf = ax.scatter3D(x_train[0], x_train[1], x_train[2],label="Exp",marker="o",edgecolor='b',c='white',s=-(y_train1-1)*100)
#FLAG_novis    ax.set_title("Exp", fontsize=15)
#FLAG_novis    ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis    ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis    ax.set_zlabel(h[2], fontsize=20)
#FLAG_novis    ax.set_xlim(-0.1,1.1)
#FLAG_novis    ax.set_ylim(-0.1,1.1)
#FLAG_novis    ax.set_zlim(-0.1,1.1)
#FLAG_novis    
#FLAG_novis    #Sv=mean.reshape(mesh,mesh,mesh)
#FLAG_novis    #maxpred, test = m.predict(m1pred.reshape(-1,1).T)
#FLAG_novis    #ax = fig.add_subplot(1,3,2, projection='3d')
#FLAG_novis    #scf = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAG_novis    #scf = ax.scatter3D(X, Y, Z, s=Sv*100, c=Sv, cmap=args.colormap, linewidth=0.3)
#FLAG_novis    #ax.set_title("Mean", fontsize=15)
#FLAG_novis    #ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis    #ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis    #ax.set_zlabel(h[2], fontsize=20)
#FLAG_novis    #ax.set_xlim(-0.1,1.1)
#FLAG_novis    #ax.set_ylim(-0.1,1.1)
#FLAG_novis    #ax.set_zlim(-0.1,1.1)
#FLAG_novis    #
#FLAG_novis    #ucb=mean+sigma.reshape(-1,1)*args.kf
#FLAG_novis    #Sv=ucb.reshape(mesh,mesh,mesh)
#FLAG_novis    #kappa=args.kf
#FLAG_novis    #u1pred=acq_max()
#FLAG_novis    #maxpred, sigpred = m.predict(u1pred.reshape(-1,1).T)
#FLAG_novis    #ax = fig.add_subplot(1,3,3, projection='3d')
#FLAG_novis    #scf = ax.scatter(u1pred[0], u1pred[1], maxpred+sigpred*kappa,label="UCBPred",marker="^",edgecolor='r',c='white',s=200)
#FLAG_novis    #scf = ax.scatter3D(X, Y, Z, s=Sv*100, c=Sv, cmap=args.colormap, linewidth=0.3)
#FLAG_novis    #ax.set_title("UCB(Kappa=5)", fontsize=15)
#FLAG_novis    #ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis    #ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis    #ax.set_zlabel(h[2], fontsize=20)
#FLAG_novis    #ax.set_xlim(-0.1,1.1)
#FLAG_novis    #ax.set_ylim(-0.1,1.1)
#FLAG_novis  
#FLAG_novis  if args.figtri is True:	
#FLAG_novis    xpre=[0,0,0]
#FLAG_novis    mesh=int(100/args.gpg)
#FLAG_novis    for i in range(0,101,mesh):
#FLAG_novis    	for j in range(0,101,mesh):
#FLAG_novis    		k=100-i-j
#FLAG_novis    		if(i+j+k==100 and k>=0):
#FLAG_novis    			xpre=np.vstack([xpre,[k/100,i/100,j/100]])
#FLAG_novis    x=xpre[1:,:]
#FLAG_novis    #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAG_novis    #FLAGGP_GPymean, sigma = m.predict(x)
#FLAG_novis    #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAG_novis    #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis    fig3 = ff.create_ternary_contour(x.T,
#FLAG_novis                      mean.reshape(-1,),
#FLAG_novis                     pole_labels=h[0:3], interp_mode='cartesian', showmarkers=True)
#FLAG_novis    po.plot(fig3, filename = 'Plotly-Trinary', auto_open=False)
#FLAG_novis
#FLAG_noviselif ndis > 3:
#FLAG_novis
#FLAG_novis  NPC=2
#FLAG_novis  d_data, h, decomp, scc = dPCA(std0.T, std1.T, NPC)
#FLAG_novis  if 2 <= NPC <= 3:
#FLAG_novis  	fig = plt.figure(figsize=plt.figaspect(1))
#FLAG_novis  if NPC == 2:
#FLAG_novis  	ax = fig.add_subplot(1,1,1)
#FLAG_novis  	scf = ax.scatter(d_data[:,0], d_data[:,1],label="Exp",marker="o",edgecolor='r',c='white',s=std1.T*100)
#FLAG_novis  elif NPC == 3:
#FLAG_novis  	ax = fig.add_subplot(1,1,1, projection='3d')
#FLAG_novis  	scf = ax.scatter3D(d_data[:,0], d_data[:,1], d_data[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=std1.T*100)
#FLAG_novis  if 2 <= NPC <= 3:
#FLAG_novis  	ax.set_title("PCA visual", fontsize=15)
#FLAG_novis
#FLAG_novis  fig = plt.figure(figsize=plt.figaspect(1))
#FLAG_novis  mesh=int(200/args.gpg)
#FLAG_novis  x0 = np.linspace(0, 1, mesh)
#FLAG_novis  x1 = np.linspace(0, 1, mesh)
#FLAG_novis  X,Y = np.meshgrid(x0,x1)
#FLAG_novis  positions = np.vstack([X.ravel(),Y.ravel()])
#FLAG_novis  x = (np.array(positions)).T
#FLAG_novis  Xscc = scc.inverse_transform(x)
#FLAG_novis  Xscc = scc.inverse_transform(x)
#FLAG_novis  Xd = decomp.inverse_transform(Xscc)
#FLAG_novis  #FLAGGP_Skitmean, sigma = m.predict(Xd, return_std=True)
#FLAG_novis  #FLAGGP_GPymean, sigma = m.predict(Xd)
#FLAG_novis  #FLAGGP_GPflowmean, sigma = m.predict_f(Xd)
#FLAG_novis  #FLAGGP_GPflowmean=mean.numpy()
#FLAG_novis  #FLAGGP_GPflowsigma=sigma.numpy()
#FLAG_novis  #h=nd[0,0:3]
#FLAG_novis  clabel=h[2]+'(%)'
#FLAG_novis  
#FLAG_novis  Z=mean.reshape(mesh,mesh)
#FLAG_novis  #maxpred, temp = m.predict(m1pred.reshape(-1,1).T)
#FLAG_novis  ax = fig.add_subplot(1,1,1, projection='3d')
#FLAG_novis  #sc = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAG_novis  sc = ax.scatter(d_data[:,0], d_data[:,1], std1,label="Exp",marker="o",edgecolor='b',c='white',s=60)
#FLAG_novis  sc = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=args.colormap, linewidth=0.3)
#FLAG_novis  ax.set_title("Mean", fontsize=15)
#FLAG_novis  ax.set_xlabel(h[0], fontsize=20)
#FLAG_novis  ax.set_ylabel(h[1], fontsize=20)
#FLAG_novis  ax.set_zlabel(clabel, fontsize=20)
#FLAG_novis  ax.set_xlim(-0.1,1.1)
#FLAG_novis  ax.set_ylim(-0.1,1.1)
#FLAG_novis  ax.set_zlim(-0.1,1.1)
#FLAG_novis
#FLAG_novisplt.tight_layout()
#FLAG_novisplt.show()


#FALG_griddatamesh=int(100/args.gpg)
#FALG_griddata#FLAG2
#FALG_griddata#FLAG3
#FALG_griddataSXMAP = np.meshgrid(SxMAP)
#FALG_griddata#FLAG4
#FALG_griddataif ndis == 1:
#FALG_griddata	positions = SXMAP
#FALG_griddataelse:
#FALG_griddata	positions = np.vstack([RAVELMAP])
#FALG_griddatax = (np.array(positions)).T
#FALG_griddata#FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FALG_griddata#FLAGGP_GPymean, sigma = m.predict(x)
#FALG_griddata#FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FALG_griddata#FLAGGP_GPflowmean=mean.numpy()
#FALG_griddata#FLAGGP_GPflowsigma=sigma.numpy()
#FALG_griddata		
#FALG_griddatamZ=mean.reshape(FLAG6)
#FALG_griddatasZ=sigma.reshape(FLAG6)
#FALG_griddatanp.savetxt('mean.dat',mZ)
#FALG_griddatanp.savetxt('sigma.dat',sZ)
  
exit()
