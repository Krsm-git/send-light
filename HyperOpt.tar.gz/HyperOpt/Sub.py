import pandas as pd

sub = pd.read_csv('sub-all1.csv')

sub.to_csv('submission.csv',index=False)


