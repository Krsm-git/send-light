import xlrd
import numpy as np
import pandas as pd
import warnings

warnings.simplefilter('ignore')


df=pd.read_excel('FLAG1', header=None, index_col=None)
nd=df.values
dat=nd[1:,:]

ntar=1
k=dat.shape
ndis=k[1]-1

print(ndis)

