import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import xlrd
from tqdm import tqdm

#df=pd.read_excel('train_Ehull.xlsx')
df=pd.read_excel('train_Ehull-1918-70.xlsx')
#df=df[df['EH'] < 400]
#dis=np.loadtxt("dis.dat")
h=df.iloc[:,1:].columns.values
#h=df.iloc[:,dis].columns.values
#h=np.append(h,'EH')
nd=df.loc[:,h].values
#dff=df.loc[:,h]
#dff.to_excel('train_Ehull-1918-70.xlsx')
#exit()
dat=nd[:,:]
ntar=1
k=dat.shape
ndis=k[1]-1
nsam=k[0]

sc=StandardScaler()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))

AdEUC = np.empty(0)	
ADEL = np.empty(0)	
AADEL = np.empty(0)	
idi = np.empty(0)	
#di=1450
#di=99
#di=1445
dsta=63
dend=64
#dend=nsam
for di in range(dsta, dend, 1):
  for eu in range(0, nsam, 1):
    if not eu == di:
      #print(eu)
      #print(nd[eu,-1])
      EUC = np.abs(std0.T[eu,:] - std0.T[di,:])
      dEUC = np.linalg.norm(EUC)
      if not dEUC == 0:
        #print("Eucrid Distance: {}".format(dEUC))
        idi = np.append(idi, eu)
        AdEUC = np.append(AdEUC, dEUC)
        TAR = np.abs(std1.T[eu] - std1.T[di])
        DEL = TAR / dEUC
        ADEL = np.append(ADEL, DEL)
  #AADEL = np.append(AADEL,ADEL.max())
  #ADELs = sorted(ADEL, reverse=True)
  AdEUCs = np.argsort(AdEUC)
  print(di)
  print(idi[AdEUCs[:3]])
  print(AdEUC[AdEUCs[:3]])
  print(ADEL[AdEUCs[:3]])
  ADEL = np.empty(0)	
  AADEL = np.empty(0)	
  AdEUC = np.empty(0)	
  idi = np.empty(0)	
#
##df = pd.DataFrame(AdEUC)
##df = pd.DataFrame(ADEL)
#df = pd.DataFrame(AADEL)
#print(df.describe())
#print(df.sort_values(0))
##with open('AADEL.txt', 'a') as f:
##  print(AADEL, file=f)
