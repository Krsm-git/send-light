import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
#FLAGMPIfrom mpi4py import MPI
#FLAGMPIcomm = MPI.COMM_WORLD
#FLAGMPIrank = comm.Get_rank()
#FLAGMPIsize = comm.Get_size()
fmpi = 1
#FLAGMPIfmpi = 0

warnings.simplefilter('ignore')

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

start = time.time()

#df=pd.read_excel('FLAG1', header=None, index_col=None).replace('male',0).replace('female',1).replace('C',0).replace('S',1).replace('Q',2)
#df=pd.read_excel('FLAG1', header=None, index_col=None)
dfo=pd.read_csv('train_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dft=pd.read_csv('test_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

tk=dft.shape
tdis=tk[1]-1
tsam=tk[0]

Amean_test=[]
#Amean_test=np.empty((tsam,1),dtype=np.float64)
#for im in range(0,2):
for im in range(0,mdis):
  dfc=pd.concat([dfo,dfs.iloc[:,im+1]], axis=1)
  df=dfc.iloc[:,1:]
  
  h=df.columns.values
  print("Target Name: {}".format(h[-1]))
  nd=df.loc[:,h].values
  dat=nd[:,:]
  
  ntar=1
  k=dat.shape
  ndis=k[1]-1
  nsam=k[0]

  #--Test--#
  ndt=dft.loc[:,h[0:-1]].values
  x=np.array([0]*tsam)
  datt=np.hstack([ndt[:,:],x.reshape(-1,1)])
  ttar=1
 
  MINo=np.min(dat[1:,:], axis=0)
  MAXo=np.max(dat[1:,:], axis=0)
  dat=np.vstack([dat,MINo])
  dat=np.vstack([dat,MAXo])
  
  #sc=MinMaxScaler()
  sc=StandardScaler()
  #sc=QuantileTransformer()
  std=sc.fit_transform(dat)
  std0o=std.T[0:ndis]
  std1o=std.T[ndis:ndis+ntar]
  std0,MMi=np.split(std0o,[nsam],1)
  std1,temp=np.split(std1o,[nsam],1)
  
  #--Test--# 
  stdt=sc.transform(datt)
  stdt0o=stdt.T[0:tdis]
  stdt1o=stdt.T[tdis:tdis+ttar]
  stdt0,MMit=np.split(stdt0o,[tsam],1)
  stdt1,tempt=np.split(stdt1o,[tsam],1)
  
  print("|-----------------------|")
  print("|--Parameter Dimension--|")
  print("|-----------------------|")
  print("Sample: {}".format(nsam))
  print("Discripter: {}".format(ndis))
  print("Target: {}".format(ntar))
  print("Test Sample: {}".format(tsam))
  	
  if ndis >= 2:
  	MMs=MMi.T
  else:
  	MMs=MMi.reshape(-1,1)
  
  pndis=ndis
  x_train=std0.T	
  y_train=std1.T	
  x_test=stdt0.T
  
  mean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
  nmean_train = np.array(mean_train)
  nmean_test = np.array(mean_test)
  mean_train = nmean_train.reshape(-1,1)
  mean_test = nmean_test.reshape(-1,1)
  
  R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
  Rmean_test=sc.inverse_transform(R2)
  Amean_test.append(Rmean_test[:,pndis])
  #np.append(Amean_test, Rmean_test[:,pndis])

temp=np.array(Amean_test)
Amean_test=temp.T
print(Amean_test)
print(Amean_test.shape)

sh=dfs.iloc[:,1:mdis+1].columns
#sh=dfs.iloc[:,1:].columns
si=dft.iloc[:,0]
spd=pd.DataFrame(data=Amean_test,index=None,columns=sh,dtype='float')
sub=pd.concat([si,spd],axis=1)
print(sub.shape)
sub.to_csv('submission.csv',index=None)

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
