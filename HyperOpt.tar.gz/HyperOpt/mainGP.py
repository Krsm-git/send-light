import os
import xlrd
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
#FLAGMPIfrom mpi4py import MPI
#FLAGMPIcomm = MPI.COMM_WORLD
#FLAGMPIrank = comm.Get_rank()
#FLAGMPIsize = comm.Get_size()
fmpi = 1
#FLAGMPIfmpi = 0

warnings.simplefilter('ignore')

def acq_max(n_warmup=10000, n_iter=10):
	from scipy.optimize import minimize
	# Warm up with random points
	x_tries = np.random.uniform(0, 1, size=(n_warmup, ndis))
	ys = ac(x_tries)
	x_max = x_tries[ys.argmax()]
	max_acq = ys.max()
	# Explore the parameter space more throughly
	x_seeds = np.random.uniform(0, 1, size=(n_iter, ndis))
	for x_try in x_seeds:
	    # Find the minimum of minus the acquisition function
	    res = minimize(lambda x: -ac(x.reshape(1, -1)),
	                   x_try.reshape(1, -1),
	                   bounds=MMs.T,
	                   method="L-BFGS-B")
	    # See if success
	    if not res.success:
	        continue
	    # Store it if better than previous minimum(maximum).
	    if max_acq is None or -res.fun[0] >= max_acq:
	        x_max = res.x
	        max_acq = -res.fun[0]
	# Clip output to make sure it lies within the bounds. Due to floating
	# point technicalities this is not always the case.
	return np.clip(x_max, MMs.T[:, 0], MMs.T[:, 1])

def ac(x):
	mean,sigma = m.predict(x)
	#FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
	#FLAGGP_GPymean, sigma = m.predict(x)
	#FLAGGP_GPflowmean, sigma = m.predict_f(x)
	#FLAGGP_GPflowmean=mean.numpy()
	#FLAGGP_GPflowsigma=sigma.numpy()
	ucb=mean+sigma.reshape(-1,1)*kappa
	return ucb

def g(x):
	optimizer = GaussianProcessRegressor(alpha=x,kernel=kernel,n_restarts_optimizer=5,random_state=1)
	optimizer.fit(std0.T,std1.T)
	print(x)
	print(-(optimizer.log_marginal_likelihood()))
	return (-(optimizer.log_marginal_likelihood()))

def ET_Skit(x_train, y_train, x_test): 
	from sklearn.ensemble import BaggingRegressor
	from sklearn.tree import ExtraTreeRegressor
	extra_tree = ExtraTreeRegressor(random_state=1)
	m = BaggingRegressor(extra_tree, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def RF_Skit(x_train, y_train, x_test): 
	from sklearn.ensemble import RandomForestRegressor
	m = RandomForestRegressor(random_state=1)
	#m = RandomForestRegressor(max_depth=2, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def KRR_Skit(x_train, y_train, x_test): 
	from sklearn.kernel_ridge import KernelRidge
	#m = KernelRidge(kernel='rbf')
	m = KernelRidge(kernel='rbf', alpha=0.007, gamma=0.007)
	m.fit(x_train,y_train)
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def GP_George(x_train, y_train, x_test): 
	import george
	from george import kernels
	#kernel=kernels.RationalQuadraticKernel(ndim=ndis)
	kernel=kernels.ExpSquaredKernel(0.5, ndim=ndis)
	#kernel=kernels.RationalQuadraticKernel(ndim=ndis,metric=1,alpha=1)
	m = george.GP(kernel,random_state=1, white_noise=1E-2)
	#m = george.GP(kernel, solver=george.HODLRSolver)
	yerr = np.ones_like(y_train)
	m.compute(x_train, yerr)
	print("Log Marginal Likelihood: {}".format(m.lnlikelihood(y_train, quiet=True)))
	#print(m.kernel_.hyperparameters)
	#print("Hyperparameters: {}".format(m.kernel_.theta))
	mean_train, sigma = m.predict(y_train, x_train, return_var=True)
	mean_test, sigma = m.predict(y_train, x_test, return_var=True)
	return mean_train, mean_test, m

def GP_Skit(x_train, y_train, x_test): 
	from sklearn.gaussian_process import GaussianProcessRegressor
	from sklearn.gaussian_process import kernels as sk_kern
	#kernel=sk_kern.RBF()
	#kernel=sk_kern.RBF(length_scale=[1]*(ndis))
	#kernel=sk_kern.Matern(nu=2.5,length_scale=[1]*(ndis))
	#kernel=sk_kern.RationalQuadratic(length_scale=1.0, alpha=1.0, length_scale_bounds=(1e-10, 1e+10), alpha_bounds=(1e-10, 1e+10))
	kernel=sk_kern.RationalQuadratic()
	x_min=1E-2
	#m = GaussianProcessRegressor(kernel=kernel,random_state=1)
	#m = GaussianProcessRegressor(alpha=1E-4,kernel=kernel,random_state=1)
	m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,random_state=1)
	#m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,n_restarts_optimizer=5,random_state=1)
	m.fit(x_train,y_train)
	print("Log Marginal Likelihood: {}".format(m.log_marginal_likelihood()))
	print(m.kernel_.hyperparameters)
	print("Hyperparameters: {}".format(m.kernel_.theta))
	mean_train, sigma = m.predict(x_train, return_std=True)
	mean_test, sigma = m.predict(x_test, return_std=True)
	return mean_train, mean_test, m

def GP_GPy(x_train, y_train, x_test): 
	import GPy
	import GPy.kern as gp_kern
	#kern = gp_kern.RBF(input_dim=ndis)
	#kern = gp_kern.RBF(input_dim=ndis, ARD=True)
	kern = gp_kern.sde_RatQuad(input_dim=ndis)
	#kern = gp_kern.sde_RatQuad(input_dim=ndis, ARD=True)
	#kern = gp_kern.RBF(input_dim=ndis, ARD=True) + gp_kern.sde_RatQuad(input_dim=ndis, ARD=True)
	#m = GPy.models.GPRegression(X=x_train, Y=y_train.reshape(-1, 1), kernel=kern)
	m = GPy.models.GPRegression(X=x_train, Y=y_train.reshape(-1, 1), kernel=kern, normalizer=None)
	#m.Gaussian_noise.variance = 1e-2
	#m.Gaussian_noise.variance.fix()
	#m.kern.lengthscale = [1e-0, 1e+1, 1e+5]
	#m.kern.lengthscale.fix()
	#m.kern.lengthscale.constrain_bounded(1e+1,1e+3)
	#m.kern.lengthscale.constrain_fixed(1e-1)
	#m.sum.rbf.lengthscale.constrain_bounded(1e+1,1e+3)
	#m.sum.RatQuad.lengthscale.constrain_bounded(1e+1,1e+3)
	m.Gaussian_noise.variance.constrain_fixed(1e-2)
	
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.sum.rbf.lengthscale)
	#print(m.sum.RatQuad.lengthscale)
	m.optimize()
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.sum.rbf.lengthscale)
	#print(m.sum.RatQuad.lengthscale)
	mean_train, sigma = m.predict(x_train)
	mean_test, sigma = m.predict(x_test)
	return mean_train, mean_test, m

def GP_GPflow(x_train, y_train, x_test): 
	import gpflow
	import tensorflow as tf
	from gpflow.utilities import print_summary
	#k = gpflow.kernels.RationalQuadratic()
	#k = gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis))) + gpflow.kernels.White(variance=1e-10)
	#k = gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	#k = gpflow.kernels.SquaredExponential()
	#k = gpflow.kernels.SquaredExponential(lengthscales=np.array([1]*(ndis)))
	k = gpflow.kernels.ArcCosine()
	#k = gpflow.kernels.ArcCosine(order=2)
	#k = gpflow.kernels.SquaredExponential(lengthscales=np.array([1]*(ndis))) + gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	#k = gpflow.kernels.SquaredExponential() + gpflow.kernels.RationalQuadratic(lengthscales=np.array([1]*(ndis)))
	m = gpflow.models.GPR(data=(x_train, y_train), kernel=k, mean_function=None) 
	#m.likelihood.variance.assign(0.01)
	#m.likelihood.variance.assign(0.001)
	#gpflow.set_trainable(m.likelihood.variance, False)
	#m.kernel.lengthscales.assign(0.3)
	#print_summary(m)
	opt = gpflow.optimizers.Scipy()
	#opt_logs = opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=100))
	#opt_logs = opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=300), method='BFGS')
	opt.minimize(m.training_loss, m.trainable_variables, options=dict(maxiter=300), method='BFGS')
	#print_summary(m)
	mean_train, sigma = m.predict_f(x_train)
	mean_train=mean_train.numpy()
	mean_test, sigma = m.predict_f(x_test)
	mean_test=mean_test.numpy()
	return mean_train, mean_test, m

def dGPLVM(XLVM, YLVM, NPC):
	import GPy
	import GPy.kern as gp_kern
	input_dim = NPC
	#kern = GPy.kern.RBF(input_dim, 1, ARD=True) 
	kern = GPy.kern.sde_RatQuad(input_dim, 1, ARD=True) 
	#m = GPy.models.GPLVM(XLVM, input_dim, kernel=kern)
	#m = GPy.models.bayesian_gplvm_minibatch.BayesianGPLVMMiniBatch(XLVM, input_dim, num_inducing=30, missing_data=True)
	m = GPy.models.bayesian_gplvm_minibatch.BayesianGPLVMMiniBatch(XLVM, input_dim, num_inducing=int(XLVM.shape[0]*XLVM.shape[1]/100), missing_data=True)
	#m.Gaussian_noise.variance.constrain_fixed(1e-2)
	#print(m)
	#print(m.kern.lengthscale)
	m.optimize(messages=1, max_iters=5e+3)
	#print(m)
	#print(m.kern.lengthscale)
	#print(m.X.shape)
	#print(m.X)
	#print(m.X.mean)
	#m.plot_latent()
	#m.plot_scatter(projection='3d')
	#m.plot_steepest_gradient_map()
	#for c in range(0,2):
	#    arg = np.where(std1.T==c)[0]
	#    plt.scatter(m.X.mean[arg, 0], m.X.mean[arg, 1], c='C'+str(c))
	#plt.show()
	dd_data = m.X.mean.values
	scc=MinMaxScaler()
	scc.fit(dd_data)
	d_data=scc.transform(dd_data)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	return d_data, scc


def dPCA(XPCA, YPCA, NPC): 
	from matplotlib.cm import get_cmap
	from sklearn.decomposition import PCA
	from sklearn.decomposition import KernelPCA
	from sklearn.decomposition import FastICA
	from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
	from sklearn.metrics import explained_variance_score
	
	#XPCA=np.hstack([std0.T,std1.T])
	print(XPCA.shape)
	#scsc=StandardScaler()
	#XPCA=scsc.fit_transform(XPCA)
	
	###def customkernel(X1,X2):
	###    from sklearn.metrics.pairwise import rbf_kernel
	###    k = rbf_kernel(X1,X2)
	###    return k
	###decomp = KernelPCA(n_components=3, kernel='precomputed')
	###gram_mat = customkernel(XPCA,XPCA)
	###decomp.fit(gram_mat)
	
	h=[]
	for i in range(1,10,1):
	    h.append("PC" + str(i))
	h.append("TG")
	#h=['PC1','PC2','FE']
	#h=['PC1','PC2','PC3','FE']
	#h=['PC1','PC2','PC3','PC4','FE']
	
	#import umap
	#decomp = umap.UMAP(n_neighbors=5,n_components=NPC).fit(XPCA)
	#decomp = umap.UMAP(n_neighbors=5,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	#decomp = umap.UMAP(n_neighbors=nsam,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	
	#from scipy.optimize import minimize
	#def kPCA(gamma):
	#	print(gamma)
	#	decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma)
	#	decomp.fit(XPCA)
	#	dd_data = decomp.transform(XPCA)
	#	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#	print(evs)
	#	return -evs
	#gam_ini=1.0
	#res = minimize(kPCA,gam_ini)
	#gamma=res.x
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma).fit(XPCA)
	
	#decomp = PCA(n_components=NPC).fit(XPCA)
	decomp = FastICA(n_components=NPC, random_state=0).fit(XPCA)
	#decomp = LDA(n_components=NPC).fit(XPCA, YPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XPCA)
	dd_data = decomp.transform(XPCA)
	evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#evs = np.max(evs_ratio)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Score: {}".format(evs))
	print("Score Ratio: {}".format(evs_ratio))
	print("Shape: {}".format(dd_data.shape))
	scc=MinMaxScaler()
	scc.fit(dd_data)
	d_data=scc.transform(dd_data)
	
	#if 2 <= NPC <= 3:
	#	fig = plt.figure(figsize=plt.figaspect(0.5))
	#if NPC == 2:
	#	ax = fig.add_subplot(1,1,1)
	#	scf = ax.scatter(d_data[:,0], d_data[:,1],label="Exp",marker="o",edgecolor='r',c='white',s=YPCA*100)
	#elif NPC == 3:
	#	ax = fig.add_subplot(1,1,1, projection='3d')
	#	scf = ax.scatter3D(d_data[:,0], d_data[:,1], d_data[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=YPCA*100)
	#if 2 <= NPC <= 3:
	#	ax.set_title("PCA visual", fontsize=15)
	#	plt.show()
	#exit()
	
	return d_data, h, decomp, scc

def dLasso(XLasso, YLasso, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.linear_model import LassoCV
	estimator = LassoCV(normalize=True, cv=10)
	#estimator = LassoCV(normalize=True)
	sfm = SelectFromModel(estimator, threshold=trh)
	sfm.fit(XLasso, YLasso)
	d_data = sfm.transform(XLasso)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Selected Descriptors: {}".format(rlabel[[not x for x in removed_idx]]))
	#print("Removed of Descriptors: {}".format(rlabel[removed_idx]))
	return d_data

def dRFS(XRFS, YRFS, label):
	from sklearn.feature_selection import RFECV
	from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet, SGDRegressor
	from sklearn.linear_model import LassoCV
	from xgboost import XGBRegressor
	from catboost import CatBoostRegressor
	#estimator = Ridge()
	estimator = XGBRegressor()
	#estimator = CatBoostRegressor()
	#estimator = LassoCV(normalize=True, cv=10)

	sfm = RFECV(estimator, step=1, cv=10)
	sfm.fit(XRFS, YRFS)
	d_data = sfm.transform(XRFS)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Selected Descriptors: {}".format(rlabel[[not x for x in removed_idx]]))
	#print("Removed  Descriptors: {}".format(rlabel[removed_idx]))
	return d_data

def dTree(XTree, YTree, NPC, label): 
	from sklearn.ensemble import RandomForestRegressor
	from sklearn.ensemble import BaggingRegressor
	from sklearn.tree import ExtraTreeRegressor
	#extra_tree = ExtraTreeRegressor(random_state=1)
	#m = BaggingRegressor(extra_tree, random_state=1)
	m = RandomForestRegressor(random_state=1)
	#m = RandomForestRegressor(max_depth=2, random_state=1)
	m.fit(XTree,YTree)
	print("RF Score: {}".format(m.score(XTree,YTree)))
	print("Hyperparameters: {}".format(m.get_params()))
	fi = m.feature_importances_
	tfi = np.argsort(fi)[::-1]
	d_data = XTree[:,tfi[:NPC]]
	rlabel = label[tfi[:NPC]]
	return d_data, rlabel

def FI_Skit(x_train, y_train, h): 
	from sklearn.ensemble import RandomForestRegressor
	from sklearn.ensemble import BaggingRegressor
	from sklearn.tree import ExtraTreeRegressor
	extra_tree = ExtraTreeRegressor(random_state=1)
	m = BaggingRegressor(extra_tree, random_state=1)
	#m = RandomForestRegressor(random_state=1)
	#m = RandomForestRegressor(max_depth=2, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	fi = m.feature_importances_
	np.savetxt("FI.dat",fi)
	#for i, feat in enumerate(h[:-2]):
	#  print('\t{} : {}'.format(feat, fi[i]))
	return mean_train, m, fi

start = time.time()

#df=pd.read_excel('FLAG1', header=None, index_col=None).replace('male',0).replace('female',1).replace('C',0).replace('S',1).replace('Q',2)
#df=pd.read_excel('FLAG1', header=None, index_col=None)
dfo=pd.read_csv('FLAG1').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dfc=pd.concat([dfo,dfs.iloc[:,1]], axis=1)
df=dfc.iloc[:,1:]
print(df.describe())

#df=df[df['EH'] < 400]

#edis=np.loadtxt("fedis.dat", dtype='int')
#edis=np.loadtxt("edis.dat", dtype='int')
#df=df.drop(df.index[edis])
#print(df.iloc[edis[-5],71])
#exit()

#dis=np.loadtxt("dis.dat")
#dis=np.loadtxt("dis-ef.dat")

h=df.columns.values
#h=df.iloc[:,1:].columns.values
#h=df.iloc[:,dis].columns.values
#h=np.append(h,'EH')
#h=np.append(h,'EF')
#h=df.iloc[:,2:].columns.values
#h=df.iloc[:,1:].columns.values
#h=['HF','OS','TF','FE']
#h=['HF','TF','FE']
#h=['AB','LT','PD','FM','FE']
#h=['HF','OS','TF','AB','LT','PD','FM','FE']
#print(h)
#print(h.shape)
#exit()

nd=df.loc[:,h].values

dat=nd[:,:]
#dat=nd[1:,1:]

ntar=1
k=dat.shape
ndis=k[1]-1
nsam=k[0]

#FLAG_MM1nsam=nsam-2
#FLAG_MM1MINo=dat[nsam,:]
#FLAG_MM1MAXo=dat[nsam+1,:]

#FLAG_MM2MINo=np.min(dat[1:,:], axis=0)
#FLAG_MM2MAXo=np.max(dat[1:,:], axis=0)
#FLAG_MM2dat=np.vstack([dat,MINo])
#FLAG_MM2dat=np.vstack([dat,MAXo])

#sc=MinMaxScaler()
sc=StandardScaler()
#sc=QuantileTransformer()
std=sc.fit_transform(dat)
std0o=std.T[0:ndis]
std1o=std.T[ndis:ndis+ntar]
std0,MMi=np.split(std0o,[nsam],1)
std1,temp=np.split(std1o,[nsam],1)

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))
	
if ndis >= 2:
	MMs=MMi.T
else:
	MMs=MMi.reshape(-1,1)

d_data=std0.T
#NPC=70
#d_data, h = dTree(XTree=std0.T, YTree=std1.T, NPC=NPC, label=h)
#d_data, h = dPCA(XPCA=std0.T, YPCA=std1.T, NPC=NPC)
#d_data = dLasso(XLasso=std0.T, YLasso=std1.T, trh=1e-10, label=h)
#d_data, h, decomp, scc = dPCA(XPCA=std0.T, YPCA=std1.T, NPC=NPC)
#d_data = dRFS(XRFS=std0.T, YRFS=std1.T, label=h)
#d_data, scc = dGPLVM(XLVM=std0.T, YLVM=std1.T, NPC=10)
  
#mean_train, m, FI = FI_Skit(std0.T, std1.T, h)

#x_train = std0.T
#y_train = std1.T
#from sklearn.model_selection import train_test_split
#x_train, x_test, y_train, y_test = train_test_split(d_data, std1.T, test_size=0.1, random_state=1)
pndis=ndis
Armse_train=[]
Armse_test=[]
Alogl_train=[]
Alogl_test=[]
#from sklearn.model_selection import KFold
#kf = KFold(n_splits = 10, shuffle = True)
#for train_index, test_index in kf.split(d_data):
#    x_train, x_test = d_data[train_index], d_data[test_index]
#    y_train, y_test = std1.T[train_index], std1.T[test_index]
from sklearn.model_selection import train_test_split
LRepeat = 1
Lrank = 1
#FLAGMPILrank=rank
LEND = LRepeat * Lrank
for Repeat in range(0, LEND, 1):
  x_train, x_test, y_train, y_test = train_test_split(d_data, std1.T, test_size=0.2, random_state=Repeat)
  #print(x_train.shape)
  #print(y_train.shape)
  #print(x_test.shape)
  #print(y_test.shape)
  
  k=x_train.shape
  nsam=k[0]
  ndis=k[1]
  
  #FLAGET_Skitmean_train, mean_test, m = ET_Skit(x_train, y_train, x_test)
  #FLAGRF_Skitmean_train, mean_test, m = RF_Skit(x_train, y_train, x_test)
  #FLAGNN_Skitmean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
  #FLAGKRR_Skitmean_train, mean_test, m = KRR_Skit(x_train, y_train, x_test)
  #FLAGGP_Skitmean_train, mean_test, m = GP_Skit(x_train, y_train, x_test)
  #FLAGGP_GPymean_train, mean_test, m= GP_GPy(x_train, y_train, x_test)
  #FLAGGP_GPflowmean_train, mean_test, m = GP_GPflow(x_train, y_train, x_test)
  #FLAGGP_Georgemean_train, mean_test, m = GP_George(x_train, y_train, x_test)
  nmean_train = np.array(mean_train)
  nmean_test = np.array(mean_test)
  mean_train = nmean_train.reshape(-1,1)
  mean_test = nmean_test.reshape(-1,1)
  
  ##Prediction Score
  from sklearn.metrics import mean_squared_error
  from sklearn.metrics import r2_score
  print("|-----------------------|")
  print("|------Train Score------|")
  print("|-----------------------|")
  #rmse = np.sqrt(mean_squared_error(mean_train, y_train))
  #print("Mean Squared Error : {0:.4%}".format(rmse))
  R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
  Ry_train=sc.inverse_transform(R2)
  R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
  Rmean_train=sc.inverse_transform(R2)
  #Rrmse_train = np.sqrt(mean_squared_error(Rmean_train[:,pndis], Ry_train[:,pndis]))
  #print("Mean Squared Error (Real): {0:.4f}".format(float(Rrmse_train)))
  #r2s = r2_score(Rmean_train, Ry_train)
  #print("R2 Score: {}".format(r2s))
  p1=Rmean_train[:,pndis]
  p2=1-Rmean_train[:,pndis]
  pp1=np.where(p1 < 1E-15,1E-15,p1)
  pp2=np.where(p2 < 1E-15,1E-15,p2)
  logl_train = -np.mean(Ry_train[:,pndis]*np.log(pp1)+(1-Ry_train[:,pndis])*np.log(pp2))
  print("Log Loss: {}".format(logl_train))
  
  ##Correlation Matrix
  #print(np.corrcoef(std.transpose()))
  
  ##Test Score according to TrainData
  print("|-----------------------|")
  print("|------Test Score-------|")
  print("|-----------------------|")
  #rmse = np.sqrt(mean_squared_error(mean_test, y_test))
  #print("Mean Squared Error : {0:.4%}".format(rmse))
  R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
  Ry_test=sc.inverse_transform(R2)
  R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
  Rmean_test=sc.inverse_transform(R2)
  #Rrmse_test = np.sqrt(mean_squared_error(Rmean_test[:,pndis], Ry_test[:,pndis]))
  #print("Mean Squared Error (Real): {0:.4f}".format(float(Rrmse_test)))
  #r2s = r2_score(Rmean_test, Ry_test)
  #print("R2 Score: {}".format(r2s))
  p1=Rmean_test[:,pndis]
  p2=1-Rmean_test[:,pndis]
  pp1=np.where(p1 < 1E-15,1E-15,p1)
  pp2=np.where(p2 < 1E-15,1E-15,p2)
  logl_test = -np.mean(Ry_test[:,pndis]*np.log(pp1)+(1-Ry_test[:,pndis])*np.log(pp2))
  print("Log Loss: {}".format(logl_test))
  
  ##Parity Plot
  #FLAGPPfont_axis_publish = {
  #FLAGPP        'color':  'black',
  #FLAGPP        'weight': 'bold',
  #FLAGPP        'size': 22,
  #FLAGPP        }
  #FLAGPPplt.rcParams['ytick.labelsize'] = 16
  #FLAGPPplt.rcParams['xtick.labelsize'] = 16
  #FLAGPP# Plot Figures
  #FLAGPPfignow = plt.figure(figsize=(8,8))
  #FLAGPPx1 =    Ry_train[:,pndis] 
  #FLAGPPy1 = Rmean_train[:,pndis]
  #FLAGPPx2 =     Ry_test[:,pndis]
  #FLAGPPy2 =  Rmean_test[:,pndis]
  #FLAGPP## find the boundaries of X and Y values
  #FLAGPPbounds1 = np.array([min(x1.min(), y1.min()) - int(0.1 * y1.min()), max(x1.max(), y1.max())+ int(0.1 * y1.max())])
  #FLAGPPbounds2 = np.array([min(x2.min(), y2.min()) - int(0.1 * y2.min()), max(x2.max(), y2.max())+ int(0.1 * y2.max())])
  #FLAGPPbounds  = (min(bounds1.min(), bounds2.min()), max(bounds1.max(), bounds2.max()))
  #FLAGPP# Reset the limits
  #FLAGPPax = plt.gca()
  #FLAGPPax.set_xlim(bounds)
  #FLAGPPax.set_ylim(bounds)
  #FLAGPP# Ensure the aspect ratio is square
  #FLAGPPax.set_aspect("equal", adjustable="box")
  #FLAGPPax.scatter(x1[:], y1[:],label="Train",marker="o",edgecolor='r',c='white',s=50)
  #FLAGPPax.scatter(x2[:], y2[:],label="Train",marker="^",edgecolor='b',c='white',s=50)
  #FLAGPPax.plot([0, 1], [0, 1], "k-",lw=2 ,transform=ax.transAxes)
  #FLAGPPplt.title("Parity Plot", fontdict=font_axis_publish)
  #FLAGPPplt.xlabel('Ground Truth', fontdict=font_axis_publish)
  #FLAGPPplt.ylabel('Prediction', fontdict=font_axis_publish)
  
  #k=x_test.shape
  #nsam2=k[0]
  #stds0=x_test
  #stds1=y_test
  
  #Armse_train.append(Rrmse_train)
  #Armse_test.append(Rrmse_test)
  Alogl_train.append(logl_train)
  Alogl_test.append(logl_test)


#FLAGMPIcomm.Barrier()
#FLAGMPIKrmse_train = comm.gather(Armse_train, root=0)
#FLAGMPIKrmse_test  = comm.gather(Armse_test, root=0)
#FLAGMPIcomm.Barrier()
#FLAGMPIArmse_train = Krmse_train
#FLAGMPIArmse_test  = Krmse_test 

if ( fmpi == 0 and rank == 0 ) or fmpi == 1:
  print("|-----------------------|")
  print("|--Summary RMSE Scores--|")
  print("|-----------------------|")
  #print("|---Train RMSE Scores---|")
  #print("Cross-Validate RMSE Train Mean: {0:.4f}".format(np.mean(Armse_train)))
  #print("Cross-Validate RMSE Train Std : {0:.4f}".format(np.std(Armse_train)))
  #print("Cross-Validate RMSE Train Std2: {0:.4f}".format(np.square(np.std(Armse_train))))
  #print("Cross-Validate RMSE Train Max : {0:.4f}".format(np.max(Armse_train)))
  #print("Cross-Validate RMSE Train Min : {0:.4f}".format(np.min(Armse_train)))
  #print("|----Test RMSE Scores---|")
  #print("Cross-Validate RMSE Test  Mean: {0:.4f}".format(np.mean(Armse_test)))
  #print("Cross-Validate RMSE Test  Std : {0:.4f}".format(np.std(Armse_test)))
  #print("Cross-Validate RMSE Test  Std2: {0:.4f}".format(np.square(np.std(Armse_test))))
  #print("Cross-Validate RMSE Test  Max : {0:.4f}".format(np.max(Armse_test)))
  #print("Cross-Validate RMSE Test  Min : {0:.4f}".format(np.min(Armse_test)))
  print("|---Train LOG-Loss Scores---|")
  print("Cross-Validate LOG-Loss Train Mean: {0:.6f}".format(np.mean(Alogl_train)))
  print("Cross-Validate LOG-Loss Train Std : {0:.6f}".format(np.std(Alogl_train)))
  print("Cross-Validate LOG-Loss Train Std2: {0:.6f}".format(np.square(np.std(Alogl_train))))
  print("Cross-Validate LOG-Loss Train Max : {0:.6f}".format(np.max(Alogl_train)))
  print("Cross-Validate LOG-Loss Train Min : {0:.6f}".format(np.min(Alogl_train)))
  print("|----Test LOG-Loss Scores---|")
  print("Cross-Validate LOG-Loss Test  Mean: {0:.6f}".format(np.mean(Alogl_test)))
  print("Cross-Validate LOG-Loss Test  Std : {0:.6f}".format(np.std(Alogl_test)))
  print("Cross-Validate LOG-Loss Test  Std2: {0:.6f}".format(np.square(np.std(Alogl_test))))
  print("Cross-Validate LOG-Loss Test  Max : {0:.6f}".format(np.max(Alogl_test)))
  print("Cross-Validate LOG-Loss Test  Min : {0:.6f}".format(np.min(Alogl_test)))

#plt.show()

#FLAGacq#Mean Prediction ArgMax
#FLAGacqMS=open('Prediction/Mean-Scaled.csv', 'a')
#FLAGacqMD=open('Prediction/Mean-Direct.csv', 'a')
#FLAGacqMS.write("# Column : Discripter, Row : target-1\n")
#FLAGacqMD.write("# Column : Discripter, Row : target-1\n")
#FLAGacq#m1pred=x[np.argmax(mean)]
#FLAGacqkappa=0
#FLAGacqm1pred=acq_max()
#FLAGacqc1=sc.inverse_transform(np.vstack([std,np.append(m1pred,1)]))
#FLAGacq#c1=MINo+np.vstack([std,np.append(m1pred,1)])*(MAXo-MINo)/SFa
#FLAGacq
#FLAGacqnp.savetxt(MS,m1pred,fmt='%2.4f',newline="\n",delimiter=",")
#FLAGacqnp.savetxt(MD,c1[-1,0:ndis],fmt='%2.4e',newline="\n",delimiter=",")
#FLAGacq
#FLAGacq#UCB Prediction ArgMax
#FLAGacqUS=open('Prediction/UCB-Scaled.csv', 'a')
#FLAGacqUD=open('Prediction/UCB-Direct.csv', 'a')
#FLAGacqUS.write("# Column : Discripter, Row : target-1 x KappaVariation\n")
#FLAGacqUD.write("# Column : Discripter, Row : target-1 x KappaVariation\n")
#FLAGacqkk=np.loadtxt('Kappa.dat',delimiter="\t",dtype = "float")
#FLAGacqfor kappa in kk:
#FLAGacq	US.write("Kappa Variation\n")
#FLAGacq	UD.write("Kappa Variation\n")
#FLAGacq	
#FLAGacq	u1pred=acq_max()
#FLAGacq	c1=sc.inverse_transform(np.vstack([std,np.append(u1pred,1)]))
#FLAGacq	#c1=MINo+np.vstack([std,np.append(m1pred,1)])*(MAXo-MINo)/SFa
#FLAGacq
#FLAGacq	np.savetxt(US,u1pred,fmt='%2.4f',newline="\n",delimiter=",")
#FLAGacq	np.savetxt(UD,c1[-1,0:ndis],fmt='%2.4e',newline="\n",delimiter=",")

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
	
#Visualization
#FLAGvisgpg = 2
#FLAGviskappa = 1
#FLAGviscolormap = 'bwr'
#FLAGvisfigsurf = True
#FLAGvisfigscat = True
#FLAGvisfigtri  = True

#FLAGvisif rank == 0:
#FLAGvis  from mpl_toolkits.mplot3d import Axes3D
#FLAGvis  import plotly.graph_objects as go
#FLAGvis  import plotly.figure_factory as ff
#FLAGvis
#FLAGvis  if ndis == 1:
#FLAGvis  
#FLAGvis    fig = plt.figure(figsize=plt.figaspect(0.5))
#FLAGvis    mesh=int(1000/gpg)
#FLAGvis    x0=np.linspace(0,1,mesh)
#FLAGvis    X0 = np.meshgrid(x0)
#FLAGvis    positions = X0
#FLAGvis    x = (np.array(positions)).T
#FLAGvis    #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGvis    #FLAGGP_GPymean, sigma = m.predict(x)
#FLAGvis    #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGvis    #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis    #h=nd[0,0:2]
#FLAGvis    clabel=h[1]+'(%)'
#FLAGvis    
#FLAGvis##    maxpred,temp = m.predict(m1pred.reshape(-1,1))
#FLAGvis#    ax1 = fig.add_subplot(1,2,1, aspect='equal')
#FLAGvis#    scf = ax1.plot(std0,std1,label="Exp",marker="o",color='white',markersize=10,markeredgewidth=3,markeredgecolor='blue',alpha=0.8)
#FLAGvis##    scf = ax1.plot(m1pred,maxpred,label="MeanPred",marker="^",color='white',markersize=12,markeredgewidth=3,markeredgecolor='red',alpha=0.8)
#FLAGvis#    scf = ax1.plot(x,mean,'k-',label="mean",color="black",lw=1.5,alpha=0.6)
#FLAGvis#    ax1.set_title("Mean,Exp(o),MeanPred", fontsize=15)
#FLAGvis#    ax1.set_xlabel(h[0], fontsize=20)
#FLAGvis#    ax1.set_ylabel(clabel, fontsize=20)
#FLAGvis#    ax1.set_xlim(-0.1,1.1)
#FLAGvis#    ax1.set_ylim(-0.1,1.1)
#FLAGvis    
#FLAGvis    kappa=kappa
#FLAGvis#    u1pred=acq_max()
#FLAGvis#    maxpred, sigpred = m.predict(u1pred.reshape(-1,1))
#FLAGvis    upr=mean+kappa*sigma.reshape(-1,1)
#FLAGvis    btr=mean-kappa*sigma.reshape(-1,1)
#FLAGvis    ax2 = fig.add_subplot(1,2,2, aspect='equal')
#FLAGvis    scf = ax2.plot(std0,std1,label="Exp",marker="o",color='white',markersize=10,markeredgewidth=3,markeredgecolor='blue',alpha=0.8)
#FLAGvis#    scf = ax2.plot(u1pred,maxpred+sigpred*kappa,label="UCBPred",marker="^",color='white',markersize=12,markeredgewidth=3,markeredgecolor='red',alpha=0.8)
#FLAGvis    scf = ax2.plot(x,mean,'k-',label="mean",color="black",lw=1.5,alpha=0.6)
#FLAGvis    scf = ax2.fill_between(x.ravel(), upr.ravel(), btr.ravel(), alpha=0.5)
#FLAGvis    ax2.set_title("Mean,UCB,UCBPred", fontsize=15)
#FLAGvis    ax2.set_xlabel(h[0], fontsize=20)
#FLAGvis    ax2.set_ylabel(clabel, fontsize=20)
#FLAGvis    ax2.set_xlim(-0.1,1.1)
#FLAGvis    ax2.set_ylim(-0.1,1.1)
#FLAGvis  
#FLAGvis  	
#FLAGvis  elif ndis == 2:
#FLAGvis  
#FLAGvis    fig = plt.figure(figsize=plt.figaspect(0.5))
#FLAGvis    mesh=int(200/gpg)
#FLAGvis    x0 = np.linspace(0, 1, mesh)
#FLAGvis    x1 = np.linspace(0, 1, mesh)
#FLAGvis    X,Y = np.meshgrid(x0,x1)
#FLAGvis    positions = np.vstack([X.ravel(),Y.ravel()])
#FLAGvis    x = (np.array(positions)).T
#FLAGvis    #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGvis    #FLAGGP_GPymean, sigma = m.predict(x)
#FLAGvis    #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGvis    #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis    #h=nd[0,0:3]
#FLAGvis    clabel=h[2]+'(%)'
#FLAGvis    
#FLAGvis    Z=mean.reshape(mesh,mesh)
#FLAGvis#    maxpred, temp = m.predict(m1pred.reshape(-1,1).T)
#FLAGvis    ax = fig.add_subplot(1,2,1, projection='3d')
#FLAGvis#    scf = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAGvis    scf = ax.scatter(d_data[:,0], d_data[:,1], std1,label="Exp",marker="o",edgecolor='b',c='white',s=60)
#FLAGvis    scf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=colormap, linewidth=0.3)
#FLAGvis    ax.set_title("Mean", fontsize=15)
#FLAGvis    ax.set_xlabel(h[0], fontsize=20)
#FLAGvis    ax.set_ylabel(h[1], fontsize=20)
#FLAGvis    ax.set_zlabel(clabel, fontsize=20)
#FLAGvis    ax.set_xlim(-0.1,1.1)
#FLAGvis    ax.set_ylim(-0.1,1.1)
#FLAGvis    ax.set_zlim(-0.1,1.1)
#FLAGvis    
#FLAGvis    ucb=mean+sigma.reshape(-1,1)*kappa
#FLAGvis    Z=ucb.reshape(mesh,mesh)
#FLAGvis    kappa=kappa
#FLAGvis#    u1pred=acq_max()
#FLAGvis#    maxpred, sigpred = m.predict(u1pred.reshape(-1,1).T)
#FLAGvis    ax = fig.add_subplot(1,2,2, projection='3d')
#FLAGvis#    scf = ax.scatter(u1pred[0], u1pred[1], maxpred+sigpred*kappa,label="UCBPred",marker="^",edgecolor='r',c='white',s=200)
#FLAGvis    scf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=colormap, linewidth=0.3)
#FLAGvis    ax.set_title("UCB(Kappa=5)", fontsize=15)
#FLAGvis    ax.set_xlabel(h[0], fontsize=20)
#FLAGvis    ax.set_ylabel(h[1], fontsize=20)
#FLAGvis    ax.set_zlabel(clabel, fontsize=20)
#FLAGvis    ax.set_xlim(-0.1,1.1)
#FLAGvis    ax.set_ylim(-0.1,1.1)
#FLAGvis    ax.set_zlim(-0.1,1.1)
#FLAGvis  
#FLAGvis  elif ndis == 3:
#FLAGvis    #h=nd[0,0:4]
#FLAGvis    clabel=h[3]+'(%)'
#FLAGvis    
#FLAGvis    if figsurf is True:	
#FLAGvis      mesh=int(100/gpg)
#FLAGvis      x0 = np.linspace(0, 1, mesh)
#FLAGvis      x1 = np.linspace(0, 1, mesh)
#FLAGvis      x2 = np.linspace(0, 1, mesh)
#FLAGvis      X,Y,Z = np.meshgrid(x0,x1,x2)
#FLAGvis      positions = np.vstack([X.ravel(),Y.ravel(),Z.ravel()])
#FLAGvis      x = (np.array(positions)).T
#FLAGvis      #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGvis      #FLAGGP_GPymean, sigma = m.predict(x)
#FLAGvis      #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGvis      #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis      #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis#c#       mean=mean.numpy()
#FLAGvis      Sv=mean.reshape(mesh,mesh,mesh)
#FLAGvis      
#FLAGvis      fig1 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#FLAGvis      #fig1 = go.Figure(data=go.Scatter3d(x=std[:,0], y=std[:,1], z=std[:,2], mode='markers',marker=dict(size=std[0,3]*1000,color=std[0,3]*1000,colorscale='Viridis')))
#FLAGvis      fig1.add_trace(go.Volume(
#FLAGvis      #fig1 = go.Figure(data=go.Volume(
#FLAGvis      x=X.flatten(),
#FLAGvis      y=Y.flatten(),
#FLAGvis      z=Z.flatten(),
#FLAGvis      value=Sv.flatten(),
#FLAGvis      #isomin=0.5,
#FLAGvis      isomin=0.0,
#FLAGvis      isomax=0.5,
#FLAGvis      opacity=0.6, # needs to be small to see through all surfaces
#FLAGvis      surface_count=6, # needs to be a large number for good volume rendering
#FLAGvis      ))
#FLAGvis
#FLAGvis      fig1.update_layout(scene = dict(xaxis_title=h[0], yaxis_title=h[1], zaxis_title=h[2]))
#FLAGvis      
#FLAGvis      #fig1 = go.Figure(data=go.Scatter3d(x=std0[0], y=std0[1], z=std0[2], mode='markers'))	
#FLAGvis      
#FLAGvis      fig1.show()
#FLAGvis      
#FLAGvis      fig2 = go.Figure(data=go.Scatter3d(x=x_train[:,0], y=x_train[:,1], z=x_train[:,2], mode='markers',marker=dict(size=y_train*10,color=y_train,colorscale='Viridis',opacity=1.0)))
#FLAGvis      fig2.add_trace(go.Volume(
#FLAGvis          x=X.flatten(),
#FLAGvis          y=Y.flatten(),
#FLAGvis          z=Z.flatten(),
#FLAGvis          value=Sv.flatten(),
#FLAGvis          isomin=0.5,
#FLAGvis          isomax=1.0,
#FLAGvis          opacity=0.6, # needs to be small to see through all surfaces
#FLAGvis          surface_count=6, # needs to be a large number for good volume rendering
#FLAGvis          ))
#FLAGvis      
#FLAGvis      fig2.update_layout(scene = dict(
#FLAGvis                  xaxis_title=h[0],
#FLAGvis                  yaxis_title=h[1],
#FLAGvis                  zaxis_title=h[2]))
#FLAGvis      fig2.show()
#FLAGvis    
#FLAGvis    
#FLAGvis    if figscat is True:	
#FLAGvis      fig = plt.figure(figsize=plt.figaspect(1))
#FLAGvis      mesh=int(100/gpg)
#FLAGvis      x0 = np.linspace(0, 1, mesh)
#FLAGvis      x1 = np.linspace(0, 1, mesh)
#FLAGvis      x2 = np.linspace(0, 1, mesh)
#FLAGvis      X,Y,Z = np.meshgrid(x0,x1,x2)
#FLAGvis      positions = np.vstack([X.ravel(),Y.ravel(),Z.ravel()])
#FLAGvis      x = (np.array(positions)).T
#FLAGvis      #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGvis      #FLAGGP_GPymean, sigma = m.predict(x)
#FLAGvis      #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGvis      #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis      #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis#c#       mean = mean.numpy()
#FLAGvis#c#       sigma = sigma.numpy()
#FLAGvis      
#FLAGvis      ax = fig.add_subplot(1,1,1, projection='3d')
#FLAGvis#      ax = fig.add_subplot(1,3,1, projection='3d')
#FLAGvis      scf = ax.scatter3D(x_train[:,0], x_train[:,1], x_train[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=y_train*100)
#FLAGvis      scf = ax.scatter3D(x_test[:,0], x_test[:,1], x_test[:,2],label="Exp",marker="^",edgecolor='g',c='white',s=y_test*100)
#FLAGvis#      scf = ax.scatter3D(x_train[0], x_train[1], x_train[2],label="Exp",marker="o",edgecolor='b',c='white',s=-(y_train1-1)*100)
#FLAGvis      ax.set_title("Exp", fontsize=15)
#FLAGvis      ax.set_xlabel(h[0], fontsize=20)
#FLAGvis      ax.set_ylabel(h[1], fontsize=20)
#FLAGvis      ax.set_zlabel(h[2], fontsize=20)
#FLAGvis      ax.set_xlim(-0.1,1.1)
#FLAGvis      ax.set_ylim(-0.1,1.1)
#FLAGvis      ax.set_zlim(-0.1,1.1)
#FLAGvis      
#FLAGvis#      Sv=mean.reshape(mesh,mesh,mesh)
#FLAGvis#      maxpred, test = m.predict(m1pred.reshape(-1,1).T)
#FLAGvis#c# #      maxpred=maxpred.numpy()
#FLAGvis#      ax = fig.add_subplot(1,3,2, projection='3d')
#FLAGvis#      scf = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAGvis#      scf = ax.scatter3D(X, Y, Z, s=Sv*100, c=Sv, cmap=colormap, linewidth=0.3)
#FLAGvis#      ax.set_title("Mean", fontsize=15)
#FLAGvis#      ax.set_xlabel(h[0], fontsize=20)
#FLAGvis#      ax.set_ylabel(h[1], fontsize=20)
#FLAGvis#      ax.set_zlabel(h[2], fontsize=20)
#FLAGvis#      ax.set_xlim(-0.1,1.1)
#FLAGvis#      ax.set_ylim(-0.1,1.1)
#FLAGvis#      ax.set_zlim(-0.1,1.1)
#FLAGvis#      
#FLAGvis#      ucb=mean+sigma.reshape(-1,1)*kappa
#FLAGvis#      Sv=ucb.reshape(mesh,mesh,mesh)
#FLAGvis#      kappa=kappa
#FLAGvis#      u1pred=acq_max()
#FLAGvis#      maxpred, sigpred = m.predict(u1pred.reshape(-1,1).T)
#FLAGvis#c# #      maxpred=maxpred.numpy()
#FLAGvis#      ax = fig.add_subplot(1,3,3, projection='3d')
#FLAGvis#      scf = ax.scatter(u1pred[0], u1pred[1], maxpred+sigpred*kappa,label="UCBPred",marker="^",edgecolor='r',c='white',s=200)
#FLAGvis#      scf = ax.scatter3D(X, Y, Z, s=Sv*100, c=Sv, cmap=colormap, linewidth=0.3)
#FLAGvis#      ax.set_title("UCB(Kappa=5)", fontsize=15)
#FLAGvis#      ax.set_xlabel(h[0], fontsize=20)
#FLAGvis#      ax.set_ylabel(h[1], fontsize=20)
#FLAGvis#      ax.set_zlabel(h[2], fontsize=20)
#FLAGvis#      ax.set_xlim(-0.1,1.1)
#FLAGvis#      ax.set_ylim(-0.1,1.1)
#FLAGvis    
#FLAGvis    if figtri is True:	
#FLAGvis      xpre=[0,0,0]
#FLAGvis      mesh=int(100/gpg)
#FLAGvis      for i in range(0,101,mesh):
#FLAGvis      	for j in range(0,101,mesh):
#FLAGvis      		k=100-i-j
#FLAGvis      		if(i+j+k==100 and k>=0):
#FLAGvis      			xpre=np.vstack([xpre,[k/100,i/100,j/100]])
#FLAGvis      x=xpre[1:,:]
#FLAGvis      #FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGvis      #FLAGGP_GPymean, sigma = m.predict(x)
#FLAGvis      #FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGvis      #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis      #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis#      print(x.T.shape)
#FLAGvis#      print(mean.shape)
#FLAGvis      fig = ff.create_ternary_contour(x.T,
#FLAGvis                        mean.reshape(-1,),
#FLAGvis                       pole_labels=h[0:3], interp_mode='cartesian', showmarkers=True)
#FLAGvis      fig.show()
#FLAGvis  
#FLAGvis  elif ndis > 3:
#FLAGvis
#FLAGvis    NPC=2
#FLAGvis    d_data, h, decomp, scc = dPCA(std0.T, std1.T, NPC)
#FLAGvis    if 2 <= NPC <= 3:
#FLAGvis    	fig = plt.figure(figsize=plt.figaspect(1))
#FLAGvis    if NPC == 2:
#FLAGvis    	ax = fig.add_subplot(1,1,1)
#FLAGvis    	scf = ax.scatter(d_data[:,0], d_data[:,1],label="Exp",marker="o",edgecolor='r',c='white',s=std1.T*100)
#FLAGvis    elif NPC == 3:
#FLAGvis    	ax = fig.add_subplot(1,1,1, projection='3d')
#FLAGvis    	scf = ax.scatter3D(d_data[:,0], d_data[:,1], d_data[:,2],label="Exp",marker="o",edgecolor='r',c='white',s=std1.T*100)
#FLAGvis    if 2 <= NPC <= 3:
#FLAGvis    	ax.set_title("PCA visual", fontsize=15)
#FLAGvis
#FLAGvis    fig = plt.figure(figsize=plt.figaspect(1))
#FLAGvis    mesh=int(200/gpg)
#FLAGvis    x0 = np.linspace(0, 1, mesh)
#FLAGvis    x1 = np.linspace(0, 1, mesh)
#FLAGvis    X,Y = np.meshgrid(x0,x1)
#FLAGvis    positions = np.vstack([X.ravel(),Y.ravel()])
#FLAGvis    x = (np.array(positions)).T
#FLAGvis    Xscc = scc.inverse_transform(x)
#FLAGvis    Xscc = scc.inverse_transform(x)
#FLAGvis    Xd = decomp.inverse_transform(Xscc)
#FLAGvis    #FLAGGP_Skitmean, sigma = m.predict(Xd, return_std=True)
#FLAGvis    #FLAGGP_GPymean, sigma = m.predict(Xd)
#FLAGvis    #FLAGGP_GPflowmean, sigma = m.predict_f(Xd)
#FLAGvis    #FLAGGP_GPflowmean=mean.numpy()
#FLAGvis    #FLAGGP_GPflowsigma=sigma.numpy()
#FLAGvis    #h=nd[0,0:3]
#FLAGvis    clabel=h[2]+'(%)'
#FLAGvis    
#FLAGvis    Z=mean.reshape(mesh,mesh)
#FLAGvis#    maxpred, temp = m.predict(m1pred.reshape(-1,1).T)
#FLAGvis    ax = fig.add_subplot(1,1,1, projection='3d')
#FLAGvis#    sc = ax.scatter(m1pred[0], m1pred[1], maxpred,label="MeanPred",marker="^",edgecolor='r',c='white',s=200)
#FLAGvis    sc = ax.scatter(d_data[:,0], d_data[:,1], std1,label="Exp",marker="o",edgecolor='b',c='white',s=60)
#FLAGvis    sc = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=colormap, linewidth=0.3)
#FLAGvis    ax.set_title("Mean", fontsize=15)
#FLAGvis    ax.set_xlabel(h[0], fontsize=20)
#FLAGvis    ax.set_ylabel(h[1], fontsize=20)
#FLAGvis    ax.set_zlabel(clabel, fontsize=20)
#FLAGvis    ax.set_xlim(-0.1,1.1)
#FLAGvis    ax.set_ylim(-0.1,1.1)
#FLAGvis    ax.set_zlim(-0.1,1.1)
#FLAGvis 
#FLAGvis  plt.tight_layout()
#FLAGvis  plt.show()


#FLAGgriddatamesh=int(100/gpg)
#FLAGgriddata#FLAG2
#FLAGgriddata#FLAG3
#FLAGgriddataSXMAP = np.meshgrid(SxMAP)
#FLAGgriddata#FLAG4
#FLAGgriddataif ndis == 1:
#FLAGgriddata	positions = SXMAP
#FLAGgriddataelse:
#FLAGgriddata	positions = np.vstack([RAVELMAP])
#FLAGgriddatax = (np.array(positions)).T
#FLAGgriddata#FLAGGP_Skitmean, sigma = m.predict(x, return_std=True)
#FLAGgriddata#FLAGGP_GPymean, sigma = m.predict(x)
#FLAGgriddata#FLAGGP_GPflowmean, sigma = m.predict_f(x)
#FLAGgriddata#FLAGGP_GPflowmean=mean.numpy()
#FLAGgriddata#FLAGGP_GPflowsigma=sigma.numpy()
#FLAGgriddata		
#FLAGgriddatamZ=mean.reshape(FLAG6)
#FLAGgriddatasZ=sigma.reshape(FLAG6)
#FLAGgriddatanp.savetxt('mean.dat',mZ)
#FLAGgriddatanp.savetxt('sigma.dat',sZ)
  
