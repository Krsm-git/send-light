import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
fmpi = 1

warnings.simplefilter('ignore')

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,100,100),max_iter=500,random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

start = time.time()

dfo=pd.read_csv('train_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')
dft=pd.read_csv('test_features.csv').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

tk=dft.shape
tdis=tk[1]-1
tsam=tk[0]

#dfc=pd.concat([dfo,dfs.iloc[:,1:3]], axis=1)
#mdis=2
dfc=pd.concat([dfo,dfs.iloc[:,1:]], axis=1)
df=dfc.iloc[:,1:]


h=df.columns.values
nd=df.loc[:,h].values
dat=nd[:,:]

ntar=mdis
k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis

#--Test--#
ndt=dft.loc[:,h[0:-mdis]].values
x=np.zeros([tsam,mdis])
datt=np.hstack([ndt[:,:],x.reshape(-1,mdis)])
ttar=mdis

#sc=MinMaxScaler()
sc=StandardScaler()
#sc=QuantileTransformer()

std=sc.fit_transform(dat)
std0=std.T[0:ndis]
std1=std.T[ndis:ndis+ntar]

#--Test--# 
stdt=sc.transform(datt)
stdt0=stdt.T[0:tdis]
stdt1=stdt.T[tdis:tdis+ttar]

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Sample: {}".format(nsam))
print("Discripter: {}".format(ndis))
print("Target: {}".format(ntar))

def dPCA(XPCA, YPCA, XTPCA, NPC): 
        from sklearn.decomposition import PCA 
        from sklearn.decomposition import KernelPCA
        from sklearn.decomposition import FastICA
        from sklearn.metrics import explained_variance_score
        h=[]
        for i in range(1,NPC,1):
            h.append("PC" + str(i))
        h.append("TG")
        XXPCA=np.vstack([XPCA,XTPCA])
        #decomp = PCA(n_components=NPC, random_state=0).fit(XXPCA)
        decomp = FastICA(n_components=NPC, random_state=0).fit(XXPCA)
        #decomp = LDA(n_components=NPC).fit(XXPCA, YPCA)
        #decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XXPCA)
        #decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XXPCA)
        dd_data = decomp.transform(XXPCA)
        d_data = dd_data[:nsam,:]
        dt_data = dd_data[nsam:,:]
        evs = explained_variance_score(XXPCA, decomp.inverse_transform(dd_data))
        #evs_ratio = decomp.explained_variance_ratio_/evs
        evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
        print("|-----------------------|")
        print("|--Decomposition Param--|")
        print("|-----------------------|")
        print("Score: {}".format(evs))
        print("Score Ratio: {}".format(evs_ratio))
        print("Shape: {}".format(dd_data.shape))
        #scc=MinMaxScaler()
        #scc.fit(dd_data)
        #d_data=scc.transform(dd_data)
        return d_data, dt_data, h, decomp

spl0=std0.T[:,:3]
spl1=std0.T[:,3:3+772]
spl2=std0.T[:,3+772:]
tspl0=stdt0.T[:,:3]
tspl1=stdt0.T[:,3:3+772]
tspl2=stdt0.T[:,3+772:]
d_data, dt_data, h, decomp = dPCA(XPCA=spl1, YPCA=std1.T, XTPCA=tspl1, NPC=100)
d_data2, dt_data2, h, decomp = dPCA(XPCA=spl2, YPCA=std1.T, XTPCA=tspl2, NPC=15)
tmp1=np.hstack([spl0,d_data])
tmp2=np.hstack([tmp1,d_data2])
ttmp1=np.hstack([tspl0,dt_data])
ttmp2=np.hstack([ttmp1,dt_data2])

dfll=pd.read_csv('train_targets_nonscored.csv')
dfl=dfll.iloc[:,1:]
lk=dfl.shape
ldis=lk[1]-1
lsam=lk[0]
hl=dfl.columns.values
ndl=dfl.loc[:,hl].values
datl=ndl[:,:]
scl=StandardScaler()
stdl=scl.fit_transform(datl)

x_train=tmp2
y_train=np.hstack([std1.T,stdl])
x_test=ttmp2
#x_train=std0.T
#y_train=std1.T
#x_test=stdt0.T
  
pndis=ndis

k=x_train.shape
nsam=k[0]
ndis=k[1]

mean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
nmean_train = np.array(mean_train)
nmean_test = np.array(mean_test)
mean_train = nmean_train[:,:ntar].reshape(-1,ntar)
mean_test = nmean_test[:,:ntar].reshape(-1,ntar)

ra=np.array([[1]*pndis]*x_test.shape[0])
rb=mean_test
R2=np.hstack([ra,rb])
Rmean_test=sc.inverse_transform(R2)
Amean_test=Rmean_test[:,pndis:]

print(Amean_test)
print(Amean_test.shape)

sh=dfs.iloc[:,1:mdis+1].columns
#sh=dfs.iloc[:,1:].columns
si=dft.iloc[:,0]
spd=pd.DataFrame(data=Amean_test,index=None,columns=sh,dtype='float')

#ts1=dft.iloc[:,1:]
#ss1=spd
#ss1.loc[ts1['cp_type']==0, :] = 1E-15
#ss1[ss1 < 1E-15] = 1E-15
#ss1[ss1 > 1-1E-15] = 1-1E-15
#ss2=ss1.loc[ts1['cp_type']==1, :].sum().sum()
#y1=3104.0
#r1=y1/ss2
#ss1.loc[ts1['cp_type']==1, :] *= r1
#print(ss1.sum().sum())
#spd=ss1

sub=pd.concat([si,spd],axis=1)
print(sub.shape)
sub.to_csv('submission.csv',index=None)

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
