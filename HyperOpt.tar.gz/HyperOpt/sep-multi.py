import os
import xlrd
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
#FLAGMPIfrom mpi4py import MPI
#FLAGMPIcomm = MPI.COMM_WORLD
#FLAGMPIrank = comm.Get_rank()
#FLAGMPIsize = comm.Get_size()
fmpi = 1
#FLAGMPIfmpi = 0

warnings.simplefilter('ignore')

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100,),random_state=1)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

start = time.time()

#df=pd.read_excel('FLAG1', header=None, index_col=None).replace('male',0).replace('female',1).replace('C',0).replace('S',1).replace('Q',2)
#df=pd.read_excel('FLAG1', header=None, index_col=None)
dfo=pd.read_csv('FLAG1').replace('ctl_vehicle',0).replace('trt_cp',1).replace('D1',0).replace('D2',1)
dfs=pd.read_csv('train_targets_scored.csv')

sk=dfs.shape
mdis=sk[1]-1
msam=sk[0]

AAlogl_train=[]
AAlogl_test=[]
#for im in range(0,10):
#for im in range(0,mdis):
	dfc=pd.concat([dfo,dfs.iloc[:,im+1]], axis=1)
	df=dfc.iloc[:,1:]

	h=df.columns.values
	print("Target Name: {}".format(h[-1]))
	nd=df.loc[:,h].values
	dat=nd[:,:]
	
	ntar=1
	k=dat.shape
	ndis=k[1]-1
	nsam=k[0]
	
	#FLAG_MM1nsam=nsam-2
	#FLAG_MM1MINo=dat[nsam,:]
	#FLAG_MM1MAXo=dat[nsam+1,:]
	
	#FLAG_MM2MINo=np.min(dat[1:,:], axis=0)
	#FLAG_MM2MAXo=np.max(dat[1:,:], axis=0)
	#FLAG_MM2dat=np.vstack([dat,MINo])
	#FLAG_MM2dat=np.vstack([dat,MAXo])
	
	#sc=MinMaxScaler()
	sc=StandardScaler()
	#sc=QuantileTransformer()
	std=sc.fit_transform(dat)
	std0o=std.T[0:ndis]
	std1o=std.T[ndis:ndis+ntar]
	std0,MMi=np.split(std0o,[nsam],1)
	std1,temp=np.split(std1o,[nsam],1)
	
	print("|-----------------------|")
	print("|--Parameter Dimension--|")
	print("|-----------------------|")
	print("Sample: {}".format(nsam))
	print("Discripter: {}".format(ndis))
	print("Target: {}".format(ntar))
		
	if ndis >= 2:
		MMs=MMi.T
	else:
		MMs=MMi.reshape(-1,1)
	
	d_data=std0.T
	  
	pndis=ndis
	Alogl_train=[]
	Alogl_test=[]
	from sklearn.model_selection import train_test_split
	LRepeat = 1
	Lrank = 1
	#FLAGMPILrank=rank
	LEND = LRepeat * Lrank
	for Repeat in range(0, LEND, 1):
	  x_train, x_test, y_train, y_test = train_test_split(d_data, std1.T, test_size=0.2, random_state=Repeat)
	  
	  k=x_train.shape
	  nsam=k[0]
	  ndis=k[1]
	  
	  #FLAGET_Skitmean_train, mean_test, m = ET_Skit(x_train, y_train, x_test)
	  #FLAGRF_Skitmean_train, mean_test, m = RF_Skit(x_train, y_train, x_test)
	  #FLAGNN_Skitmean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
	  #FLAGKRR_Skitmean_train, mean_test, m = KRR_Skit(x_train, y_train, x_test)
	  #FLAGGP_Skitmean_train, mean_test, m = GP_Skit(x_train, y_train, x_test)
	  #FLAGGP_GPymean_train, mean_test, m= GP_GPy(x_train, y_train, x_test)
	  #FLAGGP_GPflowmean_train, mean_test, m = GP_GPflow(x_train, y_train, x_test)
	  #FLAGGP_Georgemean_train, mean_test, m = GP_George(x_train, y_train, x_test)
	  nmean_train = np.array(mean_train)
	  nmean_test = np.array(mean_test)
	  mean_train = nmean_train.reshape(-1,1)
	  mean_test = nmean_test.reshape(-1,1)
	  
	  ##Prediction Score
	  from sklearn.metrics import mean_squared_error
	  from sklearn.metrics import r2_score
	  print("|-----------------------|")
	  print("|------Train Score------|")
	  print("|-----------------------|")
	  R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
	  Ry_train=sc.inverse_transform(R2)
	  R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
	  Rmean_train=sc.inverse_transform(R2)
	  p1=Rmean_train[:,pndis]
	  p2=1-Rmean_train[:,pndis]
	  pp1=np.where(p1 < 1E-15,1E-15,p1)
	  pp2=np.where(p2 < 1E-15,1E-15,p2)
	  logl_train = -np.mean(Ry_train[:,pndis]*np.log(pp1)+(1-Ry_train[:,pndis])*np.log(pp2))
	  print("Log Loss: {}".format(logl_train))
	  
	  ##Test Score according to TrainData
	  print("|-----------------------|")
	  print("|------Test Score-------|")
	  print("|-----------------------|")
	  R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
	  Ry_test=sc.inverse_transform(R2)
	  R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
	  Rmean_test=sc.inverse_transform(R2)
	  p1=Rmean_test[:,pndis]
	  p2=1-Rmean_test[:,pndis]
	  pp1=np.where(p1 < 1E-15,1E-15,p1)
	  pp2=np.where(p2 < 1E-15,1E-15,p2)
	  logl_test = -np.mean(Ry_test[:,pndis]*np.log(pp1)+(1-Ry_test[:,pndis])*np.log(pp2))
	  print("Log Loss: {}".format(logl_test))
	  
	  Alogl_train.append(logl_train)
	  Alogl_test.append(logl_test)
	AAlogl_train.append(logl_train)
	AAlogl_test.append(logl_test)
	
	if ( fmpi == 0 and rank == 0 ) or fmpi == 1:
	  print("|-----------------------|")
	  print("|--Summary RMSE Scores--|")
	  print("|-----------------------|")
	  print("|---Train LOG-Loss Scores---|")
	  print("Cross-Validate LOG-Loss Train Mean: {0:.6f}".format(np.mean(Alogl_train)))
	  print("Cross-Validate LOG-Loss Train Std : {0:.6f}".format(np.std(Alogl_train)))
	  print("Cross-Validate LOG-Loss Train Std2: {0:.6f}".format(np.square(np.std(Alogl_train))))
	  print("Cross-Validate LOG-Loss Train Max : {0:.6f}".format(np.max(Alogl_train)))
	  print("Cross-Validate LOG-Loss Train Min : {0:.6f}".format(np.min(Alogl_train)))
	  print("|----Test LOG-Loss Scores---|")
	  print("Cross-Validate LOG-Loss Test  Mean: {0:.6f}".format(np.mean(Alogl_test)))
	  print("Cross-Validate LOG-Loss Test  Std : {0:.6f}".format(np.std(Alogl_test)))
	  print("Cross-Validate LOG-Loss Test  Std2: {0:.6f}".format(np.square(np.std(Alogl_test))))
	  print("Cross-Validate LOG-Loss Test  Max : {0:.6f}".format(np.max(Alogl_test)))
	  print("Cross-Validate LOG-Loss Test  Min : {0:.6f}".format(np.min(Alogl_test)))
	elapsed_time = time.time() - start
	print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")

if ( fmpi == 0 and rank == 0 ) or fmpi == 1:
  print("|------------------------------|")
  print("|--Fineal Summary RMSE Scores--|")
  print("|------------------------------|")
  print("|---Train LOG-Loss Scores---|")
  print("Cross-Validate LOG-Loss Train Mean: {0:.6f}".format(np.mean(AAlogl_train)))
  print("Cross-Validate LOG-Loss Train Std : {0:.6f}".format(np.std(AAlogl_train)))
  print("Cross-Validate LOG-Loss Train Std2: {0:.6f}".format(np.square(np.std(AAlogl_train))))
  print("Cross-Validate LOG-Loss Train Max : {0:.6f}".format(np.max(AAlogl_train)))
  print("Cross-Validate LOG-Loss Train Min : {0:.6f}".format(np.min(AAlogl_train)))
  print("|----Test LOG-Loss Scores---|")
  print("Cross-Validate LOG-Loss Test  Mean: {0:.6f}".format(np.mean(AAlogl_test)))
  print("Cross-Validate LOG-Loss Test  Std : {0:.6f}".format(np.std(AAlogl_test)))
  print("Cross-Validate LOG-Loss Test  Std2: {0:.6f}".format(np.square(np.std(AAlogl_test))))
  print("Cross-Validate LOG-Loss Test  Max : {0:.6f}".format(np.max(AAlogl_test)))
  print("Cross-Validate LOG-Loss Test  Min : {0:.6f}".format(np.min(AAlogl_test)))

elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")
