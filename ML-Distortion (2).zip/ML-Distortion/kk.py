# -*- coding: utf-8 -*-
"""
Created on Sat May 28 00:06:53 2022

@author: kngwt
"""

import pandas as pd

a=pd.DataFrame([[1,2,3],[4,5,6],[7,8,9]],columns=["a","b","c"])
b=pd.DataFrame([[11,12,13],[14,15,16],[17,18,19]],columns=["c","a","e"])

print(a)
print(b)
print(pd.concat([a,b]))
print(a.combine_first(b))
x=a.columns.values.tolist()+b.columns.values.tolist()
#print(list(set(x)))
import collections
x=[k for k, v in collections.Counter(x).items() if v > 1]
print([ix for ix in x])
c=b.columns.values.tolist()
for ix in x:
    c.remove(ix)
print(c)
print(a.join(b[c]))
#c=[b.columns.values.tolist().remove(ix) for ix in x]
#print(pd.concat([a,b[c]]))