# -*- coding: utf-8 -*-
"""
Created on Sat May 28 18:15:22 2022

@author: kngwt
"""

             q     Eform    EformD    EformP    EformO
Os_BX-BTO  2.0 -1.946622  0.009076 -1.937546 -1.946622
Yt_BX-BTO -1.0  2.362283  0.024395  2.337888  2.362283
Dy_BX-BZO -1.0  2.701171  0.027665  2.673506  2.701171
Mg_BX-STO -2.0  5.214467  0.037822  5.252289  5.214467
Ir_BX-BTO  1.0  0.918567  0.052716  0.865851  0.918567
Ni_BX-BZO -2.0  5.767388  0.090014  5.857403  5.767388
Gd_BX-BTO -1.0  2.550223  0.091679  2.641901  2.550223
Worse Precision Elements.
             q      Eform    EformD     EformP     EformO
W_BX-BTO   2.0  -7.931791  5.381553  -2.550237  -7.931791
Na_BX-BTO -3.0   7.776111  4.488056  12.264167   7.776111
K_BX-BTO  -3.0   9.663085  4.426705  14.089790   9.663085
Au_BX-BTO  0.0   6.579903  4.312628   2.267275   6.579903
Cu_BX-STO -3.0  10.426119  3.921884   6.504235  10.426119
Mo_BX-BTO  2.0  -6.904907  3.096053  -3.808854  -6.904907
Rh_BX-BTO  1.0   1.508823  3.091504  -1.582681   1.508823
Cr_BX-STO -1.0   1.944675  2.919089   4.863764   1.944675
Os_BX-BTO  0.0   2.011026  2.713021  -0.701995   2.011026
Sn_BX-BTO  0.0   0.062748  2.697299   2.760047   0.062748
|-----------------------|
|--Summary RMSE Scores--|
|-----------------------|
|---Train RMSE Scores---|
Cross-Validate RMSE Train Mean: 0.0000
Cross-Validate RMSE Train Std : 0.0000
Cross-Validate RMSE Train Std2: 0.0000
Cross-Validate RMSE Train Max : 0.0000
Cross-Validate RMSE Train Min : 0.0000
|----Test RMSE Scores---|
Cross-Validate RMSE Test  Mean: 1.4247
Cross-Validate RMSE Test  Std : 0.2453
Cross-Validate RMSE Test  Std2: 0.0602
Cross-Validate RMSE Test  Max : 1.6830
Cross-Validate RMSE Test  Min : 1.0949


High  Precision Elements.
             q     Eform    EformD    EformP    EformO
Sc_BX-BTO -1.0  2.421776    0.0089  2.430676  2.421776
Fe_BX-BTO -1.0   7.43998  0.011006  7.428973   7.43998
V_BX-BTO  -1.0  4.444355  0.024524  4.419831  4.444355
Ge_BX-BTO  0.0  5.093585  0.053349  5.040236  5.093585
In_BX-BTO -1.0  8.906324  0.068826  8.837499  8.906324
Mn_BX-BTO  0.0  6.404953  0.072648  6.332304  6.404953
Worse Precision Elements.
             q      Eform    EformD     EformP     EformO
Hg_BX-BTO -1.0  16.929865  3.100712  13.829152  16.929865
Hg_BX-BTO -2.0  17.445062  2.490038  14.955024  17.445062
Zn_BX-BTO -2.0   12.88213  1.604191  11.277939   12.88213
Be_BX-BTO -2.0   8.852976  1.553241  10.406217   8.852976
K_BX-BTO  -3.0  18.136216  1.491241  16.644975  18.136216
Cr_BX-BTO -2.0  10.331305  1.438824   8.892481  10.331305
Cu_BX-BTO -3.0  15.842694  1.431873  14.410821  15.842694
Nb_BX-BTO  1.0  -4.719711  1.242132  -3.477579  -4.719711
V_BX-BTO   1.0  -0.689346  1.166573  -1.855919  -0.689346
Co_BX-BTO -1.0   9.097197  1.104789  10.201986   9.097197
|-----------------------|
|--Summary RMSE Scores--|
|-----------------------|
|---Train RMSE Scores---|
Cross-Validate RMSE Train Mean: 0.0000
Cross-Validate RMSE Train Std : 0.0000
Cross-Validate RMSE Train Std2: 0.0000
Cross-Validate RMSE Train Max : 0.0000
Cross-Validate RMSE Train Min : 0.0000
|----Test RMSE Scores---|
Cross-Validate RMSE Test  Mean: 0.6822
Cross-Validate RMSE Test  Std : 0.6073
Cross-Validate RMSE Test  Std2: 0.3688
Cross-Validate RMSE Test  Max : 2.8120
Cross-Validate RMSE Test  Min : 0.0089


High  Precision Elements.
             q      Eform    EformD     EformP     EformO
Nd_BX-BTO -1.0   4.002032  0.213553   3.788479   4.002032
Bi_BX-BTO -1.0  11.387049  0.243476  11.630525  11.387049
Sc_BX-BTO -1.0   2.421776  0.458903   2.880678   2.421776
Hg_BX-BTO -2.0  17.445062  0.474041  16.971020  17.445062
Worse Precision Elements.
             q      Eform    EformD     EformP     EformO
Cr_BX-BTO -2.0  10.331305  8.711238   1.620067  10.331305
Co_BX-BTO  0.0   8.088036  8.015718   0.072318   8.088036
Be_BX-BTO -2.0   8.852976  7.932271  16.785247   8.852976
Cr_BX-BTO  2.0   3.002994  6.542912  -3.539918   3.002994
Al_BX-BTO -1.0   4.609212  5.770739  -1.161527   4.609212
Yb_BX-BTO -1.0   1.962867   5.38494   7.347807   1.962867
Fe_BX-BTO  1.0   5.673649  4.095398   9.769047   5.673649
Cr_BX-BTO  1.0    3.93864  4.064715  -0.126075    3.93864
Mg_BX-BTO -2.0   9.794286  3.571543   6.222743   9.794286
Hg_BX-BTO -1.0  16.929865  3.569185  13.360679  16.929865
|-----------------------|
|--Summary RMSE Scores--|
|-----------------------|
|---Train RMSE Scores---|
Cross-Validate RMSE Train Mean: 0.0000
Cross-Validate RMSE Train Std : 0.0000
Cross-Validate RMSE Train Std2: 0.0000
Cross-Validate RMSE Train Max : 0.0000
Cross-Validate RMSE Train Min : 0.0000
|----Test RMSE Scores---|
Cross-Validate RMSE Test  Mean: 2.3756
Cross-Validate RMSE Test  Std : 1.8671
Cross-Validate RMSE Test  Std2: 3.4860
Cross-Validate RMSE Test  Max : 7.9323
Cross-Validate RMSE Test  Min : 0.2136