#for Pp in "QT" "ST" "MM" "RS"
for Pp in "QT"
do
for FE in "RF" "LS"
do
if [ ${FE} == "RF" ];then 
fn=50
elif [ ${FE} == "LS" ];then 
fn=10
fi
for n in `seq 10 20 ${fn}`
do
cp run_vasp.sh run_temp.sh

sed -i "s/JJn/${n}/g"   run_temp.sh
sed -i "s/JJPp/${Pp}/g" run_temp.sh
sed -i "s/JJFE/${FE}/g" run_temp.sh
qsub run_temp.sh
rm run_temp.sh
sleep 1
done
done
done

