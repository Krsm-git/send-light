# -*- coding: utf-8 -*-
"""
Created on Sat May 28 20:31:25 2022

@author: kngwt
"""

import pandas as pd
a=pd.read_csv("Ecoh-GGAU-NonOpt-Result.csv")
print(a)
print(a[a["EformD"] > 3.0])
print(a[a["EformD"] < 3.0]["EformD"].mean())


import numpy as np

Path="BTO/"
print(np.exp(0))
dfe=pd.read_csv(Path+'Eodata.csv',index_col=0)
print(np.exp(dfe["q"]))