import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
plt.rcParams["figure.figsize"] = [7.0,4.0]  # 図の縦横のサイズ([横(inch),縦(inch)])
plt.rcParams["figure.dpi"] = 150            # dpi(dots per inch)
plt.rcParams["figure.autolayout"] = False   # レイアウトの自動調整を利用するかどうか
plt.rcParams["figure.subplot.left"] = 0.14  # 余白
plt.rcParams["figure.subplot.bottom"] = 0.2 # 余白
plt.rcParams["figure.subplot.right"] = 0.75 # 余白
plt.rcParams["figure.subplot.top"] = 0.93   # 余白
plt.rcParams["figure.subplot.wspace"] = 0.20# 図が複数枚ある時の左右との余白
plt.rcParams["figure.subplot.hspace"] = 0.20# 図が複数枚ある時の上下との余白
plt.rcParams["font.family"] = "serif"       # 使用するフォント
#plt.rcParams["font.serif"] = "Times New Roman"
plt.rcParams["font.size"] = 10              # 基本となるフォントの大きさ
plt.rcParams["mathtext.cal"] ="serif"      # TeX表記に関するフォント設定
plt.rcParams["mathtext.rm"] = "serif"       # TeX表記に関するフォント設定
plt.rcParams["mathtext.it"] = "serif:italic"# TeX表記に関するフォント設定
plt.rcParams["mathtext.bf"] = "serif:bold"  # TeX表記に関するフォント設定
plt.rcParams["mathtext.fontset"] = "cm"     # TeX表記に関するフォント設定
plt.rcParams["xtick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["ytick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["xtick.top"] = False            # 上部に目盛り線を描くかどうか
plt.rcParams["xtick.bottom"] = True         # 下部に目盛り線を描くかどうか
plt.rcParams["ytick.left"] = True           # 左部に目盛り線を描くかどうか
plt.rcParams["ytick.right"] = False          # 右部に目盛り線を描くかどうか
plt.rcParams["xtick.major.size"] = 4.0      # x軸主目盛り線の長さ
plt.rcParams["ytick.major.size"] = 4.0      # y軸主目盛り線の長さ
plt.rcParams["xtick.major.width"] = 1.0     # x軸主目盛り線の線幅
plt.rcParams["ytick.major.width"] = 1.0     # y軸主目盛り線の線幅
plt.rcParams["xtick.minor.visible"] = True # x軸副目盛り線を描くかどうか
plt.rcParams["ytick.minor.visible"] = True # y軸副目盛り線を描くかどうか
plt.rcParams["xtick.minor.size"] = 2.0      # x軸副目盛り線の長さ
plt.rcParams["ytick.minor.size"] = 2.0      # y軸副目盛り線の長さ
plt.rcParams["xtick.minor.width"] = 0.6     # x軸副目盛り線の線幅
plt.rcParams["ytick.minor.width"] = 0.6     # y軸副目盛り線の線幅
plt.rcParams["xtick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["ytick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["axes.labelsize"] = 18         # 軸ラベルのフォントサイズ
plt.rcParams["axes.linewidth"] = 1.5        # グラフ囲う線の太さ
plt.rcParams["axes.grid"] = True            # グリッドを表示するかどうか
plt.rcParams["grid.color"] = "black"        # グリッドの色
plt.rcParams["grid.linewidth"] = 0.5        # グリッドの線幅
plt.rcParams["legend.loc"] = "best"         # 凡例の位置、"best"でいい感じのところ
plt.rcParams["legend.frameon"] = True       # 凡例を囲うかどうか、Trueで囲う、Falseで囲わない
plt.rcParams["legend.framealpha"] = 1.0     # 透過度、0.0から1.0の値を入れる
plt.rcParams["legend.facecolor"] = "white"  # 背景色
plt.rcParams["legend.edgecolor"] = "black"  # 囲いの色
plt.rcParams["legend.fancybox"] = False     # Trueにすると囲いの四隅が丸くなる
plt.rcParams["legend.fontsize"] = 12     # Trueにすると囲いの四隅が丸くなる
plt.rcParams['patch.force_edgecolor'] = True
plt.rcParams["lines.markersize"] = 8
plt.rcParams["lines.markeredgewidth"] = 2.5
plt.rcParams["lines.linewidth"] = 2
#plt.rcParams["lines.linestyle"] = '-'
plt.rcParams.update({"axes.grid" : True, "grid.color": "0.4"})

Path = "BZO/"
Path = "./"

dfe=pd.read_csv(Path+'Eodata.csv',index_col=0)
efl='EfM'
efl='EfR'
efl='EfO'
dfe=dfe[['DefN','q',efl]]
dfo=dfe.rename(columns={efl: 'Eform'})

#Dsite = "BXBO"
#Dsite = "AX"
Dsite = "BX"
#Dsite = "AXBX"
#Dsite = "BXBOAX"

dfd=pd.DataFrame()
if "BX" in Dsite:
  dfti=pd.read_csv(Path+'EDdata-BX.csv',index_col=0)
  dfti=dfti.iloc[:,3:]
  dfd=dfd.append(dfti)
if "BO" in Dsite:
  dfto=pd.read_csv(Path+'EDdata-BO.csv',index_col=0)
  dfto=dfto.iloc[:,3:]
  dfd=dfd.append(dfto)
if "AX" in Dsite:
  dfba=pd.read_csv(Path+'EDdata-AX.csv',index_col=0)
  dfba=dfba.iloc[:,3:]
  dfd=dfd.append(dfba)
dfo=dfo.join(dfd)
dfo=dfo.dropna(how='any')

#print(dfo.columns)

for MMn in ['VRN']:#,'ECN','ABA','ABL','BOP']:
#for MMn in ['BOP']:
  dfd=pd.DataFrame()
  if "BX" in Dsite:
    dfti=pd.read_csv('MMdata-'+MMn+'-BX.csv',index_col=0)
    dfti=dfti.iloc[:,3:]
    dfd=dfd.append(dfti)
  if "BO" in Dsite:
    dfto=pd.read_csv('MMdata-'+MMn+'-BO.csv',index_col=0)
    dfto=dfto.iloc[:,3:]
    dfd=dfd.append(dfto)
  if "AX" in Dsite:
    dfba=pd.read_csv('MMdata-'+MMn+'-AX.csv',index_col=0)
    dfba=dfba.iloc[:,3:]
    dfd=dfd.append(dfba)
  dfo=dfo.join(dfd)
#print(dfo[dfo.isnull().any(axis=1)])
#print(dfo.loc[:, dfo.isnull().all()].columns)
#exit()
dfo=dfo.dropna(how='all')
#dfo=dfo.dropna(how='any',axis=1)

#dfd=pd.DataFrame()
#if "Ti" in Dsite:
#  dfti=pd.read_csv('ERdata-Ti.csv',index_col=0)
#  dfti=dfti.iloc[:,3:]
#  dfd=dfd.append(dfti)
#if "TO" in Dsite:
#  dfto=pd.read_csv('ERdata-TO.csv',index_col=0)
#  dfto=dfto.iloc[:,3:]
#  dfd=dfd.append(dfto)
#if "Ba" in Dsite:
#  dfba=pd.read_csv('ERdata-Ba.csv',index_col=0)
#  dfba=dfba.iloc[:,3:]
#  dfd=dfd.append(dfba)
#dfo=dfo.join(dfd)
##print(dfo[dfo.isnull().any(axis=1)])
##print(dfo.loc[:, dfo.isnull().any()])
##exit()
#dfo=dfo.dropna(how='any')

dfo=dfo.set_index('DefN', drop=True)

AXEl=['Ba','Sr']
BXEl=['Ti','Zr']
for AXE in AXEl:
  dfo.index = dfo.index.str.replace('_'+AXE, '_AX')
  dfo.index = dfo.index.str.replace('v'+AXE, 'vAX')
for BXE in BXEl:
  dfo.index = dfo.index.str.replace('_'+BXE, '_BX')
  dfo.index = dfo.index.str.replace('v'+BXE, 'vBX')

#import re
#rep=[re.sub('_[A-Z][a-z]','',i) for i in dfo.index]
#dfo.index=rep

dfex=pd.DataFrame()
if "BX" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: x+'_BX', dfn.index)
  dfex=dfex.append(dfn)
if "BO" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: 'vO+'+x+'_BX', dfn.index)
  dfex=dfex.append(dfn)
if "AX" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: x+'_AX', dfn.index)
  dfex=dfex.append(dfn)
dfo=dfo.join(dfex)
dfo=dfo.dropna(how='any',axis=1)

print(dfo)
exit()

#---Atomic Selection---#
#1##IMPatom = ['Mg','Mn','Ca','Dy','La','Ce','Gd','V','Cr','Ni','Fe','Yt','Nd','Cu','Co','Sc','Zn','K']
#1#G1 = ['K']
#1#G2 = ['Be','Mg','Ca','Sr']
#1#G3 = ['Ga','Tl']
#1#TM = ['Mn','V','Cr','Ni','Fe','Cu','Co','Zn']
#1#RE = ['Sc','Yt','Dy','La','Ce','Gd','Nd','Yb']
#1#if "Ti" in Dsite:
#1#  #dfo=dfo.drop(map(lambda x: x+'_BX', TM))
#1#  #dfo=dfo.drop(map(lambda x: x+'_BX', G1))
#1#  dfo=dfo.drop(map(lambda x: x+'_BX', G2))
#1#  #dfo=dfo.drop(map(lambda x: x+'_BX', G3))
#1#  #dfo=dfo.drop(map(lambda x: x+'_BX', RE))
#1#  #dfo=dfo.drop('Be'+'_BX')
#1#  #dfo=dfo.drop('Tl'+'_BX')
#1#if "TO" in Dsite:
#1#  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', TM))
#1#  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G1))
#1#  dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G2))
#1#  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G3))
#1#  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', RE))
#1#  #dfo=dfo.drop('vO+'+'Be'+'_BX')
#1#  #dfo=dfo.drop('vO+'+'Tl'+'_BX')
#1#if "Ba" in Dsite:
#1#  #dfo=dfo.drop(map(lambda x: x+'_AX', TM))
#1#  #dfo=dfo.drop(map(lambda x: x+'_AX', G1))
#1#  dfo=dfo.drop(map(lambda x: x+'_AX', G2))
#1#  #dfo=dfo.drop(map(lambda x: x+'_AX', G3))
#1#  #dfo=dfo.drop(map(lambda x: x+'_AX', RE))
#1#  #dfo=dfo.drop('Be'+'_AX')
#1#  #dfo=dfo.drop('Tl'+'_AX')
#1#
#1##---q Selection---#
#1##dfo=dfo[(dfo['q'] == 0)]
#1#
#1##---Discreptor Selection---#
#1##dfo=dfo[['q','IoR','Eform']]
#1##dfo=dfo[['q','IoR','dcthTi1me','Eform']]
#1##dfo=dfo[['q','Eform']]
#1#sldis=dfo.columns[~(dfo.columns.str.startswith('chg')) | ~(dfo.columns.str.startswith('mag'))]
#1#dfo=dfo[sldis]
#1##dfo.loc['dcrOx1Ratio']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#1##dfo.loc['dcrOx1Sum']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#1##dfo.loc['dcrOx1Dif']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#1#from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN
#1#dfo['magdIm1cl']=dfo['magdIm1vl'].map(lambda x: abs(float(Decimal(str(x*1.2)).quantize(Decimal('0'), rounding=ROUND_HALF_UP))))
#1#
#1#
#1###---PrePro---#
#1##from sklearn.preprocessing import RobustScaler
#1##from sklearn.preprocessing import StandardScaler
#1##from sklearn.preprocessing import MinMaxScaler
#1##from sklearn.preprocessing import QuantileTransformer
#1##fg_pp = "QT"
#1##if fg_pp == "RS":
#1##  sc=RobustScaler()
#1##elif fg_pp == "MM":
#1##  sc=MinMaxScaler()
#1##elif fg_pp == "ST":
#1##  sc=StandardScaler()
#1##elif fg_pp == "QT":
#1##  sc=QuantileTransformer()
#1##dfo.loc[:,:]=sc.fit_transform(dfo)
#1#
#1#print(dfo)
#1#DNt2g=pd.read_csv("DN-t2g_TM_Ti.csv",index_col=0,)
#1#DNt2g=pd.read_csv("DN-Unt2g_TM_Ti.csv",index_col=0,)
#1#DNt2g=pd.read_csv("DN-t2geg_TM_Ti.csv",index_col=0,)
#1#DNt2g.columns=DNt2g.columns.astype(int)
#1#dfo=dfo.assign(t2g=0)
#1##print(dfo["t2g"])
#1#for i in dfo.index.unique():
#1#  #for q in dfo.loc[i]["q"].values:
#1#  if (type(dfo.loc[i]["q"]) == pd.core.series.Series):
#1#    for j in dfo.loc[i]["q"].values:
#1#      dfo.t2g[(dfo.index == i) & (dfo["q"] == j)] = DNt2g.loc[i.replace("_Ti","")][int(j)]
#1#  else:
#1#      j=dfo.loc[i]["q"]
#1#      dfo.t2g[(dfo.index == i) & (dfo["q"] == j)] = DNt2g.loc[i.replace("_Ti","")][int(j)]
    
import matplotlib.pyplot as plt
fig = plt.figure(tight_layout=True)
fig1 = fig.add_subplot(111)
#fig2 = fig.add_subplot(412)
#fig3 = fig.add_subplot(413)
#fig_4 = fig.add_subplot(414)
 
x2=dfo['Eform']
x3=dfo['Eform']
#x=dfo['At. #']
x1=dfo['dcrOx1me']
#x1=dfo['dcrOx1mi']
#x1=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#x1=dfo['dcrOx1ma']/dfo['dcrOx1mi']/dfo['dcrOx1me']
#fig1.set_xlim(x1.min(),x1.max())
#fig1.set_ylim(x1.min(),x1.max())
y1=dfo['Eform']
#y1=dfo['chgdIm1vl']
#x1=dfo['dcrOx1me']/dfo['dcrOx1ma']/dfo['dcrOx1mi']
#y1=dfo['magdIm1cl']
#y1=dfo['t2g']
#y1=dfo['CrR']

#c1=dfo['magdIm1cl']
#y1=dfo['Voro_dist_std_devIm1vl']
#y1=dfo['Voro_dist_std_devTi3md']
#y1=dfo['Voro_dist_std_devTi3md']
#y1=dfo['Voro_dist_std_devTi2ma']
#y1=dfo['Voro_dist_std_devTi2md']
#y1=dfo['BOOP Q l=6Ti1me']
#y1=dfo['BOOP Q l=2Ox2me']
#y1=dfo['BOOP Q l=4Im1vl']
#y3=dfo['BOOP Q l=8Ba2ma']
#y=dfo['Average bond lengthTi3md']
#y3=dfo['Voro_dist_minimumOx1md']
#y=dfo['Average bond angleOx1me']
#y=dfo['Average bond angleTi2md']
#y=dfo['Average bond angleTi1me']
#y=dfo['Average bond angleIm1vl']
#y=dfo['Average bond lengthTi2md']
#y=dfo['Average bond lengthTi1me']
#y=dfo['Average bond lengthTi1st']
#y=dfo['Average bond lengthTi2st']
#y=dfo['Average bond lengthIm1vl']
#y=dfo['CN_MinimumDistanceNNIm1vl']
#y=dfo['diffthOx1me']
#y=dfo['diffthOx1md']
#y=dfo['hcrOx1me']
y=dfo['q']
#y=dfo['IoR']
#y=dfo['chgsOx1me']
#y=dfo['hcrTi1ma']
#y=dfo['hcrTi1ma']
#y=dfo['MendeleevNumber']
#y=dfo['Voro_vol_meanOx1me']
#y=dfo['chgpOx1me']
#y=dfo['diffthBa1me']
#y=dfo['diffphBa1me']
#y=dfo['psrBa1mi']
#y=dfo['diffphBa1ku']
#y=dfo['diffphBa1ku']
#y=dfo['psrOx1me']
#y=dfo['psrTi1me']
#y=dfo['dcphOx2md']
#y=dfo['dcphOx1ma']
#y=dfo['dcthOx1mi']
#y=dfo['dcphOx1mi']
#y1=dfo['dcrOx1mi']
#y2=dfo['dcrOx1me']
#y3=dfo['dcrOx1ma']
#y1=dfo['dcrOx1ma']+dfo['dcrOx1mi']
#y2=dfo['dcrOx1ma']-dfo['dcrOx1mi']
#y1=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#y=dfo['NUnfilled']
text=pd.Series(["$\mathrm{"+x.replace("_","_{")+"}" for x in dfo.index.values]) + pd.Series(["^{"+x+"}}$" for x in dfo['q'].astype(str).values])
#print(text)
fig1.scatter(x1, y1)
#fig1.scatter(x1, y1, c=c1)
#fig2.scatter(x2, y2)
#fig3.scatter(x3, y3)
texts = [fig1.text(x1[i], y1[i], text[i], ha='center', va='center') for i in range(len(x1))]
#texts = [fig2.text(x2[i], y2[i], text[i], ha='center', va='center') for i in range(len(x2))]
#texts = [fig3.text(x3[i], y3[i], text[i], ha='center', va='center') for i in range(len(x3))]
#from adjustText import adjust_text
#adjust_text(texts)
plt.show()

#rfe=['NUnfilled', 'diffthBa1me', 'diffphBa1me', 'psrBa1mi', 'dcphOx1ma', 'q', 'At. #', 'hcphOx2me', 'hcphTi1mi', 'HHIr', 'psthBa1ku']
##rfe=['Most stable oxidation State', 'hcrOx1ma', 'dcrOx1sk', 'NUnfilled', 'chgpIm1vl', 'hcphOx2me', 'dcthTi1mi', 'dcphOx1ku', 'diffthBa1ma', 'NdUnfilled', 'diffphOx1me']
##rfe=['dcphOx1ma', 'hcrOx1ma', 'NUnfilled', 'Most stable oxidation State', 'dcphOx1mi', 'diffphOx1me', 'diffthOx1me', 'BCCfermi', 'hcphOx1ku', 'diffphBa1ku', 'q']
#rfe.append('Eform')
#cor = dfo[rfe].corr()

#cor = dfo[['Eform','psrBa1me','psrTi1me','psrOx1me','psrOx2me','psrBa1st','psrTi1st','psrOx1st','psrOx2st']].corr()
#cor = dfo[['Eform','hcrIm1vl','hcthIm1vl','hcphIm1vl','diffrIm1vl','diffthIm1vl','diffphIm1vl','magtIm1vl','magdIm1vl']].corr()
#cor = dfo[['Eform','chgtBa1me','chgtTi1me','chgtOx1me','chgtOx2me','chgtBa1st','chgtTi1st','chgtOx1st','chgtOx2st']].corr()
#cor = dfo[['Eform','magtBa1me','magtTi1me','magtOx1me','magtOx2me','magtBa1st','magtTi1st','magtOx1st','magtOx2st']].corr()
#cor = dfo[['Eform','diffphBa1me','diffphTi1me','diffphOx1me','diffphOx2me','diffphBa1st','diffphTi1st','diffphOx1st','diffphOx2st']].corr()
#cor = dfo[['Eform','hcthBa1me','hcthTi1me','hcthOx1me','hcthOx2me','hcthBa1st','hcthTi1st','hcthOx1st','hcthOx2st']].corr()
#cor = dfo[['Eform','dcrBa1me','dcrTi1me','dcrOx1me','dcrOx2me','dcrBa1st','dcrTi1st','dcrOx1st','dcrOx2st']].corr()
#cor = dfo[['Eform','hcrBa1me','hcrTi1me','hcrOx1me','hcrOx2me','hcrBa1st','hcrTi1st','hcrOx1st','hcrOx2st']].corr()
#cor = dfo[['Eform','diffrBa1me','diffrTi1me','diffrOx1me','diffrOx2me','diffrBa1st','diffrTi1st','diffrOx1st','diffrOx2st']].corr()
#cor = dfo[['Eform','diffthBa1me','diffthTi1me','diffthOx1me','diffthOx2me','diffthBa1st','diffthTi1st','diffthOx1st','diffthOx2st']].corr()
#cor = dfo[['Eform','hcphBa1me','hcphTi1me','hcphOx1me','hcphOx2me','hcphBa1st','hcphTi1st','hcphOx1st','hcphOx2st']].corr()
#cor = dfo[['Eform','dcphBa1me','dcphTi1me','dcphOx1me','dcphOx2me','dcphBa1st','dcphTi1st','dcphOx1st','dcphOx2st']].corr()
#cor = dfo[['Eform','dcthBa1me','dcthTi1me','dcthOx1me','dcthOx2me','dcthBa1st','dcthTi1st','dcthOx1st','dcthOx2st']].corr()
#sns.heatmap(cor, cmap= sns.color_palette('coolwarm', 10), annot=True,fmt='.2f', vmin = -1, vmax = 1)
#plt.show()

#CL=pd.DataFrame(columns=['corr'])
#for col in dfo.columns:
#  corr=dfo[['Eform',col]].astype('float').corr()
#  CL.loc[col]=corr.iloc[0,1]
#CL=CL.dropna(how='any').sort_values(by='corr',ascending=False)
#
#print(CL.head(40))
#print(CL.tail(40))
#print(CL.mean())
#print(CL.std())

