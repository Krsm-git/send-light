import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
warnings.simplefilter('ignore')
pd.set_option('display.max_rows', None)
start = time.time()

def CT_Skit(x_train, y_train, x_test): 
	from catboost import CatBoost
	params = {
	#'loss_function': 'Logloss',
	#'num_boost_round': 100,
	'random_seed': 1,
	}
	m = CatBoost(params)
	m.fit(x_train,y_train)
	#print("CT Score: {}".format(m.score(x_train,y_train)))
	#print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def LV_Skit(x_train, y_train, x_test): 
        from sklearn.model_selection import KFold
        from sklearn.model_selection import train_test_split
        from optuna.integration import lightgbm as lgb
        mean_train = np.zeros(len(x_train))
        mean_test = np.zeros(len(x_test))
        NCV=3
        cv = KFold(n_splits=NCV)
        for trn_idx, val_idx in cv.split(x_train):
            trn_x, trn_y = x_train[trn_idx, :], y_train[trn_idx]
            val_x, val_y = x_train[val_idx, :], y_train[val_idx]
            lgb_train = lgb.Dataset(trn_x, trn_y)
            lgb_eval  = lgb.Dataset(val_x, val_y)
            lgbm_params = {'objective':'regression','metric': 'rmse','verbosity': -1,'learning_rate':0.1,'n_estimators':1000}
            best_params, history = {}, []
            m = lgb.train(lgbm_params, lgb_train, valid_sets=[lgb_train, lgb_eval], verbose_eval=False, early_stopping_rounds=100,)
            mean_train += m.predict(x_train) / NCV
            mean_test += m.predict(x_test) / NCV
        #print("LG Score: {}".format(m.score(x_train,y_train)))
        print("Hyperparameters: {}".format(m.params))
        mean_train = m.predict(x_train)
        mean_test = m.predict(x_test)
        return mean_train, mean_test, m

def LC_Skit(x_train, y_train, x_test): 
        from sklearn.model_selection import train_test_split
        from optuna.integration import lightgbm as lgb
        train_x, valid_x, train_y, valid_y = train_test_split(x_train,y_train,test_size=0.1)
        lgb_train = lgb.Dataset(train_x, train_y)
        lgb_eval = lgb.Dataset(valid_x, valid_y, reference=lgb_train)
        lgbm_params = {'objective':'regression','metric': 'rmse','verbosity': -1,'learning_rate':0.1,'n_estimators':100}
        best_params, history = {}, []
        m = lgb.train(lgbm_params, lgb_train, valid_sets=[lgb_train, lgb_eval], verbose_eval=False, early_stopping_rounds=100,)
        #print("LG Score: {}".format(m.score(x_train,y_train)))
        print("Hyperparameters: {}".format(m.params))
        mean_train = m.predict(x_train)
        print(y_train)
        mean_test = m.predict(x_test)
        return mean_train, mean_test, m

def LG_Skit(x_train, y_train, x_test): 
        from lightgbm import LGBMRegressor
        from optuna.integration import lightgbm as lgb
        lgb_train = lgb.Dataset(x_train, y_train)
        lgbm_params = {'objective':'regression','metric': 'rmse','verbosity': -1,'learning_rate':0.1,'n_estimators':100}
        m = lgb.train(lgbm_params, lgb_train, valid_sets=[lgb_train], verbose_eval=False, early_stopping_rounds=100,)
        #m = LGBMRegressor(random_state=1)
        #m.fit(x_train,y_train)
        #print("LG Score: {}".format(m.score(x_train,y_train)))
        print("Hyperparameters: {}".format(m.params))
        mean_train = m.predict(x_train)
        mean_test = m.predict(x_test)
        return mean_train, mean_test, m

def RF_Skit(x_train, y_train, x_test): 
	from sklearn.ensemble import RandomForestRegressor
	m = RandomForestRegressor(random_state=1)
	#m = RandomForestRegressor(max_depth=2, random_state=1)
	m.fit(x_train,y_train)
	print("RF Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def NN_Skit(x_train, y_train, x_test): 
	from sklearn.neural_network import MLPRegressor
	#m = MLPRegressor(hidden_layer_sizes=(75,75,75),random_state=1)
	m = MLPRegressor(hidden_layer_sizes=(100,100,100,100),random_state=1)
	#m = MLPRegressor(hidden_layer_sizes=(100,100,100),alpha=0.001,solver='adam',activation='relu',max_iter=1,random_state=1,verbose=True)
	#m = MLPRegressor(random_state=1)
	m.fit(x_train,y_train)
	print("Neural Network Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def KRR_Skit(x_train, y_train, x_test): 
	from sklearn.kernel_ridge import KernelRidge
	m = KernelRidge(kernel='rbf', alpha=0.007, gamma=0.007)
	#m = KernelRidge(alpha=1.0, kernel='rbf')
	m.fit(x_train,y_train)
	print("KRR Score: {}".format(m.score(x_train,y_train)))
	print("Hyperparameters: {}".format(m.get_params()))
	mean_train = m.predict(x_train)
	mean_test = m.predict(x_test)
	return mean_train, mean_test, m

def GP_Skit(x_train, y_train, x_test): 
	from sklearn.gaussian_process import GaussianProcessRegressor
	from sklearn.gaussian_process import kernels as sk_kern
	#kernel=sk_kern.RBF(length_scale=[1]*(ndis))
	#kernel=sk_kern.Matern(nu=2.5,length_scale=[1]*(ndis))
	#kernel=sk_kern.RationalQuadratic(length_scale=1.0, alpha=1.0, length_scale_bounds=(1e-10, 1e+10), alpha_bounds=(1e-10, 1e+10))
	#kernel=sk_kern.RBF()
	#kernel=sk_kern.Matern()
	kernel=sk_kern.RationalQuadratic()
	x_min=1E-2
	#m = GaussianProcessRegressor(kernel=kernel,random_state=1)
	m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,random_state=1)
	#m = GaussianProcessRegressor(alpha=x_min,kernel=kernel,n_restarts_optimizer=5,random_state=1)
	m.fit(x_train,y_train)
	print("Log Marginal Likelihood: {}".format(m.log_marginal_likelihood()))
	print(m.kernel_.hyperparameters)
	print("Hyperparameters: {}".format(m.kernel_.theta))
	mean_train, sigma = m.predict(x_train, return_std=True)
	mean_test, sigma = m.predict(x_test, return_std=True)
	return mean_train, mean_test, m

plt.rcParams["figure.figsize"] = [7.0,4.0]  # 図の縦横のサイズ([横(inch),縦(inch)])
plt.rcParams["figure.dpi"] = 150            # dpi(dots per inch)
plt.rcParams["figure.autolayout"] = False   # レイアウトの自動調整を利用するかどうか
plt.rcParams["figure.subplot.left"] = 0.14  # 余白
plt.rcParams["figure.subplot.bottom"] = 0.2 # 余白
plt.rcParams["figure.subplot.right"] = 0.75 # 余白
plt.rcParams["figure.subplot.top"] = 0.93   # 余白
plt.rcParams["figure.subplot.wspace"] = 0.20# 図が複数枚ある時の左右との余白
plt.rcParams["figure.subplot.hspace"] = 0.20# 図が複数枚ある時の上下との余白
plt.rcParams["font.family"] = "serif"       # 使用するフォント
#plt.rcParams["font.serif"] = "Times New Roman"
plt.rcParams["font.size"] = 14              # 基本となるフォントの大きさ
plt.rcParams["mathtext.cal"] ="serif"      # TeX表記に関するフォント設定
plt.rcParams["mathtext.rm"] = "serif"       # TeX表記に関するフォント設定
plt.rcParams["mathtext.it"] = "serif:italic"# TeX表記に関するフォント設定
plt.rcParams["mathtext.bf"] = "serif:bold"  # TeX表記に関するフォント設定
plt.rcParams["mathtext.fontset"] = "cm"     # TeX表記に関するフォント設定
plt.rcParams["xtick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["ytick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["xtick.top"] = False            # 上部に目盛り線を描くかどうか
plt.rcParams["xtick.bottom"] = True         # 下部に目盛り線を描くかどうか
plt.rcParams["ytick.left"] = True           # 左部に目盛り線を描くかどうか
plt.rcParams["ytick.right"] = False          # 右部に目盛り線を描くかどうか
plt.rcParams["xtick.major.size"] = 4.0      # x軸主目盛り線の長さ
plt.rcParams["ytick.major.size"] = 4.0      # y軸主目盛り線の長さ
plt.rcParams["xtick.major.width"] = 1.0     # x軸主目盛り線の線幅
plt.rcParams["ytick.major.width"] = 1.0     # y軸主目盛り線の線幅
plt.rcParams["xtick.minor.visible"] = True # x軸副目盛り線を描くかどうか
plt.rcParams["ytick.minor.visible"] = True # y軸副目盛り線を描くかどうか
plt.rcParams["xtick.minor.size"] = 2.0      # x軸副目盛り線の長さ
plt.rcParams["ytick.minor.size"] = 2.0      # y軸副目盛り線の長さ
plt.rcParams["xtick.minor.width"] = 0.6     # x軸副目盛り線の線幅
plt.rcParams["ytick.minor.width"] = 0.6     # y軸副目盛り線の線幅
plt.rcParams["xtick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["ytick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["axes.labelsize"] = 18         # 軸ラベルのフォントサイズ
plt.rcParams["axes.linewidth"] = 1.5        # グラフ囲う線の太さ
plt.rcParams["axes.grid"] = True            # グリッドを表示するかどうか
plt.rcParams["grid.color"] = "black"        # グリッドの色
plt.rcParams["grid.linewidth"] = 0.5        # グリッドの線幅
plt.rcParams["legend.loc"] = "best"         # 凡例の位置、"best"でいい感じのところ
plt.rcParams["legend.frameon"] = True       # 凡例を囲うかどうか、Trueで囲う、Falseで囲わない
plt.rcParams["legend.framealpha"] = 1.0     # 透過度、0.0から1.0の値を入れる
plt.rcParams["legend.facecolor"] = "white"  # 背景色
plt.rcParams["legend.edgecolor"] = "black"  # 囲いの色
plt.rcParams["legend.fancybox"] = False     # Trueにすると囲いの四隅が丸くなる
plt.rcParams["legend.fontsize"] = 12     # Trueにすると囲いの四隅が丸くなる
plt.rcParams['patch.force_edgecolor'] = True
plt.rcParams["lines.markersize"] = 8
plt.rcParams["lines.markeredgewidth"] = 2.5
plt.rcParams["lines.linewidth"] = 2
#plt.rcParams["lines.linestyle"] = '-'
plt.rcParams.update({"axes.grid" : True, "grid.color": "0.4"})

def dPCA(XPCA, YPCA, NPC): 
	from sklearn.decomposition import PCA
	from sklearn.decomposition import KernelPCA
	from sklearn.decomposition import FastICA
	from sklearn.metrics import explained_variance_score
	#import umap
	#decomp = umap.UMAP(n_neighbors=5,n_components=NPC).fit(XPCA)
	#decomp = umap.UMAP(n_neighbors=5,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	#decomp = umap.UMAP(n_neighbors=nsam,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	
	#from scipy.optimize import minimize
	#def kPCA(gamma):
	#	print(gamma)
	#	decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma)
	#	decomp.fit(XPCA)
	#	dd_data = decomp.transform(XPCA)
	#	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#	print(evs)
	#	return -evs
	#gam_ini=1.0
	#res = minimize(kPCA,gam_ini)
	#gamma=res.x
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma).fit(XPCA)
	#decomp = PCA(n_components=NPC).fit(XPCA)
	decomp = FastICA(n_components=NPC, random_state=0).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XPCA)
	dd_data = decomp.transform(XPCA)
	evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#evs = np.max(evs_ratio)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Score: {}".format(evs))
	print("Score Ratio: {}".format(evs_ratio))
	print("Shape: {}".format(dd_data.shape))
	#scc=MinMaxScaler()
	#scc.fit(dd_data)
	#d_data=scc.transform(dd_data)
	d_data=dd_data
	return d_data #, decomp, scc
	
def dLasso(XLasso, YLasso, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.linear_model import LassoCV
	estimator = LassoCV(normalize=True, cv=10)
	#estimator = LassoCV(normalize=True)
	sfm = SelectFromModel(estimator, threshold=trh)
	sfm.fit(XLasso, YLasso)
	d_data = sfm.transform(XLasso)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	slabel = rlabel[~(removed_idx)]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Removed of Descriptors: {}".format(rlabel[removed_idx]))
	print("Selected Descriptors: {}".format(rlabel[~(removed_idx)]))
	return d_data, slabel.tolist()

def dBoruta(XBoruta, YBoruta, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.ensemble import RandomForestRegressor
	from sklearn.ensemble import GradientBoostingRegressor
	from boruta import BorutaPy
	estimator = RandomForestRegressor(random_state=1)
	#estimator = GradientBoostingRegressor(random_state=1)
	sfm = BorutaPy(estimator, n_estimators='auto', verbose=2, random_state=1)
	sfm.fit(XBoruta, YBoruta)
	d_data = sfm.transform(XBoruta)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	slabel = rlabel[~(removed_idx)]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Removed of Descriptors: {}".format(rlabel[removed_idx]))
	print("Selected Descriptors: {}".format(rlabel[~(removed_idx)]))
	return d_data, slabel.tolist()


Path = "BZO/"
Path = "STO/"
Path = "BTO/"

dfe=pd.read_csv(Path+'Eodata.csv',index_col=0)
efl='EfM'
efl='EfR'
efl='EfO'
dfe=dfe[['DefN','q',efl]]
dfo=dfe.rename(columns={efl: 'Eform'})

#Dsite = "BXBO"
#Dsite = "AX"
Dsite = "BX"
#Dsite = "BO"
#Dsite = "AXBX"
#Dsite = "BXBOAX"

dfd=pd.DataFrame()
if "BX" in Dsite:
  dfti=pd.read_csv(Path+'EDdata-BX.csv',index_col=0)
  dfti=dfti.iloc[:,3:]
  dfd=dfd.append(dfti)
if "BO" in Dsite:
  dfto=pd.read_csv(Path+'EDdata-BO.csv',index_col=0)
  dfto=dfto.iloc[:,3:]
  dfd=dfd.append(dfto)
if "AX" in Dsite:
  dfba=pd.read_csv(Path+'EDdata-AX.csv',index_col=0)
  dfba=dfba.iloc[:,3:]
  dfd=dfd.append(dfba)
dfo=dfo.join(dfd)
dfo=dfo.dropna(how='any')
#dfo=dfo.dropna(how='all')

#print(dfo.columns)

for MMn in ['VRN','BOP']:#,'VCN']:#,'ECN','ABA','ABL']:
#for MMn in ['VCN']:
  dfd=pd.DataFrame()
  if "BX" in Dsite:
    dfti=pd.read_csv(Path+'MMdata-'+MMn+'-BX.csv',index_col=0)
    dfti=dfti.iloc[:,3:]
    dfd=dfd.append(dfti)
  if "BO" in Dsite:
    dfto=pd.read_csv(Path+'MMdata-'+MMn+'-BO.csv',index_col=0)
    dfto=dfto.iloc[:,3:]
    dfd=dfd.append(dfto)
  if "AX" in Dsite:
    dfba=pd.read_csv(Path+'MMdata-'+MMn+'-AX.csv',index_col=0)
    dfba=dfba.iloc[:,3:]
    dfd=dfd.append(dfba)
  dfo=dfo.join(dfd)
#print(dfo[dfo.isnull().any(axis=1)])
#print(dfo.loc[:, dfo.isnull().all()].columns)
#exit()
dfo=dfo.dropna(how='all')
#dfo=dfo.dropna(how='any',axis=1)


#dfd=pd.DataFrame()
#if "BX" in Dsite:
#  dfti=pd.read_csv('ERdata-BX.csv',index_col=0)
#  dfti=dfti.iloc[:,3:]
#  dfd=dfd.append(dfti)
#if "BO" in Dsite:
#  dfto=pd.read_csv('ERdata-BO.csv',index_col=0)
#  dfto=dfto.iloc[:,3:]
#  dfd=dfd.append(dfto)
#if "AX" in Dsite:
#  dfba=pd.read_csv('ERdata-AX.csv',index_col=0)
#  dfba=dfba.iloc[:,3:]
#  dfd=dfd.append(dfba)
#dfo=dfo.join(dfd)
#print(dfo[dfo.isnull().any(axis=1)])
#print(dfo.loc[:, dfo.isnull().any()])
##exit()
#dfo=dfo.dropna(how='all')
#print(dfo['IoR'])

dfo=dfo.set_index('DefN', drop=True)

AXEl=['Ba','Sr']
BXEl=['Ti','Zr']
for AXE in AXEl:
  dfo.index = dfo.index.str.replace('_'+AXE, '_AX')
  dfo.index = dfo.index.str.replace('v'+AXE, 'vAX')
for BXE in BXEl:
  dfo.index = dfo.index.str.replace('_'+BXE, '_BX')
  dfo.index = dfo.index.str.replace('v'+BXE, 'vBX')

#import re
#rep=[re.sub('_[A-Z][a-z]','',i) for i in dfo.index]
#dfo.index=rep

dfex=pd.DataFrame()
if "BX" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: x+'_BX', dfn.index)
  dfex=dfex.append(dfn)
if "BO" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: 'vO+'+x+'_BX', dfn.index)
  dfex=dfex.append(dfn)
if "AX" in Dsite:
  dfn=pd.read_csv('element.csv',index_col=0)
  dfn.index=map(lambda x: x+'_AX', dfn.index)
  dfex=dfex.append(dfn)
dfo=dfo.join(dfex)
#dfo=dfo.fillna(0.0)
#dfo=dfo.fillna(method='ffill')
#dfo=dfo.fillna(method='bfill')
dfo=dfo.dropna(how='any',axis=1)

#---Atomic Selection---#
#['Ag','Al','Au','Be','Bi','Ca','Cd','Ce','Co','Cr','Cu','Dy','Fe','Ga','Gd','Ge','Hf','Hg','In','Ir','Mg','Mn','Mo','Na','Nb','Nd','Ni','Os','Pb','Pd','Pt','Re','Rh','Ru','Sc','Si','Sn','Sr','Ta','Tl','V','W','Yb','Yt','Zn','Zr']
RM = ['Be','K']
G1 = ['K','Na']
G2 = ['Be','Mg','Ca','Sr']
G3 = ['Al','Ga','In','Tl']
G4 = ['Si','Ge','Sn','Pb']
G5 = ['Bi']
TM3 = ['V','Cr','Mn','Fe','Co','Ni','Cu','Zn']
TM4 = ['Zr','Nb','Mo','Ru','Rh','Pd','Ag','Cd']
TM5 = ['Hf','Ta','W','Re','Os','Ir','Pt','Au','Hg']
RE = ['Sc','Yt','Dy','La','Ce','Gd','Nd','Yb']
if "BX" in Dsite:
  print("Remove")
  #dfo=dfo.drop(map(lambda x: x+'_BX', RM))
  #dfo=dfo.drop(map(lambda x: x+'_BX', TM3))
  #dfo=dfo.drop(map(lambda x: x+'_BX', TM4))
  #dfo=dfo.drop(map(lambda x: x+'_BX', TM5))
  #dfo=dfo.drop(map(lambda x: x+'_BX', G1))
  #dfo=dfo.drop(map(lambda x: x+'_BX', G2))
  #dfo=dfo.drop(map(lambda x: x+'_BX', G3))
  #dfo=dfo.drop(map(lambda x: x+'_BX', RE))
  #dfo=dfo.drop('Be'+'_BX')
  #dfo=dfo.drop('Tl'+'_BX')
if "BO" in Dsite:
  print("Remove")
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', RM))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', TM3))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', TM4))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', TM5))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G1))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G2))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', G3))
  #dfo=dfo.drop(map(lambda x: 'vO+'+x+'_BX', RE))
  #dfo=dfo.drop('vO+'+'Be'+'_BX')
  #dfo=dfo.drop('vO+'+'Tl'+'_BX')
if "AX" in Dsite:
  print("Remove")
  #dfo=dfo.drop(map(lambda x: x+'_AX', RM))
  #dfo=dfo.drop(map(lambda x: x+'_AX', TM3))
  #dfo=dfo.drop(map(lambda x: x+'_AX', TM4))
  #dfo=dfo.drop(map(lambda x: x+'_AX', TM5))
  #dfo=dfo.drop(map(lambda x: x+'_AX', G1))
  #dfo=dfo.drop(map(lambda x: x+'_AX', G2))
  #dfo=dfo.drop(map(lambda x: x+'_AX', G3))
  #dfo=dfo.drop(map(lambda x: x+'_AX', RE))
  #dfo=dfo.drop('Be'+'_AX')
  #dfo=dfo.drop('Tl'+'_AX')
#1#
#---q Selection---#
#dfo=dfo[(dfo['q'] == 0)]

#---Discreptor Selection---#
#dfo=dfo[['q','IoR','Eform']]
#dfo=dfo[['q','IoR','dcthTi1me','Eform']]
#dfo=dfo[['q','Eform']]
#sldis=dfo.columns[~(dfo.columns.str.startswith('chg')) | ~(dfo.columns.str.startswith('mag'))]
#dfo=dfo[sldis]
#dfo.loc['dcrOx1Ratio']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#dfo.loc['dcrOx1Sum']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#dfo.loc['dcrOx1Dif']=dfo['dcrOx1ma']/dfo['dcrOx1mi']
#from decimal import Decimal, ROUND_HALF_UP, ROUND_HALF_EVEN
#dfo['magdIm1cl']=dfo['magdIm1vl'].map(lambda x: abs(float(Decimal(str(x*1.2)).quantize(Decimal('0'), rounding=ROUND_HALF_UP))))
#
#print(dfo)
#DNt2g=pd.read_csv("DN-t2g_TM_Ti.csv",index_col=0,)
#DNt2g=pd.read_csv("DN-Unt2g_TM_Ti.csv",index_col=0,)
#DNt2g=pd.read_csv("DN-t2geg_TM_Ti.csv",index_col=0,)
#DNt2g.columns=DNt2g.columns.astype(int)
#dfo=dfo.assign(t2g=0)
#print(dfo["t2g"])
#for i in dfo.index.unique():
#  #for q in dfo.loc[i]["q"].values:
#  if (type(dfo.loc[i]["q"]) == pd.core.series.Series):
#    for j in dfo.loc[i]["q"].values:
#      dfo.t2g[(dfo.index == i) & (dfo["q"] == j)] = DNt2g.loc[i.replace("_Ti","")][int(j)]
#  else:
#      j=dfo.loc[i]["q"]
#      dfo.t2g[(dfo.index == i) & (dfo["q"] == j)] = DNt2g.loc[i.replace("_Ti","")][int(j)]

#---Method Selection---#
#Nrank = XXNrank
Nrank = 40
trhLS = 1e-10
fg_pred = "KR"
#fg_pred = "CT"
#fg_pred = "LC"
#fg_pred = "LV"
#fg_pred = "LG"
#fg_pred = "GP"
#fg_pred = "RF"
#fg_fe = "LSRF"
#fg_fe = "BA"
fg_fe = "LS"
#fg_fe = "RF"
#fg_fe = "Non"
RFstop=1


#---PrePro---#
#fg_pp = "XXpp"
fg_pp = "MM"
if fg_pp == "RS":
  sc=RobustScaler()
elif fg_pp == "MM":
  sc=MinMaxScaler()
elif fg_pp == "ST":
  sc=StandardScaler()
elif fg_pp == "QT":
  sc=QuantileTransformer()

#---Elist---#
trainEl = []
testEl = []
for i in dfo.index.unique():
    trainE = dfo.reset_index().loc[~(dfo.index.str.startswith(i))].index
    trainEl.append(trainE)
    testE = dfo.index.get_loc(i)
    testEl.append(testE)
#---Elist---#

Ef = dfo['Eform'].values
dfo = dfo.drop('Eform', axis=1)
dfo['Eform'] = Ef
#print(dfo.loc['Mn'])
#print(dfo)

mdis=1
ntar=mdis
ttar=mdis

df=dfo.copy()
h=df.columns.values
#--Train--#
nd=df.loc[:,h].values
dat=nd[:,:]

k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis

#--Train--# 
std=sc.fit_transform(dat)
std0=std.T[0:ndis]
std1=std.T[ndis:ndis+ntar]

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Train Sample: {}".format(nsam))
print("Train Discripter: {}".format(ndis))
print("Train Target: {}".format(ntar))

#x_train=std0.T
#y_train=std1.T
#x_test=stdt0.T
X_train=std0.T
Y_train=std1.T

if (fg_fe=="BA"):
    d_data=std0.T
    d_data, slabel = dBoruta(XBoruta=std0.T, YBoruta=std1.T, trh=trhLS, label=h)

    if ('q' not in slabel):
      slabel.append('q')
    #slabel.append('CrR')
    #slabel.append('IoR')
    slabel.append('Eform')
    dfo=dfo[slabel]
    
    df=dfo.copy()
    h=df.columns.values
    nd=df.loc[:,h].values
    dat=nd[:,:]
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]



if fg_fe=="PC":
    d_data=std0.T
    d_data = dPCA(XPCA=std0.T, YPCA=std1.T, NPC=Nrank)
    std0 = d_data.T
    dat=np.hstack([std0.T,dat[:,-1].reshape(-1,1)])
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    #--Train--# 
    std=dat
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]

if (fg_fe=="LS") | (fg_fe=="LSRF"):
    d_data=std0.T
    d_data, slabel = dLasso(XLasso=std0.T, YLasso=std1.T, trh=trhLS, label=h)

    if ('q' not in slabel):
      slabel.append('q')
    #slabel.append('CrR')
    #slabel.append('IoR')
    slabel.append('Eform')
    dfo=dfo[slabel]
    
    df=dfo.copy()
    h=df.columns.values
    nd=df.loc[:,h].values
    dat=nd[:,:]
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]

if (fg_fe=="RF") | (fg_fe=="LSRF"):
    if (fg_fe=="LSRF"):
      X_train=std0.T
      Y_train=std1.T
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.feature_selection import RFE
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import RepeatedKFold
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.model_selection import KFold
    from sklearn.feature_selection import RFECV
    
    ## Number of Ndis
    ##def get_models():
    ##    models = dict()
    ##    for i in range(2, 5):
    ##        model = RandomForestRegressor(n_estimators=100, random_state=0)
    ##        rfe = RFE(estimator=model, n_features_to_select=i)
    ##        models[str(i)] = Pipeline(steps=[('s',rfe),('m',model)])
    ##    return models
    ##def evaluate_model(model, X, y):
    ##    cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
    ##    scores = cross_val_score(model, X, y, cv=cv, n_jobs=4)
    ##    return scores
    ##models = get_models()
    ##results, names = list(), list()
    ##for name, model in models.items():
    ##    scores = evaluate_model(model, X_train, Y_train.reshape(-1,))
    ##    results.append(scores)
    ##    names.append(name)
    ##    print('>%s %.3f (%.3f)' % (name, np.mean(scores), np.std(scores)))
    ##plt.boxplot(results, labels=names, showmeans=True)
    ##plt.show()
    ##exit()
    
    ##---RFECV---#
    #estimator = RandomForestRegressor(n_estimators=100, random_state=0)
    #min_features_to_select=10
    #rfecv = RFECV(estimator=estimator,step=1,cv=10,min_features_to_select=min_features_to_select)
    #rfecv.fit(X_train, Y_train)
    #print("Optimal number of features : %d" % rfecv.n_features_)
    #plt.figure()
    #plt.xlabel("Number of features selected")
    #plt.ylabel("Cross validation score (nb of correct classifications)")
    #plt.plot(range(min_features_to_select,len(rfecv.grid_scores_) + min_features_to_select),rfecv.grid_scores_)
    #plt.show()
    #exit()
    
    m = RandomForestRegressor(n_estimators=100, random_state=0)
    m.fit(X_train, Y_train)
    importances = m.feature_importances_
    importance_std = np.std([tree.feature_importances_ for tree in m.estimators_], axis=0)
    indices = np.argsort(importances)[::-1]
    
    #Nrank = 5
    rank_n = min(X_train.shape[1], Nrank)
    print('Feature importance ranking (TOP {rank_n})'.format(rank_n=rank_n))
    crank=[]
    tcrank=[]
    for i in range(rank_n):
        params = {'rank': i + 1,'idx': dfo.columns.tolist()[indices[i]],'importance': importances[indices[i]]}
        print('{rank}. feature {idx}: {importance}'.format(**params))
        tcrank.append(dfo.columns.tolist()[indices[i]])
        crank.append(indices[i])
    
    ##plt.figure(figsize=(8, 32))
    ##plt.barh(range(rank_n),
    ##         importances[indices][:rank_n],
    ##         color='g',
    ##         ecolor='r',
    ##         yerr=importance_std[indices][:rank_n],
    ##         align='center')
    ##plt.yticks(range(rank_n), indices[:rank_n])
    ##plt.xlabel('Importance')
    ##plt.ylabel('Features')
    ##plt.grid()
    ##plt.show()
    
    print(crank)
    print(tcrank)
    if ('q' not in tcrank):
      tcrank.append('q')
    #tcrank.append('CrR')
    #tcrank.append('IoR')
    tcrank.append('Eform')
    dfo=dfo[tcrank]
    if RFstop==1:
      exit()
    
    ##---Correlation Matrix---#
    #import seaborn as sns
    #cor = dfo.corr()
    #sns.heatmap(cor, cmap= sns.color_palette('coolwarm', 10), annot=True,fmt='.2f', vmin = -1, vmax = 1)
    #plt.show()
    #exit()
    
    df=dfo.copy()
    h=df.columns.values
    #--Train--#
    nd=df.loc[:,h].values
    dat=nd[:,:]
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    
    #--Train--# 
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]


X_train=std0.T
Y_train=std1.T
print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Train Sample: {}".format(nsam))
print("Train Discripter: {}".format(ndis))
print("Train Target: {}".format(ntar))


## RFE
##model = RandomForestRegressor(n_estimators=100, random_state=0)
##model = DecisionTreeRegressor()
##rfe = RFE(model, n_features_to_select=5)
##rfe.fit(X_train, Y_train)
##mask = rfe.support_
##
##print('選ばれた変数の数',rfe.n_features_)
##print('各変数のランキング',rfe.ranking_)

## RFE CV
##rfe = RFE(estimator=DecisionTreeRegressor(), n_features_to_select=5)
##model = DecisionTreeRegressor()
##pipeline = Pipeline(steps=[('s',rfe),('m',model)])
##cv = KFold(n_splits=2, random_state=0)
###cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
##n_scores = cross_val_score(pipeline, X_train, Y_train.reshape(-1,), cv=cv, n_jobs=-1)
##print('MAE: %.3f (%.3f)' % (np.mean(n_scores), np.std(n_scores)))

## RFE CV Wrap-Estimator
##def get_models():
##    models = dict()
##    # cart
##    rfe = RFE(estimator=DecisionTreeRegressor(), n_features_to_select=5)
##    model = DecisionTreeRegressor()
##    models['cart'] = Pipeline(steps=[('s',rfe),('m',model)])
##    # rf
##    rfe = RFE(estimator=RandomForestRegressor(n_estimators=100), n_features_to_select=5)
##    model = DecisionTreeRegressor()
##    models['rf'] = Pipeline(steps=[('s',rfe),('m',model)])
##    # gbm
##    rfe = RFE(estimator=GradientBoostingRegressor(), n_features_to_select=5)
##    model = DecisionTreeRegressor()
##    models['gbm'] = Pipeline(steps=[('s',rfe),('m',model)])
##    return models
##def evaluate_model(model, X, y):
##    cv = KFold(n_splits=10, random_state=0)
##    #cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
##    scores = cross_val_score(model, X, y, cv=cv, n_jobs=-1)
##    #scores = cross_val_score(model, X, y, scoring='r2', cv=cv, n_jobs=-1, error_score='raise')
##    return scores
##models = get_models()
##results, names = list(), list()
##for name, model in models.items():
##	scores = evaluate_model(model, X_train, Y_train.reshape(-1,))
##	results.append(scores)
##	names.append(name)
##	print('>%s %.3f (%.3f)' % (name, np.mean(scores), np.std(scores)))
##plt.boxplot(results, labels=names, showmeans=True)
##plt.show()
##exit()

pndis=ndis
k=X_train.shape
Nsam=k[0]
Ndis=k[1]

Ay_train=[]
Amean_train=[]
Ay_test=[]
Amean_test=[]
Armse_train=[]
Armse_test=[]

#---Elist---#
Elist = pd.DataFrame(columns=dfo.columns,index=dfo.index)
ix=-1
for Repeat in testEl:
  ix = ix +1
  x_train = X_train[trainEl[ix]]
  y_train = Y_train[trainEl[ix]]
  if (isinstance(Repeat,np.int64) == 1):
    x_test = X_train[Repeat].reshape(1,-1)
    y_test = Y_train[Repeat].reshape(1,-1)
  elif (isinstance(Repeat,np.int64) == 0):
    x_test = X_train[Repeat]
    y_test = Y_train[Repeat]
  idlist = np.array(range(Nsam))
  if (isinstance(Repeat,np.int64) == 1):
    id_train = idlist[trainEl[ix]].reshape(-1,)
    id_test = idlist[Repeat].reshape(-1,)
  elif (isinstance(Repeat,np.int64) == 0):
    id_train = idlist[trainEl[ix]]
    id_test = idlist[Repeat]
#---Elist---#
#---TrainTestSplit---#
#from sklearn.model_selection import train_test_split
#LEND=10
#for Repeat in range(0, LEND, 1):
#  LRepeat = Repeat
#  x_train, x_test, y_train, y_test = train_test_split(X_train, Y_train, test_size=0.2, random_state=LRepeat)
#  id_train, id_test, nodat1, nodat2 = train_test_split(np.array(range(Nsam)), Y_train, test_size=0.2, random_state=LRepeat)
#---TrainTestSplit---#

  print(x_train.shape)
  print(y_train.shape)
  print(x_test.shape)
  print(y_test.shape)
  print(id_train.shape)
  print(id_test.shape)
   
#exit()
#for Repeat in testEl:

  k=x_train.shape
  nsam=k[0]
  ndis=k[1]

  if fg_pred == "RF":
    mean_train, mean_test, m = RF_Skit(x_train, y_train, x_test)
  elif fg_pred == "NN":
    mean_train, mean_test, m = NN_Skit(x_train, y_train, x_test)
  elif fg_pred == "GP":
    mean_train, mean_test, m = GP_Skit(x_train, y_train, x_test)
  elif fg_pred == "LG":
    mean_train, mean_test, m = LG_Skit(x_train, y_train, x_test)
  elif fg_pred == "LC":
    mean_train, mean_test, m = LC_Skit(x_train, y_train, x_test)
  elif fg_pred == "LV":
    mean_train, mean_test, m = LV_Skit(x_train, y_train, x_test)
  elif fg_pred == "CT":
    mean_train, mean_test, m = CT_Skit(x_train, y_train, x_test)
  elif fg_pred == "KR":
    mean_train, mean_test, m = KRR_Skit(x_train, y_train, x_test)
  nmean_train = np.array(mean_train)
  nmean_test = np.array(mean_test)
  mean_train = nmean_train.reshape(-1,ntar)
  mean_test = nmean_test.reshape(-1,ntar)
 
  ##Prediction Score
  from sklearn.metrics import mean_absolute_error
  from sklearn.metrics import mean_squared_error
  print("|-----------------------|")
  print("|------Train Score------|")
  print("|-----------------------|")
  R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
  p1=sc.inverse_transform(R2)
  Ry_train=p1
  #Ry_train=np.round(p1)
  #Ry_train=np.where(p1 < 0,0,p1)
  R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
  p1=sc.inverse_transform(R2)
  Rmean_train=p1
  #Rmean_train=np.round(p1)
  #Rmean_train=np.where(p1 < 0,0,p1)
  #mse_train = mean_absolute_error(Ry_train[:,pndis],Rmean_train[:,pndis])
  #mse_train = mean_absolute_error(Ry_train[:,pndis],Rmean_train[:,pndis])
  mse_train = np.sqrt(mean_squared_error(Ry_train[:,pndis],Rmean_train[:,pndis]))
  print("Mean Squared Error: {}".format(mse_train))
 
  print("|-----------------------|")
  print("|------Test Score-------|")
  print("|-----------------------|")
  R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
  p1=sc.inverse_transform(R2)
  Ry_test=p1
  R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
  p1=sc.inverse_transform(R2)
  Rmean_test=p1
  #mse_test = mean_absolute_error(Ry_test[:,pndis],Rmean_test[:,pndis])
  mse_test = np.sqrt(mean_squared_error(Ry_test[:,pndis],Rmean_test[:,pndis]))
  print("Mean Squared Error: {}".format(mse_test))

  print("|-----------------------|")
  print("|------Inverse Tr-------|")
  print("|-----------------------|")
  train=np.hstack([x_train,mean_train])
  test=np.hstack([x_test,mean_test])
  inv1=np.vstack([train,test])
  inv2=sc.inverse_transform(inv1)
  inv3=inv2
  inv4=np.concatenate([id_train,id_test])
  inv=np.hstack([inv3,inv4.reshape(-1,1)])
  dfx=dfo[['Eform']]
  #dfx=dfo.copy()
  dfx['id']=0
  dfi = pd.DataFrame(data=inv[:,-2:], index=None, columns=dfx.columns) 
  #dfi = pd.DataFrame(data=inv, index=None, columns=dfx.columns) 
  dfi=dfi.sort_values('id').reset_index(drop=True)
  dfi['q']=dfo['q'].values
  dfi.index=dfo.index.values
  dfi=dfi.drop('id', axis=1)
  diff=dfo[['Eform']]
  #diff = dfo.copy()
  diff['EformD'] = abs(dfo['Eform'] - dfi['Eform'])
  diff['EformP'] = dfi['Eform']
  diff['EformO'] = dfo['Eform']
  diff['q'] = dfo['q']
  #print(diff.iloc[id_train])
  #print(diff.iloc[id_test])
  #---Elist---#
  #Elist=Elist.append(dfi.iloc[id_test])
  #Elist=Elist.append(dfo.iloc[id_test])
  Elist=Elist.append(diff.iloc[id_test])
  #---Elist---#

  Armse_train=np.append(Armse_train,mse_train)
  Armse_test=np.append(Armse_test,mse_test)
  Ay_train=np.append(Ay_train,Ry_train[:,pndis]) 
  Amean_train=np.append(Amean_train,Rmean_train[:,pndis])
  Ay_test=np.append(Ay_test,Ry_test[:,pndis])
  Amean_test=np.append(Amean_test,Rmean_test[:,pndis])
  #Armse_train.append(mse_train)
  #Armse_test.append(mse_test)
  #Ay_train.append(Ry_train[:,pndis]) 
  #Amean_train.append(Rmean_train[:,pndis])
  #Ay_test.append(Ry_test[:,pndis])
  #Amean_test.append(Rmean_test[:,pndis])

#---Elist---#
Elist = Elist.dropna(how='all', axis=1).dropna(how='all', axis=0)
#print(Elist)
#Elist['q'] -= 4
Elist[['q','EformD']].to_csv('a.csv')
print("High  Precision Elements.")
print(Elist[Elist['EformD']<0.1].sort_values('EformD').index.unique())
print(Elist[Elist['EformD']<0.1].sort_values('EformD'))
#print("Mid  Precision Elements.")
#print(Elist[(Elist['EformD']>0.1) & (Elist['EformD']<0.2)].sort_values('EformD').index.unique())
#print(Elist[(Elist['EformD']>0.1) & (Elist['EformD']<0.2)].sort_values('EformD'))
print("Worse Precision Elements.")
print(Elist.sort_values('EformD',ascending=False).iloc[:10].index.unique())
print(Elist.sort_values('EformD',ascending=False).iloc[:10])
#---Elist---#

print("|-----------------------|")
print("|--Summary RMSE Scores--|")
print("|-----------------------|")
#print("Cross-Validate RMSE Train: {}".format(Armse_train))
#print("Cross-Validate RMSE Test : {}".format(Armse_test))
print("|---Train RMSE Scores---|")
print("Cross-Validate RMSE Train Mean: {0:.4f}".format(np.mean(Armse_train)))
print("Cross-Validate RMSE Train Std : {0:.4f}".format(np.std(Armse_train)))
print("Cross-Validate RMSE Train Std2: {0:.4f}".format(np.square(np.std(Armse_train))))
print("Cross-Validate RMSE Train Max : {0:.4f}".format(np.max(Armse_train)))
print("Cross-Validate RMSE Train Min : {0:.4f}".format(np.min(Armse_train)))
print("|----Test RMSE Scores---|")
print("Cross-Validate RMSE Test  Mean: {0:.4f}".format(np.mean(Armse_test)))
print("Cross-Validate RMSE Test  Std : {0:.4f}".format(np.std(Armse_test)))
print("Cross-Validate RMSE Test  Std2: {0:.4f}".format(np.square(np.std(Armse_test))))
print("Cross-Validate RMSE Test  Max : {0:.4f}".format(np.max(Armse_test)))
print("Cross-Validate RMSE Test  Min : {0:.4f}".format(np.min(Armse_test)))

##Parity Plot
# Plot Figures
fignow = plt.figure(figsize=(8,8))
x1 = np.array(   Ay_train) 
y1 = np.array(Amean_train)
x2 = np.array(    Ay_test)
y2 = np.array( Amean_test)
# find the boundaries of X and Y values
bounds1 = np.array([min(x1.min(), y1.min()) - int(0.1 * y1.min()), max(x1.max(), y1.max())+ int(0.1 * y1.max())])
bounds2 = np.array([min(x2.min(), y2.min()) - int(0.1 * y2.min()), max(x2.max(), y2.max())+ int(0.1 * y2.max())])
bounds  = (min(bounds1.min(), bounds2.min()), max(bounds1.max(), bounds2.max()))
# Reset the limits
ax = plt.gca()
ax.set_xlim(bounds)
ax.set_ylim(bounds)
# Ensure the aspect ratio is square
ax.set_aspect("equal", adjustable="box")
ax.scatter(x1[:], y1[:],label="Train",marker="o",edgecolor='r',c='white',s=50)
ax.scatter(x2[:], y2[:],label="Train",marker="^",edgecolor='b',c='white',s=50)
ax.plot([0, 1], [0, 1], "k-",lw=2 ,transform=ax.transAxes)
plt.xlabel('$\mathrm{Ground Truth\ (eV)}$')
plt.ylabel('$\mathrm{Prediction\ (eV)}$')
 
plt.show()
elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")


