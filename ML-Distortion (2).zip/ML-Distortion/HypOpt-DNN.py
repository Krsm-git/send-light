import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import RobustScaler
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import QuantileTransformer
import time
import warnings
from mpi4py import MPI
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()
fmpi = 0
warnings.simplefilter('ignore')
start = time.time()

def dPCA(XPCA, YPCA, NPC): 
	from sklearn.decomposition import PCA
	from sklearn.decomposition import KerneNrankPCA
	from sklearn.decomposition import FastICA
	from sklearn.metrics import explained_variance_score
	#import umap
	#decomp = umap.UMAP(n_neighbors=5,n_components=NPC).fit(XPCA)
	#decomp = umap.UMAP(n_neighbors=5,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	#decomp = umap.UMAP(n_neighbors=nsam,min_dist=1.0,n_components=NPC).fit(XPCA, y=YPCA.reshape(-1,))
	
	#from scipy.optimize import minimize
	#def kPCA(gamma):
	#	print(gamma)
	#	decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma)
	#	decomp.fit(XPCA)
	#	dd_data = decomp.transform(XPCA)
	#	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#	print(evs)
	#	return -evs
	#gam_ini=1.0
	#res = minimize(kPCA,gam_ini)
	#gamma=res.x
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.1, gamma=gamma).fit(XPCA)
	#decomp = PCA(n_components=NPC).fit(XPCA)
	decomp = FastICA(n_components=NPC, random_state=0).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="rbf", fit_inverse_transform=True, alpha=0.01, gamma=1).fit(XPCA)
	#decomp = KernelPCA(n_components=NPC, kernel="linear", fit_inverse_transform=True, alpha=0.001).fit(XPCA)
	dd_data = decomp.transform(XPCA)
	evs_ratio = np.var(dd_data, axis=0) / np.sum(np.var(dd_data, axis=0))
	evs = explained_variance_score(XPCA, decomp.inverse_transform(dd_data))
	#evs = np.max(evs_ratio)
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Score: {}".format(evs))
	print("Score Ratio: {}".format(evs_ratio))
	print("Shape: {}".format(dd_data.shape))
	#scc=MinMaxScaler()
	#scc.fit(dd_data)
	#d_data=scc.transform(dd_data)
	d_data=dd_data
	return d_data #, decomp, scc
	
def dLasso(XLasso, YLasso, trh, label):
	from sklearn.feature_selection import SelectFromModel
	from sklearn.linear_model import LassoCV
	estimator = LassoCV(normalize=True, cv=10)
	#estimator = LassoCV(normalize=True)
	sfm = SelectFromModel(estimator, threshold=trh)
	sfm.fit(XLasso, YLasso)
	d_data = sfm.transform(XLasso)
	removed_idx  = ~sfm.get_support()
	rlabel = label[:-1]
	slabel = rlabel[~(removed_idx)]
	print("|-----------------------|")
	print("|--Decomposition Param--|")
	print("|-----------------------|")
	print("Number of Descriptors: {}".format(d_data.shape[1]))
	print("Removed of Descriptors: {}".format(rlabel[removed_idx]))
	print("Selected Descriptors: {}".format(rlabel[~(removed_idx)]))
	return d_data, slabel.tolist()



dfd=pd.read_csv('EDdata.csv',index_col=0)
#print(dfd)

dfr=pd.read_csv('ERdata.csv',index_col=0)
#print(dfr)
dfr=dfr.iloc[:,3:]
dfo=dfd.join(dfr).dropna(how='any')

#---Rad Only---#
#dfo=dfr.copy()

#---Dist Only---#
dfo=dfd.copy()

dfo=dfo.set_index('DefN', drop=True)

dfn=pd.read_csv('element.csv',index_col=0)
dfn=dfn.iloc[:,0:]

import re
rep=[re.sub('_[A-Z][a-z]','',i) for i in dfo.index]
dfo.index=rep
#print(dfo)
#print(dfn)
#dfo=dfo.drop('Sc').drop('Y')

#---Atomic Selection---#
#IMPatom = ['Mg','Mn','Ca','Dy','La','Ce','Gd','V','Cr','Ni','Fe','Yt','Nd','Cu','Co','Sc','Zn','K']
G1 = ['K']
G2 = ['Be','Mg','Ca','Sr']
G3 = ['Ga']
TM = ['Mn','V','Cr','Ni','Fe','Cu','Co','Sc','Zn','Yt']
RE = ['Dy','La','Ce','Gd','Nd','Yb']
#dfo=dfo.drop(TM)
dfo=dfo.drop(G1)
#dfo=dfo.drop(G2)
dfo=dfo.drop(G3)
dfo=dfo.drop(RE)
dfo=dfo.drop('Be')

#---q Selection---#
#dfo=dfo[(dfo['q'] == 3)]

#---Discreptor Selection---#
#dfo=dfo[['q','IoR','Eform']]
#dfo=dfo[['q','IoR','dcthTi1me','Eform']]

#---Method Selection---#
Nrank = XXNrank
fg_pred = "NN"
fg_fe = "XXfe"

#---PrePro---#
fg_pp = "XXpp"
if fg_pp == "RS":
  sc=RobustScaler()
elif fg_pp == "MM":
  sc=MinMaxScaler()
elif fg_pp == "ST":
  sc=StandardScaler()
elif fg_pp == "QT":
  sc=QuantileTransformer()

#dfc = dfo.copy()
dfc = dfo.join(dfn).dropna(how='any')
#print(dfc.loc['Mn'])
#El#trainEl = []
#El#testEl = []
#El#for i in dfc.index.unique():
#El#    trainE = dfc.reset_index().loc[~(dfc.index.str.contains(i))].index
#El#    trainEl.append(trainE)
#El#    testE = dfc.index.get_loc(i)
#El#    testEl.append(testE)

Ef = dfc['Eform'].values
dfc = dfc.drop('Eform', axis=1)
dfc['Eform'] = Ef
#print(dfc.loc['Mn'])
print(dfc)

mdis=1
ntar=mdis
ttar=mdis

df=dfc.copy()
h=df.columns.values
#--Train--#
nd=df.loc[:,h].values
dat=nd[:,:]

k=dat.shape
ndis=k[1]-ntar
nsam=k[0]
tdis=ndis


#--Train--# 
std=sc.fit_transform(dat)
std0=std.T[0:ndis]
std1=std.T[ndis:ndis+ntar]

print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Train Sample: {}".format(nsam))
print("Train Discripter: {}".format(ndis))
print("Train Target: {}".format(ntar))

#x_train=std0.T
#y_train=std1.T
#x_test=stdt0.T
X_train=std0.T
Y_train=std1.T

if fg_fe=="PC":
    d_data=std0.T
    d_data = dPCA(XPCA=std0.T, YPCA=std1.T, NPC=Nrank)
    std0 = d_data.T
    dat=np.hstack([std0.T,dat[:,-1].reshape(-1,1)])
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    #--Train--# 
    std=dat
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]

elif fg_fe=="LS":
    d_data=std0.T
    d_data, slabel = dLasso(XLasso=std0.T, YLasso=std1.T, trh=1e-10, label=h)

    #slabel.append('CrR')
    #slabel.append('IoR')
    slabel.append('Eform')
    dfc=dfc[slabel]
    
    df=dfc.copy()
    h=df.columns.values
    nd=df.loc[:,h].values
    dat=nd[:,:]
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]


elif fg_fe=="RF":
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.feature_selection import RFE
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import cross_val_score
    from sklearn.model_selection import RepeatedKFold
    from sklearn.tree import DecisionTreeRegressor
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.model_selection import KFold
    from sklearn.feature_selection import RFECV
    
    ## Number of Ndis
    ##def get_models():
    ##    models = dict()
    ##    for i in range(2, 30):
    ##        model = RandomForestRegressor(n_estimators=100, random_state=0)
    ##        rfe = RFE(estimator=model, n_features_to_select=i)
    ##        models[str(i)] = Pipeline(steps=[('s',rfe),('m',model)])
    ##    return models
    ##def evaluate_model(model, X, y):
    ##    cv = RepeatedKFold(n_splits=10, n_repeats=3, random_state=1)
    ##    scores = cross_val_score(model, X, y, cv=cv, n_jobs=-1)
    ##    return scores
    ##models = get_models()
    ##results, names = list(), list()
    ##for name, model in models.items():
    ##    scores = evaluate_model(model, X_train, Y_train.reshape(-1,))
    ##    results.append(scores)
    ##    names.append(name)
    ##    print('>%s %.3f (%.3f)' % (name, np.mean(scores), np.std(scores)))
    ##plt.boxplot(results, labels=names, showmeans=True)
    ##plt.show()
    ##exit()
    
    m = RandomForestRegressor(n_estimators=100, random_state=0)
    m.fit(X_train, Y_train)
    
    importances = m.feature_importances_
    importance_std = np.std([tree.feature_importances_ for tree in m.estimators_], axis=0)
    indices = np.argsort(importances)[::-1]
    
    #Nrank = 5
    rank_n = min(X_train.shape[1], Nrank)
    print('Feature importance ranking (TOP {rank_n})'.format(rank_n=rank_n))
    crank=[]
    tcrank=[]
    for i in range(rank_n):
        params = {'rank': i + 1,'idx': dfc.columns.tolist()[indices[i]],'importance': importances[indices[i]]}
        print('{rank}. feature {idx}: {importance}'.format(**params))
        tcrank.append(dfc.columns.tolist()[indices[i]])
        crank.append(indices[i])
    
    ##plt.figure(figsize=(8, 32))
    ##plt.barh(range(rank_n),
    ##         importances[indices][:rank_n],
    ##         color='g',
    ##         ecolor='r',
    ##         yerr=importance_std[indices][:rank_n],
    ##         align='center')
    ##plt.yticks(range(rank_n), indices[:rank_n])
    ##plt.xlabel('Importance')
    ##plt.ylabel('Features')
    ##plt.grid()
    ##plt.show()
    
    print(crank)
    print(tcrank)
    #tcrank.append('CrR')
    #tcrank.append('IoR')
    tcrank.append('Eform')
    dfc=dfc[tcrank]
    
    ##---Correlation Matrix---#
    #import seaborn as sns
    #cor = dfc.corr()
    #sns.heatmap(cor, cmap= sns.color_palette('coolwarm', 10), annot=True,fmt='.2f', vmin = -1, vmax = 1)
    #plt.show()
    #exit()
    
    df=dfc.copy()
    h=df.columns.values
    #--Train--#
    nd=df.loc[:,h].values
    dat=nd[:,:]
    
    k=dat.shape
    ndis=k[1]-ntar
    nsam=k[0]
    tdis=ndis
    
    #--Train--# 
    std=sc.fit_transform(dat)
    std0=std.T[0:ndis]
    std1=std.T[ndis:ndis+ntar]

X_train=std0.T
Y_train=std1.T
print("|-----------------------|")
print("|--Parameter Dimension--|")
print("|-----------------------|")
print("Train Sample: {}".format(nsam))
print("Train Discripter: {}".format(ndis))
print("Train Target: {}".format(ntar))

pndis=ndis
k=X_train.shape
Nsam=k[0]
Ndis=k[1]

Armse_train=[]
Armse_test=[]

clist=[]
for hlsD in range(1,15,1):
  for hlsN in range(25,400,25):
  #for hlsN in [10,20,40,60,80,100,150,200]:
    clist.append([hlsD,hlsN])

Ncl = len(clist)

NRF = -(-Ncl // size)
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
LEND = 10
for ix in range(NRF):
  iclx = ix * size + ( rank + 1 ) - 1
  if iclx >= Ncl:
    break
  hlsD = clist[iclx][0]
  hlsN = clist[iclx][1]
  print("|-----------------------|")
  print("|------Hyper Param------|")
  print("|-----------------------|")
  print(" All: {}".format(clist[iclx]))
  print(" HiddenLayerDepth: {}".format(hlsD))
  print(" HiddenLayerNumber: {}".format(hlsN))
  hls = np.full((hlsD,),hlsN) 
  m = MLPRegressor(verbose=True, hidden_layer_sizes=hls, random_state=1)

  Armse_train=[]
  Armse_test=[]
  for Repeat in range(0, LEND, 1):
    LRepeat = Repeat
    x_train, x_test, y_train, y_test = train_test_split(X_train, Y_train, test_size=0.2, random_state=LRepeat)
    id_train, id_test, nodat1, nodat2 = train_test_split(np.array(range(Nsam)), Y_train, test_size=0.2, random_state=LRepeat)
  
    print(x_train.shape)
    print(y_train.shape)
    print(x_test.shape)
    print(y_test.shape)
    print(id_train.shape)
    print(id_test.shape)
  
    m.fit(x_train,y_train)
    print("Neural Network Iter: {}".format(m.n_iter_))
    print("Neural Network Loss: {}".format(m.loss_))
    print("Neural Network Score: {}".format(m.score(x_train,y_train)))
    print("Hyperparameters: {}".format(m.get_params()))
  
    k=x_train.shape
    nsam=k[0]
    ndis=k[1]
  
    mean_train = m.predict(x_train)
    mean_test  = m.predict(x_test)
    nmean_train = np.array(mean_train)
    nmean_test = np.array(mean_test)
    mean_train = nmean_train.reshape(-1,ntar)
    mean_test = nmean_test.reshape(-1,ntar)
   
    ##Prediction Score
    from sklearn.metrics import mean_absolute_error
    from sklearn.metrics import mean_squared_error
    print("|-----------------------|")
    print("|------Train Score------|")
    print("|-----------------------|")
    R2=np.hstack([[[1]*pndis]*x_train.shape[0],y_train])
    p1=sc.inverse_transform(R2)
    Ry_train=p1
    #Ry_train=np.round(p1)
    #Ry_train=np.where(p1 < 0,0,p1)
    R2=np.hstack([[[1]*pndis]*x_train.shape[0],mean_train])
    p1=sc.inverse_transform(R2)
    Rmean_train=p1
    #Rmean_train=np.round(p1)
    #Rmean_train=np.where(p1 < 0,0,p1)
    #mse_train = mean_absolute_error(Ry_train[:,pndis],Rmean_train[:,pndis])
    #mse_train = mean_absolute_error(Ry_train[:,pndis],Rmean_train[:,pndis])
    mse_train = np.sqrt(mean_squared_error(Ry_train[:,pndis],Rmean_train[:,pndis]))
    print("Mean Squared Error: {}".format(mse_train))
   
    print("|-----------------------|")
    print("|------Test Score-------|")
    print("|-----------------------|")
    R2=np.hstack([[[1]*pndis]*x_test.shape[0],y_test])
    p1=sc.inverse_transform(R2)
    Ry_test=p1
    R2=np.hstack([[[1]*pndis]*x_test.shape[0],mean_test])
    p1=sc.inverse_transform(R2)
    Rmean_test=p1
    #mse_test = mean_absolute_error(Ry_test[:,pndis],Rmean_test[:,pndis])
    mse_test = np.sqrt(mean_squared_error(Ry_test[:,pndis],Rmean_test[:,pndis]))
    print("Mean Squared Error: {}".format(mse_test))
  
    print("|-----------------------|")
    print("|------delay Time-------|")
    print("|-----------------------|")
    train=np.hstack([x_train,mean_train])
    test=np.hstack([x_test,mean_test])
    inv1=np.vstack([train,test])
    inv2=sc.inverse_transform(inv1)
    inv3=inv2
    inv4=np.concatenate([id_train,id_test])
    inv=np.hstack([inv3,inv4.reshape(-1,1)])
    dfx=dfc[['Eform']]
    dfx['id']=0
    dfi = pd.DataFrame(data=inv[:,-2:], index=None, columns=dfx.columns) 
    dfi=dfi.sort_values('id').reset_index(drop=True)
    dfi.index=dfc.index.values
    dfi=dfi.drop('id', axis=1)
    diff=dfc[['Eform']]

    diff['Eform'] = dfc['Eform'] - dfi['Eform']
    print(diff.iloc[id_train])
    print(diff.iloc[id_test])

    Armse_train.append(mse_train)
    Armse_test.append(mse_test)
  
  print("|-----------------------|")
  print("|--Summary RMSE Scores--|")
  print("|-----------------------|")
  #print("Cross-Validate RMSE Train: {}".format(Armse_train))
  #print("Cross-Validate RMSE Test : {}".format(Armse_test))
  print("|---Train RMSE Scores---|")
  print("Cross-Validate RMSE Train Mean: {0:.4f}".format(np.mean(Armse_train)))
  print("Cross-Validate RMSE Train Std : {0:.4f}".format(np.std(Armse_train)))
  print("Cross-Validate RMSE Train Std2: {0:.4f}".format(np.square(np.std(Armse_train))))
  print("Cross-Validate RMSE Train Max : {0:.4f}".format(np.max(Armse_train)))
  print("Cross-Validate RMSE Train Min : {0:.4f}".format(np.min(Armse_train)))
  print("|----Test RMSE Scores---|")
  print("Cross-Validate RMSE Test  Mean: {0:.4f}".format(np.mean(Armse_test)))
  print("Cross-Validate RMSE Test  Std : {0:.4f}".format(np.std(Armse_test)))
  print("Cross-Validate RMSE Test  Std2: {0:.4f}".format(np.square(np.std(Armse_test))))
  print("Cross-Validate RMSE Test  Max : {0:.4f}".format(np.max(Armse_test)))
  print("Cross-Validate RMSE Test  Min : {0:.4f}".format(np.min(Armse_test)))


  filename = 'ResHyp-'+'XXWW'+'/hyperopt' + str(rank) + '.dat'
  with open(filename, 'a') as ff:
    ff.write(str(clist[iclx])+'  ')
    ff.write(str(np.mean(Armse_test))+'\n')


elapsed_time = time.time() - start
print ("elapsed_time : {0:.4f}".format(elapsed_time) + "[sec]")


