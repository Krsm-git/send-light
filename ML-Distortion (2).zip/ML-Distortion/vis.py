import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D

plt.rcParams["figure.figsize"] = [7.0,4.0]  # 図の縦横のサイズ([横(inch),縦(inch)])
plt.rcParams["figure.dpi"] = 150            # dpi(dots per inch)
plt.rcParams["figure.autolayout"] = False   # レイアウトの自動調整を利用するかどうか
plt.rcParams["figure.subplot.left"] = 0.14  # 余白
plt.rcParams["figure.subplot.bottom"] = 0.2 # 余白
plt.rcParams["figure.subplot.right"] = 0.75 # 余白
plt.rcParams["figure.subplot.top"] = 0.93   # 余白
plt.rcParams["figure.subplot.wspace"] = 0.20# 図が複数枚ある時の左右との余白
plt.rcParams["figure.subplot.hspace"] = 0.20# 図が複数枚ある時の上下との余白
plt.rcParams["font.family"] = "serif"       # 使用するフォント
#plt.rcParams["font.serif"] = "Times New Roman"
plt.rcParams["font.size"] = 14              # 基本となるフォントの大きさ
plt.rcParams["mathtext.cal"] ="serif"      # TeX表記に関するフォント設定
plt.rcParams["mathtext.rm"] = "serif"       # TeX表記に関するフォント設定
plt.rcParams["mathtext.it"] = "serif:italic"# TeX表記に関するフォント設定
plt.rcParams["mathtext.bf"] = "serif:bold"  # TeX表記に関するフォント設定
plt.rcParams["mathtext.fontset"] = "cm"     # TeX表記に関するフォント設定
plt.rcParams["xtick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["ytick.direction"] = "out"      # 目盛り線の向き、内側"in"か外側"out"かその両方"inout"か
plt.rcParams["xtick.top"] = False            # 上部に目盛り線を描くかどうか
plt.rcParams["xtick.bottom"] = True         # 下部に目盛り線を描くかどうか
plt.rcParams["ytick.left"] = True           # 左部に目盛り線を描くかどうか
plt.rcParams["ytick.right"] = False          # 右部に目盛り線を描くかどうか
plt.rcParams["xtick.major.size"] = 4.0      # x軸主目盛り線の長さ
plt.rcParams["ytick.major.size"] = 4.0      # y軸主目盛り線の長さ
plt.rcParams["xtick.major.width"] = 1.0     # x軸主目盛り線の線幅
plt.rcParams["ytick.major.width"] = 1.0     # y軸主目盛り線の線幅
plt.rcParams["xtick.minor.visible"] = True # x軸副目盛り線を描くかどうか
plt.rcParams["ytick.minor.visible"] = True # y軸副目盛り線を描くかどうか
plt.rcParams["xtick.minor.size"] = 2.0      # x軸副目盛り線の長さ
plt.rcParams["ytick.minor.size"] = 2.0      # y軸副目盛り線の長さ
plt.rcParams["xtick.minor.width"] = 0.6     # x軸副目盛り線の線幅
plt.rcParams["ytick.minor.width"] = 0.6     # y軸副目盛り線の線幅
plt.rcParams["xtick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["ytick.labelsize"] = 12        # 目盛りのフォントサイズ
plt.rcParams["axes.labelsize"] = 18         # 軸ラベルのフォントサイズ
plt.rcParams["axes.linewidth"] = 1.5        # グラフ囲う線の太さ
plt.rcParams["axes.grid"] = True            # グリッドを表示するかどうか
plt.rcParams["grid.color"] = "black"        # グリッドの色
plt.rcParams["grid.linewidth"] = 0.5        # グリッドの線幅
plt.rcParams["legend.loc"] = "best"         # 凡例の位置、"best"でいい感じのところ
plt.rcParams["legend.frameon"] = True       # 凡例を囲うかどうか、Trueで囲う、Falseで囲わない
plt.rcParams["legend.framealpha"] = 1.0     # 透過度、0.0から1.0の値を入れる
plt.rcParams["legend.facecolor"] = "white"  # 背景色
plt.rcParams["legend.edgecolor"] = "black"  # 囲いの色
plt.rcParams["legend.fancybox"] = False     # Trueにすると囲いの四隅が丸くなる
plt.rcParams["legend.fontsize"] = 12     # Trueにすると囲いの四隅が丸くなる
plt.rcParams['patch.force_edgecolor'] = True
plt.rcParams["lines.markersize"] = 8
plt.rcParams["lines.markeredgewidth"] = 2.5
plt.rcParams["lines.linewidth"] = 2
#plt.rcParams["lines.linestyle"] = '-'
plt.rcParams.update({"axes.grid" : True, "grid.color": "0.4"})



data = pd.read_csv('temp',header = None)
data = data.sort_values(1).sort_values(0)
df_pivot = pd.pivot_table(data=data, values=2, columns=1, index=0, aggfunc=np.mean)
print(df_pivot)

fig = plt.figure()
ax = fig.add_subplot(111)
cf = ax.contourf(df_pivot.index, df_pivot.columns, df_pivot.T,51,vmin=0,vmax=2,cmap='tab20b')

pp = fig.colorbar(cf, orientation="vertical")
pp.set_label("$\mathrm{Root\ Mean\ Squared\ Error\ (eV)}$", fontsize=12)

ax.set_xlabel("$\mathrm{Nlayer}$")
ax.set_ylabel("$\mathrm{Ndepth}$")

plt.show()
fig.savefig("HypOpt.png")

